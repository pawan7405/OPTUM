﻿using System;
using System.Web;

using System.Text;
using System.Web.UI;
using System.Configuration;


using CryptoManager;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WebChat.ChatArea
{
    public partial class ChatWithUs : Page
    {
        //external application parameters
        private static readonly string mIdApplication = ConfigurationManager.AppSettings["EXTERNALAPPLICATION_CHAT_SAMPLE12"].ToString();
        private static readonly string mUserExternalAplication = ConfigurationManager.AppSettings["USER_EXTERNALAPPLICATION_CHAT_SAMPLE12"].ToString();
        private static readonly string mPasswordExternalAplication = ConfigurationManager.AppSettings["PASSWORD_EXTERNALAPPLICATION_CHAT_SAMPLE12"].ToString();
        private static readonly string mLanguageCode = ConfigurationManager.AppSettings["LANGUAGECODE_CHAT_SAMPLE12"].ToString();
        private static readonly string RequestTypeTreeID = ConfigurationManager.AppSettings["RequestTypeTreeID"];
        private static readonly string UserTypeTreeID = ConfigurationManager.AppSettings["UserTypeTreeID"];
        private static readonly string ClassificationTypeTreeID = ConfigurationManager.AppSettings["ClassificationTypeTreeID"];
        private static readonly string UrgentClassificationTypeTreeID = ConfigurationManager.AppSettings["UrgentClassificationTypeTreeID"];
        private static readonly string UrgentSubClassificationTypeTreeID = ConfigurationManager.AppSettings["UrgentSubClassificationTypeTreeID"];
        private static readonly string documentType = ConfigurationManager.AppSettings["DocumentType"];
        private static readonly string document = ConfigurationManager.AppSettings["Document"];
        //queue
        private static readonly string mQueueLogin = ConfigurationManager.AppSettings["CHAT_QUEUE_LOGIN_SAMPLE12"].ToString();
        private static int queueID = 0;

        //customer type for chat queue
        private static string mId_CUTYNewClient = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            string ModeSource;
            bool enableRequest;
            string URLSite;
            string ChatType;
            string CodeJSScriptLiteral;

            if (!IsPostBack)
            {
                ClientScript.GetPostBackEventReference(this, string.Empty);         //Postabck management in the client side

                //save urlsite
                URLSite = ConfigurationManager.AppSettings["URLChatExternalUI_SAMPLE12"];

                if (!URLSite.EndsWith("/"))
                {
                    URLSite += "/";
                }

                //encode url
                URLSiteHidden.Value = HttpUtility.UrlEncode(URLSite);

                CodeJSScriptLiteral = "";
                CodeJSScriptLiteral = CodeJSScriptLiteral + "<script src='" + URLSite + "signalr/hubs' ></script>";
                JSScriptsSignalRhubReferenceLiteral.Text = CodeJSScriptLiteral;

                //check schedule
                enableRequest = true;
                if (Request["ModeSource"] != null)
                {
                    ModeSource = Request["ModeSource"].ToString();
                    if (ModeSource == "CHECKSCHEDULE" && !IsValidSchedule(mQueueLogin))
                    {

                        enableRequest = false;

                    }
                }
                ChatType = Request["ChatType"];
                if (string.IsNullOrEmpty(ChatType))
                {
                    ChatTypeTextBox.Value = "TEXT";
                }
                else
                {
                    if (ChatType == "VIDEO")
                    {
                        ChatTypeTextBox.Value = "VIDEO";
                    }
                    else
                    {
                        ChatTypeTextBox.Value = "TEXT";
                    }
                }

                if (enableRequest)
                {
                    RequestDiv.Style.Add("display", "block");
                    OutOfScheduleDiv.Style.Add("display", "none");
                    SaveButton.Enabled = true;
                }
                else
                {
                    RequestDiv.Style.Add("display", "none");
                    OutOfScheduleDiv.Style.Add("display", "block");
                }

                #region Load Dropdown lists

                requestTypeRadioButtonList.DataSource = GetBranchesByParent(RequestTypeTreeID, mLanguageCode);
                requestTypeRadioButtonList.DataTextField = "Text";
                requestTypeRadioButtonList.DataValueField = "Value";
                requestTypeRadioButtonList.DataBind();

                ddlusertype.DataSource = GetBranchesByParent(UserTypeTreeID, mLanguageCode);
                ddlusertype.DataTextField = "Text";
                ddlusertype.DataValueField = "Value";
                ddlusertype.DataBind();
                ListItem listuserType = new ListItem("Select User Type", "-1");
                ddlusertype.Items.Insert(0, listuserType);

                ddlclassificationtype.DataSource = GetBranchesByParent(ClassificationTypeTreeID, mLanguageCode);
                ddlclassificationtype.DataTextField = "Text";
                ddlclassificationtype.DataValueField = "Value";
                ddlclassificationtype.DataBind();
                ListItem listClass = new ListItem("Select Classification Type", "-1");
                ddlclassificationtype.Items.Insert(0, listClass);

                ListItem listSubClass = new ListItem("Select Sub Classification Type", "-1");
                ddlsubclassificationtype.Items.Insert(0, listSubClass);
                ddlsubclassificationtype.Enabled = false;



                #endregion


            }
            else
            {
                //RequestDiv.Style.Add("display", "none");
                //OutOfScheduleDiv.Style.Add("display", "none");
                //RedirectingDiv.Style.Add("display", "block");
            }
        }

        private Boolean IsValidSchedule(string UserLogin)
        {
            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string Message;
            string encryptedUser;
            string encryptedPassword;
            string signature;
            string encryptedSignature;
            string md5parameters;
            string serviceparameters;
            string script;
            string message = "";
            string publicKey2;

            StringBuilder htmlTaskTable = new StringBuilder();

            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIGetScheduleByUserResponse GetScheduleByUserResponse;

            //Get utc date and time
            DateTime RightNow = DateTime.UtcNow;

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {

                script = "alert('Error creating key pairs');";
                ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", script, true);
                return false;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                script = "alert('Error getting public key');";
                ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", script, true);
                return false;
            }

            //encrypt user

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                script = "alert('Error encrypting user');";
                ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", script, true);
                return false;
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                script = "alert('Error encrypting password');";
                ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", script, true);
                return false;
            }

            //compute md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px is a datetime must be converted to string using yyyy-mm-dd 24hh:mm:ss
            //if px is byte array md5_byte opperation needs to be performed (see samples)
            md5parameters = "";
            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            //add specific parameters 
            serviceparameters += UserLogin;

            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                script = "alert('Error creating md5 hash');";
                ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", script, true);
                return false;
            }

            //calculates signature
            //signature: idapplication|utcyear-utcmonth-utcday-utchour-utcminute|md5parameters
            signature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString();
            signature = signature + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();
            signature = signature + "|" + md5parameters;

            //encrypt signature
            Message = "";
            encryptedSignature = RsaManager.EncryptRSA(publicKey2, signature, ref Message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                script = "alert('Error encrypting signature');";
                ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", script, true);
                return false;
            }

            GetScheduleByUserResponse = ws.GetScheduleByUser(publicKey1, encryptedUser, encryptedPassword, encryptedSignature, UserLogin);
            if (GetScheduleByUserResponse.response.responseCode == 1)
            {
                if (GetScheduleByUserResponse.schedule.ActiveNow)
                {
                    return true;
                }

                message = "We are currently outside our opening hours. ";
                message += " Our attention will begin in " + String.Format("{0:yyyy/MM/dd HH:mm:ss}", GetScheduleByUserResponse.schedule.NextWorkingDate);

                message += " Time Zone: " + GetScheduleByUserResponse.schedule.TimeZone;
                OutOfScheduleLabel.Text = message;
                DateTime actualDate;
                DateTime iniTime;
                DateTime endTime;
                actualDate = DateTime.Today;

                //Table head
                htmlTaskTable.AppendLine("<table class='table table-striped' align='center' width='98%'>");
                htmlTaskTable.AppendLine("<thead class='thead-default'>");
                htmlTaskTable.AppendLine("<tr>");
                htmlTaskTable.AppendLine("<td><b></b></td>");
                htmlTaskTable.AppendLine("<td><b>Start Time</b></td>");
                htmlTaskTable.AppendLine("<td><b>End Time</b></td>");
                htmlTaskTable.AppendLine("</tr>");
                htmlTaskTable.AppendLine("</thead>");

                //Monday                
                iniTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Monday_Start * 60.0);
                endTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Monday_End * 60.0);
                htmlTaskTable.AppendLine("<tr>");
                htmlTaskTable.AppendLine("<td>Monday</td>");
                if (GetScheduleByUserResponse.schedule.Monday_Start == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", iniTime) + "</td>");
                }

                if (GetScheduleByUserResponse.schedule.Monday_End == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", endTime) + "</td>");
                }
                htmlTaskTable.AppendLine("</tr>");

                //Tuesday
                iniTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Tuesday_Start * 60.0);
                endTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Tuesday_End * 60.0);
                htmlTaskTable.AppendLine("<tr>");
                htmlTaskTable.AppendLine("<td>Tuesday</td>");
                if (GetScheduleByUserResponse.schedule.Tuesday_Start == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", iniTime) + "</td>");
                }

                if (GetScheduleByUserResponse.schedule.Tuesday_End == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", endTime) + "</td>");
                }
                htmlTaskTable.AppendLine("</tr>");

                //Wednesday                
                iniTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Wednesday_Start * 60.0);
                endTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Wednesday_End * 60.0);
                htmlTaskTable.AppendLine("<tr>");
                htmlTaskTable.AppendLine("<td>Wednesday</td>");
                if (GetScheduleByUserResponse.schedule.Wednesday_Start == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", iniTime) + "</td>");
                }

                if (GetScheduleByUserResponse.schedule.Wednesday_End == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", endTime) + "</td>");
                }
                htmlTaskTable.AppendLine("</tr>");

                //Thursday                
                iniTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Thursday_Start * 60.0);
                endTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Thursday_End * 60.0);
                htmlTaskTable.AppendLine("<tr>");
                htmlTaskTable.AppendLine("<td>Thursday</td>");
                if (GetScheduleByUserResponse.schedule.Thursday_Start == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", iniTime) + "</td>");
                }

                if (GetScheduleByUserResponse.schedule.Thursday_End == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", endTime) + "</td>");
                }
                htmlTaskTable.AppendLine("</tr>");

                //Friday 
                iniTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Friday_Start * 60.0);
                endTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Friday_End * 60.0);
                htmlTaskTable.AppendLine("<tr>");
                htmlTaskTable.AppendLine("<td>Friday</td>");
                if (GetScheduleByUserResponse.schedule.Friday_Start == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", iniTime) + "</td>");
                }

                if (GetScheduleByUserResponse.schedule.Friday_End == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", endTime) + "</td>");
                }
                htmlTaskTable.AppendLine("</tr>");

                //Saturday                
                iniTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Saturday_Start * 60.0);
                endTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Saturday_End * 60.0);
                htmlTaskTable.AppendLine("<tr>");
                htmlTaskTable.AppendLine("<td>Saturday</td>");
                if (GetScheduleByUserResponse.schedule.Saturday_Start == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", iniTime) + "</td>");
                }

                if (GetScheduleByUserResponse.schedule.Saturday_End == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", endTime) + "</td>");
                }
                htmlTaskTable.AppendLine("</tr>");

                //Sunday                
                iniTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Sunday_Start * 60.0);
                endTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Sunday_End * 60.0);
                htmlTaskTable.AppendLine("<tr>");
                htmlTaskTable.AppendLine("<td>Sunday</td>");
                if (GetScheduleByUserResponse.schedule.Sunday_Start == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", iniTime) + "</td>");
                }

                if (GetScheduleByUserResponse.schedule.Sunday_End == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", endTime) + "</td>");
                }
                htmlTaskTable.AppendLine("</tr>");

                //Holiday
                iniTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Holiday_Start * 60.0);
                endTime = actualDate.AddMinutes(GetScheduleByUserResponse.schedule.Holiday_End * 60.0);
                htmlTaskTable.AppendLine("<tr>");
                htmlTaskTable.AppendLine("<td>Holiday</td>");
                if (GetScheduleByUserResponse.schedule.Holiday_Start == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", iniTime) + "</td>");
                }

                if (GetScheduleByUserResponse.schedule.Holiday_End == 24)
                {
                    htmlTaskTable.AppendLine("<td>24:00</td>");
                }
                else
                {
                    htmlTaskTable.AppendLine("<td>" + string.Format("{0:HH:mm}", endTime) + "</td>");
                }
                htmlTaskTable.AppendLine("</tr>");

                //Loading information to Div
                htmlTaskTable.AppendLine("</table>");
                ScheduleTable.InnerHtml = htmlTaskTable.ToString();

                return false;
            }
            else
            {//Error
                script = "alert('Error: " + GetScheduleByUserResponse.response.responseDescription + "');";
                ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", script, true);
                return false;
            }
        }

        private static bool GetQueueProperties(string QueueLogin, ref string Id_CUTY, ref string ErrorMessage)
        {
            Newtonsoft.Json.Linq.JToken objJson;

            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIGetChatQueuePropertiesByLoginResponse ChatPropertiesResponse;

            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters;
            DateTime RightNow = DateTime.UtcNow;
            ErrorMessage = "";
            Id_CUTY = "";

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                ErrorMessage = "Error creating key pairs";
                return false;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                ErrorMessage = "Error creating public key";
                return false;
            }

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                ErrorMessage = "Error encrypting user";
                return false;
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                ErrorMessage = "Error encrypting password";
                return false;
            }


            //Get properties for current chat queue

            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters += QueueLogin;

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                ErrorMessage = "Error creating md5 hash";
                return false;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                ErrorMessage = "Error encrypting signature";
                return false;
            }


            ChatPropertiesResponse = ws.GetChatQueuePropertiesByLogin(publicKey1, encryptedUser, encryptedPassword, signature, QueueLogin);
            if (ChatPropertiesResponse.response.responseCode != 1)
            {
                //Error
                ErrorMessage = "Error getting chat properties:" + ChatPropertiesResponse.response.responseDescription;
                return false;
            }

            objJson = Newtonsoft.Json.Linq.JToken.Parse(ChatPropertiesResponse.JsonChatQueueProperties);

            Id_CUTY = objJson["Id_CUTY"].ToString();


            return true;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Globalization", "CA1305:Specify IFormatProvider", Justification = "<Pending>")]
        protected void SaveButton_Click(object sender, EventArgs e)
        {

            RequestDiv.Style.Add("display", "none");
            OutOfScheduleDiv.Style.Add("display", "none");
            RedirectingDiv.Style.Add("display", "block");

            string script;
            string ErrorMessage;
            string CaseNumber;
            bool r;
            string RequestId;
            string encryptedRequestId;
            string ProactiveId = "";
            string url;

            if (Request["ProactiveId"] != null)
            {
                ProactiveId = Request["ProactiveId"].ToString();
            }

            //get queue properties
            ErrorMessage = "";
            r = GetQueueProperties(mQueueLogin, ref mId_CUTYNewClient, ref ErrorMessage);
            if (!r)
            {
                ErrorMessage = "alert('Error getting queue properties ::" + ErrorMessage + "'); ";
                ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", ErrorMessage, true);
                return;
            }

            //save case
            ErrorMessage = "";
            CaseNumber = null;
            r = SaveCase(ref ErrorMessage, ref CaseNumber, mId_CUTYNewClient);
            if (!r)
            {
                ErrorMessage = "alert('Error Saving case ::" + ErrorMessage + "'); ";
                ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", ErrorMessage, true);
                return;
            }

            //save chat request
            encryptedRequestId = null;
            RequestId = null;
            ErrorMessage = "";
            r = SaveChatRequest(ref ErrorMessage, ref RequestId, ref encryptedRequestId, CaseNumber);
            if (!r)
            {
                ErrorMessage = "alert('Error Saving chat request ::" + ErrorMessage + "');";
                ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", ErrorMessage, true);
                return;
            }
            //UPDATE CHAT REQUEST TO ENABLE REQUIRESRECEIVENOTIFICATION
            r = UpdateChatRequestRequiresReceiveNotifications(ref ErrorMessage, RequestId, true);
            if (!r)
            {
                ErrorMessage = "alert('Error updating chat request ::" + ErrorMessage + "');";
                ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", ErrorMessage, true);
                return;
            }

            //redirect
            url = "ChatRouting.aspx?RequestId=" + encryptedRequestId + "&ProactiveId=" + ProactiveId + "&ChatType=" + ChatTypeTextBox.Value;

            script = "setTimeout(function(){window.location.href='" + url + "'},3000);";
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "scriptRedirecting", script, true);
        }

        private bool SaveCase(ref string ErrorMessage, ref string CaseNumber, string Id_CUTYNewClient)
        {
            // search client by email
            //if exists gets clientid and subsidiary id (no update any data)
            //if not exists insert it with unkown document type and customer type Id_CUTYNewClient
            //Then insert additional data (name and last name ) to preserve typed data

            //Then insert case with 5 fixed classifiers 

            WebChat.wsTPClientAPI.TPClientWebServicesAPI ws = new WebChat.wsTPClientAPI.TPClientWebServicesAPI();
            WebChat.wsTPClientAPI.APIGetClientResponse clientResponse;
            WebChat.wsTPClientAPI.APIInsertCustomerResponse insertClientResponse;

            WebChat.wsTPClientAPI.APISaveCaseResponse caseResponse;


            WebChat.wsTPClientAPI.APIGetChatInitialClassificatorByQueueLoginResponse InitialClassificator;

            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters;
            string value = null;
            string symmetrickey;
            string[] Data;

            string emailAddress;
            int client;
            int subsidiary;
            string comments;


            string guid;
            string name;
            string lastName;
            string crewid;
            //string documentType = "UNK";
            //string document;

            string Id_BALE;
            string BranchCodeTree1;
            string BranchCodeTree2;
            string BranchCodeTree3;
            string BranchCodeTree4;
            string BranchCodeTree5;
            DateTime RightNow = DateTime.UtcNow;
            ErrorMessage = "";
            CaseNumber = null;

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                ErrorMessage = "Error creating key pairs";
                return false;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                ErrorMessage = "Error creating public key";
                return false;
            }

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                ErrorMessage = "Error encrypting user";
                return false;
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                ErrorMessage = "'Error encrypting password";
                return false;
            }


            //Get classificators for current chat queue

            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters += mQueueLogin;

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                ErrorMessage = "Error creating md5 hash";
                return false;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                ErrorMessage = "Error encrypting signature";
                return false;
            }

            InitialClassificator = ws.GetChatInitialClassificatorByQueueLogin(publicKey1, encryptedUser, encryptedPassword, signature, mQueueLogin);
            if (InitialClassificator.response.responseCode != 1)
            {
                //Error
                ErrorMessage = "Error getting initial classificators:" + InitialClassificator.response.responseDescription;
                return false;
            }
            else
            {
                Id_BALE = InitialClassificator.InitialClassifier.IdBaseLevel;

                BranchCodeTree1 = requestTypeRadioButtonList.SelectedValue;
                BranchCodeTree2 = ddlusertype.SelectedValue;
                if (ddlclassificationtype.SelectedValue != "-1")
                {
                    BranchCodeTree3 = ddlclassificationtype.SelectedValue;
                }
                else { BranchCodeTree3 = UrgentClassificationTypeTreeID; }
                if (ddlsubclassificationtype.SelectedValue != "-1")
                {
                    BranchCodeTree4 = ddlsubclassificationtype.SelectedValue;
                }
                else { BranchCodeTree4 = UrgentSubClassificationTypeTreeID; }
                BranchCodeTree5 = InitialClassificator.InitialClassifier.Classify5_Id_BRANCH;
            }


            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            emailAddress = emailTextBox.Text.Trim();

            if (string.IsNullOrEmpty(emailAddress))
            {
                ErrorMessage = "Invalid Email Address";
                return false;
            }

            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters += emailAddress;

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                ErrorMessage = "Error creating md5 hash";
                return false;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                ErrorMessage = "Error encrypting signature";
                return false;
            }


            comments = queryTextArea.Text.Trim();

            guid = System.Guid.NewGuid().ToString();
            name = nameTextBox.Text.Trim();
            lastName = lastNameTextBox.Text.Trim();
            crewid = crewidTextBox.Text.Trim();
            clientResponse = ws.GetClientByEmail(publicKey1, encryptedUser, encryptedPassword, signature, emailAddress);
            if (clientResponse.response.responseCode == 1)
            {
                symmetrickey = RsaManager.DecryptRSA(keyPairs, clientResponse.response.encryptedSymmetrickey, ref message);
                Data = symmetrickey.Split('^');
                DesManager desEncryptor = new DesManager(Data[0], Data[1]);

                value = "";
                r = desEncryptor.DecryptText(clientResponse.clients[0].ClientIdEncrypted, ref value);
                if (!r || string.IsNullOrEmpty(value))
                {
                    ErrorMessage = "Error decrypting client id";
                    return false;
                }
                client = Convert.ToInt32(value);

                value = "";
                r = desEncryptor.DecryptText(clientResponse.clients[0].SubsidiaryIdEncrypted, ref value);
                if (!r || string.IsNullOrEmpty(value))
                {
                    ErrorMessage = "Error decrypting subsidiary id);";
                    return false;
                }
                subsidiary = Convert.ToInt32(value);
            }
            else if (clientResponse.response.responseCode == -4) //No client found
            {
                //document = guid;

                //doctype,docnumber,name,last name, additionalinfo,isactive,internalcode,address,addressinfo,phone1,phone2,email,geography,guid
                serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
                serviceparameters = serviceparameters + documentType + crewid + name + lastName + "" + "1" + "" + "" + "" + "" + "" + "" + emailAddress + "" + "";
                serviceparameters = serviceparameters + "" + "" + Id_CUTYNewClient + "" + "";

                md5parameters = "";
                r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
                if (!r || string.IsNullOrEmpty(md5parameters))
                {
                    //Error
                    ErrorMessage = "Error creating md5 hash";
                    return false;
                }

                signature = appSignature + "|" + md5parameters;

                signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
                if (string.IsNullOrEmpty(signature))
                {
                    //Error
                    ErrorMessage = "Error encrypting signature";
                    return false;
                }
                insertClientResponse = ws.InsertCustomer(publicKey1, encryptedUser, encryptedPassword, signature, documentType,
                    crewid, name, lastName, "", true, "", "", "", "", "", "", emailAddress, "", "", "", "", Id_CUTYNewClient, "", "");

                if (insertClientResponse.response.responseCode == 1)
                {
                    symmetrickey = RsaManager.DecryptRSA(keyPairs, insertClientResponse.response.encryptedSymmetrickey, ref message);
                    Data = symmetrickey.Split('^');
                    DesManager desEncryptor = new DesManager(Data[0], Data[1]);

                    value = "";
                    r = desEncryptor.DecryptText(insertClientResponse.SubsidiaryOrganizationId.ClientIdEncrypted, ref value);
                    if (!r || string.IsNullOrEmpty(value))
                    {
                        ErrorMessage = "Error decrypting client id";
                        return false;
                    }
                    client = Convert.ToInt32(value);

                    value = "";
                    r = desEncryptor.DecryptText(insertClientResponse.SubsidiaryOrganizationId.SubsidiaryIdEncrypted, ref value);
                    if (!r || string.IsNullOrEmpty(value))
                    {
                        ErrorMessage = "Error decrypting subsidiary id";
                        return false;
                    }
                    subsidiary = Convert.ToInt32(value);
                }
                else
                {
                    //Error
                    ErrorMessage = "Error inserting client: " + insertClientResponse.response.responseDescription;
                    return false;
                }
            }
            else
            {
                //Error
                ErrorMessage = "Error searching client: " + clientResponse.response.responseDescription;
                return false;
            }
            

           //save case
           //clientid,subsidiaryid,subsidiaryorgid,baselevel,branch1,branch2,branch3,branch4,branch5,isdirectsolution,guid,comments,languagecode,uploadfilesid,typystlogin
           serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters = serviceparameters + client.ToString() + subsidiary.ToString() + "0" + Id_BALE;
            serviceparameters = serviceparameters + BranchCodeTree1 + BranchCodeTree2 + BranchCodeTree3 + BranchCodeTree4 + BranchCodeTree5;
            serviceparameters = serviceparameters + "0" + guid + comments + mLanguageCode + "" + "";

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                ErrorMessage = "Error creating md5 hash";
                return false;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                ErrorMessage = "Error encrypting signature";
                return false;
            }
            //clientid,subsidiaryid,subsidiaryorgid,baselevel,branch1,branch2,branch3,branch4,branch5,isdirectsolution,guid,comments,languagecode,uploadfilesid,typystlogin
            caseResponse = ws.SaveCase(publicKey1, encryptedUser, encryptedPassword, signature, client, subsidiary, 0,
                                        Id_BALE, BranchCodeTree1, BranchCodeTree2, BranchCodeTree3, BranchCodeTree4, BranchCodeTree5,
                                        false, guid, comments, mLanguageCode, "", "");
            if (caseResponse.response.responseCode == 1)
            {
                //decrypt Case Number
                symmetrickey = RsaManager.DecryptRSA(keyPairs, caseResponse.response.encryptedSymmetrickey, ref message);
                Data = symmetrickey.Split('^');
                DesManager desEncryptor = new DesManager(Data[0], Data[1]);

                value = "";
                r = desEncryptor.DecryptText(caseResponse.caseNumber.caseNumberEncrypted, ref value);
                if (!r || string.IsNullOrEmpty(value))
                {
                    ErrorMessage = "Error decrypting case number";
                    return false;
                }
                CaseNumber = value;
                return true;
            }
            else
            {
                //Error
                ErrorMessage = "alert('Error saving case: " + caseResponse.response.responseDescription + "');";
                return false;
            }
        }

        private bool SaveChatRequest(ref string ErrorMessage, ref string RequestId, ref string encryptedRequestId, string CaseNumber)
        {
            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            //wsTPClientAPI.APIGetUserByLoginResponse userInfo;
            wsTPClientAPI.APIInsertChatRequestResponse chatRequestId;

            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters;
            DateTime RightNow = DateTime.UtcNow;
            ErrorMessage = "";
            RequestId = null;
            encryptedRequestId = null;

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                ErrorMessage = "Error creating key pairs";
                return false;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                ErrorMessage = "Error creating public key";
                return false;
            }

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                ErrorMessage = "Error encrypting user";
                return false;
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                ErrorMessage = "Error encrypting password";
                return false;
            }


            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();


            //get queue id by login
            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters += mQueueLogin;

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                ErrorMessage = "Error creating md5 hash";
                return false;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                ErrorMessage = "Error encrypting signature";
                return false;
            }

            //userInfo = ws.GetUserByLogin(publicKey1, encryptedUser, encryptedPassword, signature, mQueueLogin);
            wsTPClientAPI.APIGetChatQueuePropertiesByLoginResponse userInfo;
            userInfo = ws.GetChatQueuePropertiesByLogin(publicKey1, encryptedUser, encryptedPassword, signature, mQueueLogin);
            string json = JsonConvert.SerializeObject(userInfo);

            if (userInfo.response.responseCode == 1)
            {
                //queueID = Convert.ToInt32(userInfo.user.idGroup);
                dynamic data = JObject.Parse(userInfo.JsonChatQueueProperties);
                queueID = Convert.ToInt32(data.Id_GROU);
            }
            else
            {
                //Error
                ErrorMessage = "Error getting queue id";
                return false;
            }


            //insert chat request and redirect to router page
            //casenumber,queueid
            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters = serviceparameters + CaseNumber + queueID.ToString();
            serviceparameters = serviceparameters + nameTextBox.Text + lastNameTextBox.Text + emailTextBox.Text;
            serviceparameters += UserTimezoneOffset.Value;


            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                ErrorMessage = "Error creating md5 hash";
                return false;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                ErrorMessage = "Error encrypting signature";
                return false;
            }

            chatRequestId = ws.InsertChatRequest(publicKey1, encryptedUser, encryptedPassword, signature, Convert.ToInt32(CaseNumber), queueID, nameTextBox.Text, lastNameTextBox.Text, emailTextBox.Text, Convert.ToInt32(UserTimezoneOffset.Value));
            if (chatRequestId.response.responseCode == 1)
            {
                RightNow = DateTime.UtcNow;
                //requestid-yearutc-monthutc-dayutc-hourutc-minuteutc-secondutc
                RequestId = chatRequestId.chatRequestId.ToString();
                encryptedRequestId = RsaManager.EncryptRSA(publicKey2, chatRequestId.chatRequestId.ToString() + "-" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString() + "-" + RightNow.Second.ToString(), ref message);
                if (string.IsNullOrEmpty(encryptedRequestId))
                {
                    //Error
                    ErrorMessage = "Error encrypting chat request id";
                    return false;
                }

                return true;
            }
            else
            {
                //Error
                ErrorMessage = "Error saving chat request";
                return false;
            }
        }

        private bool UpdateChatRequestRequiresReceiveNotifications(ref string ErrorMessage, string RequestId, bool bolRequiresReceiveNotifications)
        {
            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIUpdateChatRequestRequieresReceiveNotificationResponse updateResponse;

            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters = null;
            DateTime RightNow = DateTime.UtcNow;
            ErrorMessage = "";

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                ErrorMessage = "Error creating key pairs";
                return false;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                ErrorMessage = "Error creating public key";
                return false;
            }

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                ErrorMessage = "Error encrypting user";
                return false;
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                ErrorMessage = "Error encrypting password";
                return false;
            }


            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();


            //update chat request
            //casenumber,queueid
            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters += RequestId.ToString();
            if (bolRequiresReceiveNotifications)
            {
                serviceparameters += "1";
            }
            else
            {
                serviceparameters += "0";
            }



            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                ErrorMessage = "Error creating md5 hash";
                return false;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                ErrorMessage = "Error encrypting signature";
                return false;
            }

            updateResponse = ws.UpdateChatRequestRequieresReceiveNotification(publicKey1, encryptedUser, encryptedPassword, signature,
                                                                              Convert.ToInt32(RequestId),
                                                                              bolRequiresReceiveNotifications);
            if (updateResponse.response.responseCode == 1)
            {
                return true;
            }
            else
            {
                //Error
                ErrorMessage = "Error updating chat request requires receive notifications";
                return false;
            }

        }

        public List<ListItem> GetBranchesByParent(string IdParent, string LanguageCode)
        {
            bool r;
            string Message;
            string encryptedUser;
            string encryptedPassword;
            string signature;
            string encryptedSignature;

            string idApplication;
            string md5parameters;
            string serviceparameters;
            string symmetricKey;
            string decryptedText;
            string publicKey1 = "";
            string publicKey2;
            string keyPair1 = "";
            string message = "";

            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIGetBranchesByParentResponse branches;

            System.DateTime RightNow = default(System.DateTime);

            //Get utc date and time
            RightNow = System.DateTime.UtcNow;
            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPair1, ref message);
            if (!r)
            {
                //Error
                //ErrorMessage = "Error creating key pairs";
                return null;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                //ErrorMessage = "Error creating public key";
                return null;
            }

            //encrypt user
            Message = "";
            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref Message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //MessageBox.Show("Error encrypting user error:" + Message);
                return null;
            }

            //encrypt password
            Message = "";
            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref Message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //MessageBox.Show("Error encrypting password error:" + Message);
                return null;
            }

            //compute md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px is a datetime must be converted to string using yyyy-mm-dd 24hh:mm:ss
            //if px is byte array md5_byte opperation needs to be performed (see samples)
            md5parameters = "";
            idApplication = mIdApplication;
            serviceparameters = idApplication + encryptedUser + encryptedPassword;
            //add specific parameters 
            serviceparameters = serviceparameters + IdParent + LanguageCode;

            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (r == false | string.IsNullOrEmpty(md5parameters))
            {
                // MessageBox.Show("Error creating md5 hash");
                return null;
            }

            //calculates signature
            //signature: idapplication|utcyear-utcmonth-utcday-utchour-utcminute|md5parameters
            signature = idApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString();
            signature = signature + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            signature = signature + "|" + md5parameters;

            //encrypt signature
            Message = "";
            encryptedSignature = RsaManager.EncryptRSA(publicKey2, signature, ref Message);
            if (string.IsNullOrEmpty(signature))
            {
                //MessageBox.Show("Error encrypting signature error:" + Message);
                return null;
            }
            //Call web service method

            branches = ws.GetBranchesByParent(publicKey1, encryptedUser, encryptedPassword, encryptedSignature, IdParent, LanguageCode);
            List<ListItem> lists = new List<ListItem>();

            //string json = JsonConvert.SerializeObject(branches);
            //JsonTextBox.Text = json;
            if (branches.response.responseCode == 1)
            {
                Message = "";
                symmetricKey = RsaManager.DecryptRSA(keyPair1, branches.response.encryptedSymmetrickey, ref Message);
                if ((symmetricKey == "") || (Message != ""))
                {
                    //MessageBox.Show("Error decrypting symmetric key:" + Message);
                    return null;
                }
                string[] rgbKeyAndIV = symmetricKey.Split('^');

                DesManager desEncryptor = new DesManager(rgbKeyAndIV[0], rgbKeyAndIV[1]);


                foreach (wsTPClientAPI.APIGetBranchesByParentInfo branch in branches.branches)
                {

                    if (!string.IsNullOrEmpty(branch.idBranch))
                    {

                        ListItem listItem = new ListItem
                        {
                            Text = branch.description,
                            Value = branch.idBranch
                        };
                        lists.Add(listItem);

                        //MessageBox.Show("branch " + branch.idBranch + " value=" + decryptedText);

                    }
                }
                return lists;
            }
            return null;
        }

        protected void ddlclassificationtype_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlclassificationtype.SelectedIndex == 0)
            {
                ddlsubclassificationtype.SelectedIndex = 0;
                ddlsubclassificationtype.Enabled = false;
            }
            else
            {
                ddlsubclassificationtype.Enabled = true;

                ddlsubclassificationtype.DataSource = GetBranchesByParent(ddlclassificationtype.SelectedValue, "en");
                ddlsubclassificationtype.DataTextField = "Text";
                ddlsubclassificationtype.DataValueField = "Value";
                ddlsubclassificationtype.DataBind();
                ListItem listsubClass = new ListItem("Select Sub Classification Type", "-1");
                ddlsubclassificationtype.Items.Insert(0, listsubClass);
            }
        }

        protected void requestTypeRadioButtonList_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (requestTypeRadioButtonList.SelectedItem.Text == "Urgent")
            {
                ddlsubclassificationtype.SelectedIndex = 0;
                ddlclassificationtype.SelectedIndex = 0;
                ddlclassificationtype.Enabled = false;
                ddlsubclassificationtype.Enabled = false;
                ddlsubclassificationtype.Visible = false;
                ddlclassificationtype.Visible = false;
                classID.Visible = false;
                subClassID.Visible = false;
            }
            else
            {
                ddlclassificationtype.Enabled = true;
                ddlsubclassificationtype.Visible = true;
                ddlclassificationtype.Visible = true;
                classID.Visible = true;
                subClassID.Visible = true;
            }
        }
    }
}