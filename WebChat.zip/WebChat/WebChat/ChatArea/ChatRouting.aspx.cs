﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.Services;
using System.Configuration;
using System.Collections.Generic;
using System.Security.Cryptography;

using CryptoManager;

namespace WebChat.ChatArea
{ 
    public partial class ChatRouting : Page
    {
        string userName = "";
        string userLastName = "";
        string CaseNumber = "";

        //external application parameters
        static readonly string mIdApplication = ConfigurationManager.AppSettings["EXTERNALAPPLICATION_CHAT_SAMPLE12"].ToString();
        static readonly string mUserExternalAplication = ConfigurationManager.AppSettings["USER_EXTERNALAPPLICATION_CHAT_SAMPLE12"].ToString();
        static readonly string mPasswordExternalAplication = ConfigurationManager.AppSettings["PASSWORD_EXTERNALAPPLICATION_CHAT_SAMPLE12"].ToString();
        static readonly string mLanguageCode = ConfigurationManager.AppSettings["LANGUAGECODE_CHAT_SAMPLE12"].ToString();
        //queue
        static readonly string mQueueLogin = ConfigurationManager.AppSettings["CHAT_QUEUE_LOGIN_SAMPLE12"].ToString();
        int queueID = 0;
        //context
        static readonly string mContextTPClientSite = ConfigurationManager.AppSettings["CHAT_CONTEXT_SAMPLE12"].ToString();
        //keypair for encrypting chat connection id (it also will be used on wrapper)
        static readonly string mKeypairWrapperKey = ConfigurationManager.AppSettings["WRAPPER_KEYPAIR_CHAT_SAMPLE12"].ToString();

        static string mURLSite = ConfigurationManager.AppSettings["URLChatExternalUI_SAMPLE12"];

        static readonly string TWOWAY = ConfigurationManager.AppSettings["TWOWAY_VIDEO_SAMPLE12"].ToString();
        static readonly string AUDIOONLY = ConfigurationManager.AppSettings["AUDIOONLY_SAMPLE12"].ToString();

        protected void Page_Load(object sender, EventArgs e)
        {
            string CodeJSScriptLiteral;
            bool r;
            string ErrorMessage;
            string publickey2;
            string CodeJSScript;
            string expRSA;
            string modRSA;
            string UrlCustomSite;
            string ChatType;




            //check valid requestid 
            if (!IsValidRequestId())
            {
                IsValidRequestHidden.Value = "false";
                ErrorMessage = "";
                r = GetInvalidRequestMessage(ref ErrorMessage);
                if (!r)
                {
                    InvalidChatRequestMessage_CHGRHidden.Value = "Invalid chat request...";
                }
                return;
            }
            else
            {
                IsValidRequestHidden.Value = "true";
            }

            if (!IsPostBack)
            {
                Session["webMethodsToken"] = Guid.NewGuid().ToString();
                webMethodsTokenHidden.Value = Session["webMethodsToken"].ToString();


                ErrorMessage = "";


                UrlCustomSite = HttpContext.Current.Request.Url.AbsoluteUri.Split('?')[0];

                UrlCustomSite = UrlCustomSite.Substring(0, UrlCustomSite.LastIndexOf('/'));

                urlHexTextBox.Value = HexAndBase64Helpers.BytesToHexString(System.Text.Encoding.UTF8.GetBytes(UrlCustomSite), ref ErrorMessage);

                //Get queue properties
                ErrorMessage = "";
                r = GetQueueProperties(ref ErrorMessage);
                if (!r)
                {
                    ErrorMessage = "alert('Error getting chat properties ::" + ErrorMessage + "');";
                    ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", ErrorMessage, true);
                    return;
                }
                //render User header
                UserRenderHeader_CHGRHidden.Value = userName;
                UserFirstNameTextBox.Text = userName;
                UserLastNameTextBox.Text = userLastName;

                //Get Case Properties
                r = GetCaseProperties(CaseNumber, mLanguageCode, ref ErrorMessage);
                if (!r)
                {
                    ErrorMessage = "alert('Error getting case information ::" + ErrorMessage + "');";
                    ClientScript.RegisterStartupScript(this.GetType(), "AlertScript", ErrorMessage, true);
                    return;
                }

                //rsa variables
                //write RSA variables
                wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
                publickey2 = ws.GetPublicKey();

                expRSA = GetPublicKeysRSA_Exponent(publickey2);
                modRSA = GetPublicKeyRSA_Modulus(publickey2);

                CodeJSScript = "";
                CodeJSScript = CodeJSScript + "var ExpRSATpCol='" + expRSA + "';" + Environment.NewLine;
                CodeJSScript = CodeJSScript + "var ModRSATpCol='" + modRSA + "';" + Environment.NewLine;
                CodeJSScript = CodeJSScript + "var ChallengeRSATpCol='';" + Environment.NewLine;
                ClientScript.RegisterStartupScript(this.GetType(), "RSAScript", CodeJSScript, true);

                //save urlsite

                if (!mURLSite.EndsWith("/"))
                {
                    mURLSite += "/";
                }
                //encode url
                URLSiteHidden.Value = HttpUtility.UrlEncode(mURLSite);


                //set reference to signalrhub 
                CodeJSScriptLiteral = "";
                
                
                CodeJSScriptLiteral = CodeJSScriptLiteral + "<script src='" + mURLSite + "signalr/hubs' ></script>";
               
                JSScriptsSignalRhubReferenceLiteral.Text = CodeJSScriptLiteral;

                ChatType = Request["ChatType"];
                if (string.IsNullOrEmpty(ChatType))
                {
                    ChatTypeTextBox.Value = "TEXT";
                }
                else
                {
                    if (ChatType == "VIDEO")
                    {
                        ChatTypeTextBox.Value = "VIDEO";
                    }
                    else
                    {
                        ChatTypeTextBox.Value = "TEXT";
                    }
                }

                if (AUDIOONLY == "1")
                {
                    AUDIOONLY_SAMPLE12_TEXTBOX.Value = "1";
                }
                else
                {
                    AUDIOONLY_SAMPLE12_TEXTBOX.Value = "0";
                }

                if (TWOWAY == "1")
                {
                    TWOWAY_VIDEO_SAMPLE12_TEXTBOX.Value = "1";
                }
                else
                {
                    TWOWAY_VIDEO_SAMPLE12_TEXTBOX.Value = "0";
                }               
            }
        }

        private bool IsValidRequestId()
        {
            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters;
            string ProactiveChatId;
            string symmetrickey;
            string[] Data;
            string value = null;
            string encryptedChatRequestId;
            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIIsValidChatRequestIdResponse IsValidRequestResponse;

            DateTime RightNow = DateTime.UtcNow;
            encryptedChatRequestId = "";
            if (Request["RequestId"] != null)
            {
                encryptedChatRequestId = Request["RequestId"];
            }
            if (encryptedChatRequestId == "")
            {
                return false;
            }
            ProactiveChatId = "";
            if (Request["ProactiveId"] != null)
            {
                ProactiveChatId = Request["ProactiveId"];
            }

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                return false;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                return false;
            }

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                return false;
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                return false;
            }

            //check if chatrequestid is valid

            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters = serviceparameters + encryptedChatRequestId + ProactiveChatId;

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                return false;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                return false;
            }
            IsValidRequestResponse = ws.IsValidChatRequestId(publicKey1, encryptedUser, encryptedPassword, signature, encryptedChatRequestId, ProactiveChatId);

            if (IsValidRequestResponse.response.responseCode != 1)
            {
                queueID = IsValidRequestResponse.QueueId;
                //Error
                return false;
            }
            symmetrickey = RsaManager.DecryptRSA(keyPairs, IsValidRequestResponse.response.encryptedSymmetrickey, ref message);
            Data = symmetrickey.Split('^');
            DesManager desEncryptor = new DesManager(Data[0], Data[1]);


            r = desEncryptor.DecryptText(IsValidRequestResponse.RequestIdEncrypted, ref value);
            if (!r)
            {
                //Error
                return false;
            }
            ChatRequestIdHidden.Value = value;
            r = desEncryptor.DecryptText(IsValidRequestResponse.CaseNumberEncrypted, ref value);
            if (!r)
            {
                //Error
                return false;
            }
            CaseNumber = value;
            queueID = IsValidRequestResponse.QueueId;
            //url survey
            URLSurveyHidden.Value = HttpUtility.UrlEncode(IsValidRequestResponse.URLSurvey);
            userName = IsValidRequestResponse.userName;
            userLastName = IsValidRequestResponse.userLastName;
            IsOutofScheduleHidden.Value = IsValidRequestResponse.IsOutOfSchedule.ToString();

            caseNumberTextBox.Text = CaseNumber;
            ContextTextBox.Text = mContextTPClientSite;
            QueueLoginTextBox.Text = mQueueLogin;
            if (IsValidRequestResponse.RequiresReceiveNotification)
            {
                RequiresChatNotification.Value = "true";
            }

            return true;
        }

        private string GetPublicKeysRSA_Exponent(string publickey)
        {
            CspParameters varCspParameters;
            RSAParameters varRSAParameters;
            RSACryptoServiceProvider sp;
            string Message;
            int Keysize;

            Keysize = 1024;
            varCspParameters = new CspParameters
            {
                Flags = CspProviderFlags.UseMachineKeyStore
            };
            sp = new RSACryptoServiceProvider(Keysize, varCspParameters);
            sp.FromXmlString(publickey);
            varRSAParameters = sp.ExportParameters(false);
            Message = "";
            return HexAndBase64Helpers.BytesToHexString(varRSAParameters.Exponent, ref Message);
        }

        private string GetPublicKeyRSA_Modulus(string publickey)
        {
            CspParameters varCspParameters;
            RSAParameters varRSAParameters;
            RSACryptoServiceProvider sp;
            string Message;
            int Keysize;

            Keysize = 1024;
            varCspParameters = new CspParameters
            {
                Flags = CspProviderFlags.UseMachineKeyStore
            };
            sp = new RSACryptoServiceProvider(Keysize, varCspParameters);
            sp.FromXmlString(publickey);
            varRSAParameters = sp.ExportParameters(false);
            Message = "";
            return HexAndBase64Helpers.BytesToHexString(varRSAParameters.Modulus, ref Message);
        }

        private bool GetQueueProperties(ref string ErrorMessage)
        {
            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters;
            Newtonsoft.Json.Linq.JToken objJson;
            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIGetChatQueuePropertiesByIdResponse ChatPropertiesResponse;

            DateTime RightNow = DateTime.UtcNow;
            ErrorMessage = "";

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                ErrorMessage = "Error creating key pairs";
                return false;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                ErrorMessage = "Error creating public key";
                return false;
            }

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                ErrorMessage = "Error encrypting user";
                return false;
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                ErrorMessage = "Error encrypting password";
                return false;
            }
            
            //Get proeprties for current chat queue

            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters += queueID.ToString();

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                ErrorMessage = "Error creating md5 hash";
                return false;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                ErrorMessage = "Error encrypting signature";
                return false;
            }

            

            ChatPropertiesResponse = ws.GetChatQueuePropertiesById(publicKey1, encryptedUser, encryptedPassword, signature, queueID);
            if (ChatPropertiesResponse.response.responseCode != 1)
            {
                //Error
                ErrorMessage = "Error getting chat properties:" + ChatPropertiesResponse.response.responseDescription;
                return false;
            }

            objJson = Newtonsoft.Json.Linq.JToken.Parse(ChatPropertiesResponse.JsonChatQueueProperties);

            
            Id_GROUHidden.Value = objJson["Id_GROU"].ToString();
            //"Language_CHGR": "en",  
            Language_CHGRHidden.Value = objJson["Language_CHGR"].ToString();
            //"ReturnURL_CHGR": "http://localhost/TPClientCustomDemo/CHAT/ACMEReturnPageChatSample.aspx",  **DEPRECATED**
            //"RoutingSearchAvailAgentMessage_CHGR": "Searching for an available CSR",  
            RoutingSearchAvailAgentMessage_CHGRHidden.Value = objJson["RoutingSearchAvailAgentMessage_CHGR"].ToString();
            //"ShowQueuePosition_CHGR": true,  
            ShowQueuePosition_CHGRHidden.Value = objJson["ShowQueuePosition_CHGR"].ToString();
            //"RoutingQueuePositionMessage_CHGR": "Queue position:",  
            RoutingQueuePositionMessage_CHGRHidden.Value = objJson["RoutingQueuePositionMessage_CHGR"].ToString();
            
            //ExpectedWaitTimeMessage_CHGE
            ExpectedWaitTimeMessage_CHGEHidden.Value= objJson["ExpectedWaitTimeMessage_CHGE"].ToString();

            //"OfferStillWait_CHGR": true,
            OfferStillWait_CHGRHidden.Value = objJson["OfferStillWait_CHGR"].ToString();
            //"DelayBeforeOfferWaitSeconds_CHGR": 40,  
            DelayBeforeOfferWaitSeconds_CHGRHidden.Value = objJson["DelayBeforeOfferWaitSeconds_CHGR"].ToString();
            //"StillWaitMessage_CHGR": "I wish to wait and continue searching for an agent",  
            StillWaitMessage_CHGRHidden.Value = objJson["StillWaitMessage_CHGR"].ToString();
            //"DontWaitMessage_CHGR": "I don't want to wait. Contact me by Email",  
            DontWaitMessage_CHGRHidden.Value = objJson["DontWaitMessage_CHGR"].ToString();
            //"SendButtonMessage_CHGR": "Send",  
            SendButtonMessage_CHGRHidden.Value = objJson["SendButtonMessage_CHGR"].ToString();
            //"EndButtonMessage_CHGR": "End", 
            EndButtonMessage_CHGRHidden.Value = objJson["EndButtonMessage_CHGR"].ToString();
            //"AgentIsTypingMessage_CHGR": "Agent is typing a message", 
            AgentIsTypingMessage_CHGRHidden.Value = objJson["AgentIsTypingMessage_CHGR"].ToString();
            //"UserRenderHeader_CHGR": "[CustomerFirstName] -",
            UserRenderHeader_CHGRHidden.Value = objJson["UserRenderHeader_CHGR"].ToString();
            //"AgentRenderHeader_CHGR": "[UserFirstNameSession] - ",  not needed
            //"SLAPercent_CHGR": 80,  not needed
            //"SLASeconds_CHGR": 60,   not needed
            //"ShowSendTranscript_CHGR": true,
            ShowSendTranscript_CHGRHidden.Value = objJson["ShowSendTranscript_CHGR"].ToString();
            //"SendEmailButtonMessage_CHGR": "Send by Email",  
            SendEmailButtonMessage_CHGRHidden.Value = objJson["SendEmailButtonMessage_CHGR"].ToString();
            //"EmailTranscriptMailbox_idAccount_MAAC": "OUTMAIL2",  not needed
            //"SubjectEmailTranscript_CHGR": "Chat conversation Transcript",   not needed
            //"SuccessSendEmailTranscriptMessage_CHGR": "Your transcript conversation should arrive shortly, please check your email.",  
            SuccessSendEmailTranscriptMessage_CHGRHidden.Value = objJson["SuccessSendEmailTranscriptMessage_CHGR"].ToString();
            //"FailSendEmailTranscriptMessage_CHGR": "Error processing your request to send chat transcript.", 
            FailSendEmailTranscriptMessage_CHGRHidden.Value = objJson["FailSendEmailTranscriptMessage_CHGR"].ToString();
            //"HeaderEmailTranscript_CHGR": "This is the transcript of your recent chat conversation.",  not needed
            //"FooterEmailTranscript_CHGR": "This is a automatically generated email please do not  reply.",  not needed
            //"WelcomeMessage_CHGR": "Welcome to customer service",  
            WelcomeMessage_CHGRHidden.Value = objJson["WelcomeMessage_CHGR"].ToString();
            //"YellowThresholdSeconds_CHGR": 30,  not needed
            //"RedThresholdSeconds_CHGR": 90,  not needed
            //"TransferedMessage_CHGR": "Your conversation has been transferred",  
            TransferredMessage_CHGRHidden.Value = objJson["TransferedMessage_CHGR"].ToString();
            //"InvalidChatRequestMessage_CHGR": "Invalid Chat Request",
            InvalidChatRequestMessage_CHGRHidden.Value = objJson["InvalidChatRequestMessage_CHGR"].ToString();
            //"CurrentDialogTabMesage_CHGR": "Current Dialog",  
            CurrentDialogTabMesage_CHGRHidden.Value = objJson["CurrentDialogTabMesage_CHGR"].ToString();
            //"PreviousDialogTabMesage_CHGR": "Previous Dialogs",  
            PreviousDialogTabMesage_CHGRHidden.Value = objJson["PreviousDialogTabMesage_CHGR"].ToString();
            //"RSAPublicKey_CHGR":  not needed
            //"InitialClassifier_Id_WSCL": "INITIALCLASSIFIER",  not needed
            //"FinalClassifier_Id_WSCL": "REQUESTNOCONNECTED",  not needed
            //"AbandonThreshold_CHGR": 10,  not needed
            //"MustReclassifyChat_CHGR": 0/1/2,  not needed
            //"IsActiveProactiveChat_CHGR": true,  not needed
            //"ProactiveChatTimeOffer_CHGR": 5,  not needed
            //"ProactiveChatMinAgents_CHGR": 1,  not needed
            //"EnableVideoChat_CHGR": true,  
            EnableVideoChat_CHGRHidden.Value = objJson["EnableVideoChat_CHGR"].ToString();
            //"EnableViewDesktop_CHGR": true, not needed  
            //"ViewDesktopOfferQuestion_CHGR": "Agent is requesting to view your desktop. If you agree to share it, you can stop at any moment pressing the Stop button.",  
            ViewDesktopOfferQuestion_CHGRHidden.Value = objJson["ViewDesktopOfferQuestion_CHGR"].ToString();
            //"ViewDesktopOfferAcceptButtonMessage_CHGR": "Yes - I Allow",  
            ViewDesktopOfferAcceptButtonMessage_CHGRHidden.Value = objJson["ViewDesktopOfferAcceptButtonMessage_CHGR"].ToString();
            //"ViewDesktopOfferRejectButtonMessage_CHGR": "No - I Reject",  
            ViewDesktopOfferRejectButtonMessage_CHGRHidden.Value = objJson["ViewDesktopOfferRejectButtonMessage_CHGR"].ToString();
            //"ViewDesktopInstructions_CHGR": "SCREEN SHARING PROCESS - READ ME FIRST\r\n\r\n1. This process will download and run an exe file on your computer, without installing or registering anything.\r\n\r\n2. Press the Run button at the bottom of this screen\r\n\r\n3. When your browser prompts you, select Run (or Save if Run doesn't show)\r\n\r\n4. If the file does not run automatically, double-click on the file in the download list\r\n\r\n5. When the User Account Control window requests your permission, answer Yes\r\n\r\n6. Close this help window to continue chatting.\r\n", 
            ViewDesktopInstructions_CHGRHidden.Value = objJson["ViewDesktopInstructions_CHGR"].ToString();
            //"ViewDesktopRunButtonMessage_CHGR": "Run",  
            ViewDesktopRunButtonMessage_CHGRHidden.Value = objJson["ViewDesktopRunButtonMessage_CHGR"].ToString();
            //"EnableViewCountDown_CHGR": false,  not needed
            //"UseTPClientSurvey_CHGR": true,  
            UseTPClientSurvey_CHGRHidden.Value = objJson["UseTPClientSurvey_CHGR"].ToString();
            //"TPClientSurveyCode_CHGR": "en/SURV1",  
            TPClientSurveyCode_CHGRHidden.Value = objJson["TPClientSurveyCode_CHGR"].ToString();
            //"ExternalSurveyURL_CHGR": null,  
            ExternalSurveyURL_CHGRHidden.Value = HttpUtility.UrlEncode(objJson["ExternalSurveyURL_CHGR"].ToString());
            //"ExternalURLOutOfSchedule_CHGR": "http://localhost/TPClientCustomDemo/CHAT/ACMEReturnPageChatSample.aspx",  
            ExternalURLOutOfSchedule_CHGRHidden.Value = HttpUtility.UrlEncode(objJson["ExternalURLOutOfSchedule_CHGR"].ToString());
            //"MessageWhenNoExternalURLOutOfSchedule_CHGR": null
            MessageWhenNoExternalURLOutOfSchedule_CHGRHidden.Value = objJson["MessageWhenNoExternalURLOutOfSchedule_CHGR"].ToString();
            //,"TimeoutMinutesNoConnection_CHGR":60,
            TimeoutMinutesNoConnection_CHGRHidden.Value = objJson["TimeoutMinutesNoConnection_CHGR"].ToString();
            //"TimeOutMessage_CHGR":"Timeout trying to connect an agent...",
            TimeOutMessage_CHGRHidden.Value = objJson["TimeOutMessage_CHGR"].ToString();
            
            EmailClassifier_ID_WSCLHidden.Value = objJson["EmailClassifier_ID_WSCL"].ToString();
            //AgentCanReceiveFiles_Hidden
            AgentCanReceiveFiles_Hidden.Value = objJson["AgentCanReceiveFiles_CHGE"].ToString().ToLower();
            //PlayReceiveMessageSoundHidden
            PlayReceiveMessageSoundHidden.Value= objJson["AllowToPlaySoundIncomingMessage_CHGE"].ToString().ToLower();


            return true;
        }

        private bool GetInvalidRequestMessage(ref string ErrorMessage)
        {
            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters;
            Newtonsoft.Json.Linq.JToken objJson;
            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIGetChatQueuePropertiesByIdResponse ChatPropertiesResponse;

            DateTime RightNow = DateTime.UtcNow;
            ErrorMessage = "";

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                ErrorMessage = "Error creating key pairs";
                return false;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                ErrorMessage = "Error creating public key";
                return false;
            }

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                ErrorMessage = "Error encrypting user";
                return false;
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                ErrorMessage = "Error encrypting password";
                return false;
            }
            
            //Get proeprties for current chat queue

            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters += queueID.ToString();

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                ErrorMessage = "Error creating md5 hash";
                return false;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                ErrorMessage = "Error encrypting signature";
                return false;
            }

            ChatPropertiesResponse = ws.GetChatQueuePropertiesById(publicKey1, encryptedUser, encryptedPassword, signature, queueID);
            if (ChatPropertiesResponse.response.responseCode != 1)
            {
                //Error
                ErrorMessage = "Error getting chat properties:" + ChatPropertiesResponse.response.responseDescription;
                return false;
            }

            objJson = Newtonsoft.Json.Linq.JToken.Parse(ChatPropertiesResponse.JsonChatQueueProperties);
            InvalidChatRequestMessage_CHGRHidden.Value = objJson["InvalidChatRequestMessage_CHGR"].ToString();
            return true;
        }

        private bool GetCaseProperties(string pCaseNumber, string pLanguageCode, ref string ErrorMessage)
        {
            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters;
            long CaseNumberLong;
            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIGetCaseInfoResponse CaseInfoResponse;

            DateTime RightNow = DateTime.UtcNow;
            ErrorMessage = "";

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                ErrorMessage = "Error creating key pairs";
                return false;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                ErrorMessage = "Error creating public key";
                return false;
            }

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                ErrorMessage = "Error encrypting user";
                return false;
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                ErrorMessage = "Error encrypting password";
                return false;
            }
            
            //Get proeprties for current chat queue

            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters = serviceparameters + pCaseNumber.ToString() + pLanguageCode;

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                ErrorMessage = "Error creating md5 hash";
                return false;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                ErrorMessage = "Error encrypting signature";
                return false;
            }
            
            CaseNumberLong = Convert.ToInt64(pCaseNumber);

            CaseInfoResponse = ws.GetCaseInfo(publicKey1, encryptedUser, encryptedPassword, signature, CaseNumberLong, pLanguageCode);
            if (CaseInfoResponse.response.responseCode != 1)
            {
                //Error
                ErrorMessage = "Error getting case properties:" + CaseInfoResponse.response.responseDescription;
                return false;
            }
            caseCommentsTextBox.Text = CaseInfoResponse.CaseInfo.Comments;
            return true;
        }

        [WebMethod(EnableSession = true)]
        public static string GetHistoryChatFromTPClientSite(string SearchCriteriaFilter, string HistoryOption, string encRequestNumberOrCaseNumberOrConnectionNumber,string webmethodSecurityToken  )
        {
            bool r;
            string ErrorMessage;
            List<wsTPClientAPI.APIChatHistoryInfo> HistoryResults;
            string html = "";

            ErrorMessage = "";
            HistoryResults = null;

            if (HttpContext.Current.Session["webMethodsToken"]==null )
            {
                return html;
            }
            if ( HttpContext.Current.Session["webMethodsToken"].ToString().Trim()=="")
            {
                return html;
            }
            if (HttpContext.Current.Session["webMethodsToken"].ToString()!= webmethodSecurityToken)
            {
                return html;
            }


            r = GetHistory(SearchCriteriaFilter, HistoryOption, encRequestNumberOrCaseNumberOrConnectionNumber, ref HistoryResults, ref ErrorMessage);
            if (r)
            {
                html = "<ul style='overflow-y: auto;list-style-type: none;>";
                foreach (wsTPClientAPI.APIChatHistoryInfo historyitem in HistoryResults)
                {
                    if (historyitem.ChatPart == "A")
                    {
                        html = html + "<li class='liagentsaid'><span class='agentSaid'>" + Microsoft.Security.Application.Sanitizer.GetSafeHtmlFragment(historyitem.ChatPartName) + "</span></li>";
                        html += "<li class='triangle-isosceles2'>";
                        html = html + "<span class='agentText'>" + Microsoft.Security.Application.Sanitizer.GetSafeHtmlFragment(historyitem.ChatText.Replace(System.Environment.NewLine, "<br/>")) + "</span>";
                        html += "</li>";
                    }
                    else
                    {
                        html = html + "<li class='liusersaid><span class='userSaid'>" + Microsoft.Security.Application.Sanitizer.GetSafeHtmlFragment(historyitem.ChatPartName) + "</span></li>";
                        html += "<li class='triangle-isosceles'>";
                        html = html + "<span class='userText'>" + Microsoft.Security.Application.Sanitizer.GetSafeHtmlFragment(historyitem.ChatText.Replace(System.Environment.NewLine, "<br/>")) + "</span>";
                        html += "</li>";
                    }
                }
                html += "</ul>";
            }
            return html;
        }

        private static bool GetHistory(string SearchCriteriaFilter, string HistoryOption, string encRequestNumberOrCaseNumberOrConnectionNumber, ref List<wsTPClientAPI.APIChatHistoryInfo> HistoryResults, ref string ErrorMessage)
        {
            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters;
            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIGetHistoryChatResponse ChatHistoryInfoResponse;

            DateTime RightNow = DateTime.UtcNow;
            ErrorMessage = "";
            HistoryResults = null;

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                ErrorMessage = "Error creating key pairs";
                return false;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                ErrorMessage = "Error creating public key";
                return false;
            }

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                ErrorMessage = "Error encrypting user";
                return false;
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                ErrorMessage = "Error encrypting password";
                return false;
            }

            //Get chat history

            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters = serviceparameters + SearchCriteriaFilter + HistoryOption + encRequestNumberOrCaseNumberOrConnectionNumber;

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                ErrorMessage = "Error creating md5 hash";
                return false;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                ErrorMessage = "Error encrypting signature";
                return false;
            }

            ChatHistoryInfoResponse = ws.GetHistoryChat(publicKey1, encryptedUser, encryptedPassword, signature, SearchCriteriaFilter, HistoryOption, encRequestNumberOrCaseNumberOrConnectionNumber);
            if (ChatHistoryInfoResponse.response.responseCode != 1)
            {
                //Error
                ErrorMessage = "Error getting chat history:" + ChatHistoryInfoResponse.response.responseDescription;
                return false;
            }
            HistoryResults = new List<wsTPClientAPI.APIChatHistoryInfo>();
            foreach (wsTPClientAPI.APIChatHistoryInfo historyitem in ChatHistoryInfoResponse.History)
            {
                HistoryResults.Add(historyitem);
            }
            return true;
        }

        [WebMethod(EnableSession = true)]
        public static string ReclassifyChatRequestToBeContactedByMail(string chatRequestId, string webmethodSecurityToken)
        {
            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters;
            if (HttpContext.Current.Session["webMethodsToken"] == null)
            {
                return "Invalid Data1";
            }
            if (HttpContext.Current.Session["webMethodsToken"].ToString().Trim() == "")
            {
                return "Invalid Data2";
            }
            if (HttpContext.Current.Session["webMethodsToken"].ToString() != webmethodSecurityToken)
            {
                return "Invalid Data3";
            }

            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIReclassifyChatRequestToBeContactedByMailResponse ReclassifyChatResponse;

            DateTime RightNow = DateTime.UtcNow;

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                return "Error creating key pairs";
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                return "Error creating public key";
            }

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                return "Error encrypting user";
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                return "Error encrypting password";
            }

            //Reclassify chat

            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters += chatRequestId;

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                return "Error creating md5 hash";
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                return "Error encrypting signature";
            }

            ReclassifyChatResponse = ws.ReclassifyChatRequestToBeContactedByMail(publicKey1, encryptedUser, encryptedPassword, signature, Convert.ToInt32(chatRequestId));
            if (ReclassifyChatResponse.response.responseCode != 1)
            {
                //Error
                return "Error reclassifying chat :" + ReclassifyChatResponse.response.responseDescription;
            }

            return "SUCCESS";
        }

        [WebMethod(EnableSession = true)]
        public static string EncryptChatConnection(string chatConnectionId, string webmethodSecurityToken)
        {
            string errorMessage;
            string Keypair;
            byte[] data;
            string encrypted;
            string publickey;
            String Nonce;
            Boolean r;

            if (HttpContext.Current.Session["webMethodsToken"] == null)
            {
                return "";
            }
            if (HttpContext.Current.Session["webMethodsToken"].ToString().Trim() == "")
            {
                return "";
            }
            if (HttpContext.Current.Session["webMethodsToken"].ToString() != webmethodSecurityToken)
            {
                return "";
            }

            errorMessage = "";
            data = HexAndBase64Helpers.HexStringToBytes(mKeypairWrapperKey, ref errorMessage);
            if (errorMessage != "")
            {
                return "";
            }
            Keypair = System.Text.Encoding.UTF8.GetString(data);

            publickey = "";
            errorMessage = "";

            r = GetPublicKeyFromKeypair(ref publickey, Keypair, ref errorMessage);
            if ((errorMessage != "") || (!r) || (publickey == ""))
            {
                return "";
            }

            errorMessage = "";
            encrypted = RsaManager.EncryptRSA(publickey, chatConnectionId, ref errorMessage);
            if ((errorMessage != "") || (encrypted == ""))
            {
                return "";
            }
            Nonce = MemoryCollections.Add();

            return encrypted + "|" + Nonce;
        }

        private static Boolean GetPublicKeyFromKeypair(ref string publickey, string keypair, ref string ErrorMessage)
        {
            ErrorMessage = "";
            publickey = "";
            try
            {
                CspParameters cspParameter;
                cspParameter = new CspParameters
                {
                    Flags = CspProviderFlags.UseMachineKeyStore
                };
                RSACryptoServiceProvider sp;
                sp = new RSACryptoServiceProvider(2048, cspParameter);
                sp.FromXmlString(keypair);
                publickey = sp.ToXmlString(false);
                return true;
            }
            catch (Exception ex)
            {
                ErrorMessage = ex.Message.ToString();
                return false;
            }
        }

        public class LoadExternalFilesResultsInfo
        {
            public string Id { get; set; }
            public string ExternalFileType { get; set; }
            public string AttachmentFilename { get; set; }
            public string FileExtension { get; set; }
        }

        [WebMethod(EnableSession = true)]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Style", "IDE0060:Remove unused parameter", Justification = "<Pending>")]
        public static List<LoadExternalFilesResultsInfo> LoadExternalFiles(string[] IdFinalArray,string[] TypeFinalArray, string webmethodSecurityToken)
        {
            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters = null;
            List<LoadExternalFilesResultsInfo> ResultList = new List<LoadExternalFilesResultsInfo>();
            int i;
            string Serverpath = HttpContext.Current.Server.MapPath("Upload");

            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIGetChatFileByGuidResponse oneChatFileInfo;

            DateTime RightNow = DateTime.UtcNow;


            if (HttpContext.Current.Session["webMethodsToken"] == null)
            {
                return null;
            }
            if (HttpContext.Current.Session["webMethodsToken"].ToString().Trim() == "")
            {
                return null;
            }
            if (HttpContext.Current.Session["webMethodsToken"].ToString() != webmethodSecurityToken)
            {
                return null;
            }

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                return null;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                return null;
            }

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                return null;
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                return null;
            }
            for(i=0;i<= IdFinalArray.Length-1;i++)
            {
                //get chat file

                //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
                //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
                //if px not exists md5 finish after EncryptedPassword
                //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
                appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

                serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
                serviceparameters += IdFinalArray[i];

                md5parameters = "";
                r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
                if (!r || string.IsNullOrEmpty(md5parameters))
                {
                    //Error
                    return null;
                }

                signature = appSignature + "|" + md5parameters;

                signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
                if (string.IsNullOrEmpty(signature))
                {
                    //Error
                    return null;
                }

                oneChatFileInfo = ws.GetChatFileByGuid(publicKey1, encryptedUser, encryptedPassword, signature, IdFinalArray[i]);
                if (oneChatFileInfo.response.responseCode!=1)
                {
                    //Error
                    return null;
                }
                if (oneChatFileInfo.filetype=="image")
                {
                    System.IO.File.WriteAllBytes(System.IO.Path.Combine(Serverpath, "image" + IdFinalArray[i] + ".png"),oneChatFileInfo.FileBytes);
                    LoadExternalFilesResultsInfo oneresult = new LoadExternalFilesResultsInfo
                    {
                        ExternalFileType = "image",
                        Id = IdFinalArray[i]
                    };
                    ResultList.Add(oneresult);
                }
                if (oneChatFileInfo.filetype == "video")
                {
                    System.IO.File.WriteAllBytes(System.IO.Path.Combine(Serverpath, "video" + IdFinalArray[i] + ".mp4"), oneChatFileInfo.FileBytes);
                    LoadExternalFilesResultsInfo oneresult = new LoadExternalFilesResultsInfo
                    {
                        ExternalFileType = "video",
                        Id = IdFinalArray[i]
                    };
                    ResultList.Add(oneresult);
                }
                if (oneChatFileInfo.filetype == "audio")
                {
                    System.IO.File.WriteAllBytes(System.IO.Path.Combine(Serverpath, "audio" + IdFinalArray[i] + ".mp4"), oneChatFileInfo.FileBytes);
                    LoadExternalFilesResultsInfo oneresult = new LoadExternalFilesResultsInfo
                    {
                        ExternalFileType = "audio",
                        Id = IdFinalArray[i]
                    };
                    ResultList.Add(oneresult);
                }
                if (oneChatFileInfo.filetype == "file")
                {
                    System.IO.File.WriteAllBytes(System.IO.Path.Combine(Serverpath, "file" + IdFinalArray[i] + System.IO.Path.GetExtension(oneChatFileInfo.filename)), oneChatFileInfo.FileBytes);
                    LoadExternalFilesResultsInfo oneresult = new LoadExternalFilesResultsInfo
                    {
                        ExternalFileType = "file",
                        Id = IdFinalArray[i],
                        AttachmentFilename = oneChatFileInfo.filename,
                        FileExtension = System.IO.Path.GetExtension(oneChatFileInfo.filename)
                    };
                    ResultList.Add(oneresult);
                }
            }
            return ResultList;
        }


        [WebMethod(EnableSession = true)]
        public static string KillChatRequest(string Id_CHRE,  string webmethodSecurityToken)
        {
            string result = "0";

            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters;
            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIKillChatRequestResponse oneKillChatRequestResponse;

            DateTime RightNow = DateTime.UtcNow;
            if (HttpContext.Current.Session["webMethodsToken"] == null)
            {
                return result;
            }
            if (HttpContext.Current.Session["webMethodsToken"].ToString().Trim() == "")
            {
                return result;
            }
            if (HttpContext.Current.Session["webMethodsToken"].ToString() != webmethodSecurityToken)
            {
                return result;
            }

            //Key pair
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                return result;
            }

            //Public key
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                return result;
            }

            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                return result;
            }

            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                return result;
            }

            //Kill Chat Request

            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;
            serviceparameters += Id_CHRE;

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                return result;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                return result;
            }

            oneKillChatRequestResponse = ws.KillChatRequest(publicKey1, encryptedUser, encryptedPassword, signature, Convert.ToInt32(Id_CHRE));
            if (oneKillChatRequestResponse.response.responseCode != 1)
            {
                //Error
                return result;
            }
            result = "1";
            return result;
        }

    }
}