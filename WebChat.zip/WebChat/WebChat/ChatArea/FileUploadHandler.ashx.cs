﻿/// <summary>
/// Summary description for FileUploadHandler
/// </summary>
using System;

using System.Linq;
using System.Web;
using System.Configuration;
using System.IO;

using CryptoManager;
using System.Diagnostics;

namespace WebChat.ChatArea
{
    /// <summary>
    /// Summary description for FileUploadHandler
    /// </summary>
    public class FileUploadHandler : IHttpHandler
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Security", "SCS0029:Potential XSS vulnerability", Justification = "<Pending>")]
        public void ProcessRequest(HttpContext context)
        {
            string fileguid;
            string FileTypeTPClient;
            string CaseNumber;

            bool FileSavedOnTPClient;

            FileSavedOnTPClient = false;
            FileTypeTPClient = "file";
            fileguid = Guid.NewGuid().ToString();

            context.Response.AddHeader("Vary", "Accept");
            context.Response.ContentType = "text/plain";
            try
            {
                if (context.Request.QueryString["upload"] != null)
                {
                    CaseNumber = context.Request.QueryString["CaseNumber"];
                    string Serverpath = HttpContext.Current.Server.MapPath("Upload");

                    var postedFile = context.Request.Files[0];
                    int fileSize = postedFile.ContentLength;
                    string file;
                    string newFile;

                    byte[] fileBytes;
                    byte[] tmpBytes;
                    bool r;

                    //string fileDirectory;
                    string ext;
                    string onlyfilename;

                    //check security
                    if (!CheckSecurity())
                    {
                        context.Response.Write("Access Denied");
                        return;
                    }

                    if (!Directory.Exists(Serverpath))
                    {
                        Directory.CreateDirectory(Serverpath);
                    }


                    if (context.Request.QueryString["IsAudioRecorded"] == null)
                    {
                        //For IE to get file name
                        if (HttpContext.Current.Request.Browser.Browser.ToUpper() == "IE")
                        {
                            string[] files = postedFile.FileName.Split(new char[] { '\\' });
                            file = files[files.Length - 1];
                        }
                        else
                        {
                            file = postedFile.FileName;
                        }


                        //fileDirectory = Serverpath;
                        if (context.Request.QueryString["fileName"] != null)
                        {
                            file = context.Request.QueryString["fileName"];
                        }

                        ext = Path.GetExtension(file).ToLower();
                        onlyfilename = Path.GetFileNameWithoutExtension(file).ToLower();

                        newFile = fileguid + ext;

                        //fileDirectory = GetFileDirectory(Serverpath, newFile);
                        //fileDirectory = Path.Combine(Serverpath, newFile);
                        postedFile.SaveAs(GetFileDirectory(Serverpath, newFile));

                        //fileBytes = System.IO.File.ReadAllBytes(GetFileDirectory(Serverpath, newFile));
                        fileBytes = GetBytes(GetFileDirectory(Serverpath, newFile));
                    }
                    else
                    {
                        ext = ".wav";
                        onlyfilename = "recordedaudio";
                        file = "recordedaudio.wav";

                        newFile = fileguid + ext;
                        //fileDirectory = Serverpath + "\\" + newFile;
                        postedFile.SaveAs(GetFileDirectory(Serverpath, newFile));

                        //fileBytes = System.IO.File.ReadAllBytes(GetFileDirectory(Serverpath, newFile));
                        fileBytes = GetBytes(GetFileDirectory(Serverpath, newFile));

                    }

                    if (ext == ".jpg" || ext == ".jpeg" || ext == ".png")
                    {
                        if (fileSize < (5000 * 1024))
                        {
                            tmpBytes = ConvertToPNG(fileBytes, Serverpath, newFile, fileguid);
                            if (tmpBytes == null)
                            {
                                //fail to convert to png. save as file
                                r = SaveAttachmentTPClient(CaseNumber, file, newFile, fileBytes, fileguid, FileTypeTPClient);
                                if (r)
                                {
                                    FileSavedOnTPClient = true;
                                }
                            }
                            else
                            {
                                //save as image
                                FileTypeTPClient = "image";
                                r = SaveAttachmentTPClient(CaseNumber, onlyfilename + ".png", fileguid + ".png", tmpBytes, fileguid, FileTypeTPClient);
                                if (r)
                                {
                                    FileSavedOnTPClient = true;
                                }
                            }
                        }
                    }

                    switch (ext)
                    {
                        ////detect image types
                        //case ".jpg":
                        //case ".jpeg":
                        //case ".png":
                        //case ".bmp":
                        //case ".gif":
                        //    tmpBytes = ConvertToPNG(fileBytes, Serverpath, newFile, fileguid);
                        //    if (tmpBytes == null)
                        //    {
                        //        //fail to convert to png. save as file
                        //        r = SaveAttachmentTPClient(CaseNumber, file, newFile, fileBytes, fileguid, FileTypeTPClient);
                        //        if (r)
                        //        {
                        //            FileSavedOnTPClient = true;
                        //        }
                        //    }
                        //    else
                        //    {
                        //        //save as image
                        //        FileTypeTPClient = "image";
                        //        r = SaveAttachmentTPClient(CaseNumber, onlyfilename + ".png", fileguid + ".png", tmpBytes, fileguid, FileTypeTPClient);
                        //        if (r)
                        //        {
                        //            FileSavedOnTPClient = true;
                        //        }
                        //    }
                        //    break;
                        //case ".mp3":
                        case ".wav":
                            //check if has audio tracks
                            if (HasAudioTracks(Serverpath, newFile))
                            {
                                tmpBytes = ConvertAudio_ACC(Serverpath, newFile, fileguid);
                                if (tmpBytes == null)
                                {
                                    //transcoding fail save as file
                                    r = SaveAttachmentTPClient(CaseNumber, file, newFile, fileBytes, fileguid, FileTypeTPClient);
                                    if (r)
                                    {
                                        FileSavedOnTPClient = true;
                                    }
                                }
                                else
                                {
                                    //save as audio
                                    FileTypeTPClient = "audio";
                                    r = SaveAttachmentTPClient(CaseNumber, onlyfilename + ".mp4", fileguid + ".mp4", tmpBytes, fileguid, FileTypeTPClient);
                                    if (r)
                                    {
                                        FileSavedOnTPClient = true;
                                    }
                                }
                            }
                            else
                            {
                                //not audio but has the extension. save as file
                                r = SaveAttachmentTPClient(CaseNumber, file, newFile, fileBytes, fileguid, FileTypeTPClient);
                                if (r)
                                {
                                    FileSavedOnTPClient = true;
                                }
                            }
                            break;
                        //case ".mp4":
                        //    //check if has video tracks
                        //    if (HasVideoTracks(Serverpath, newFile))
                        //    {
                        //        //transcoding to h2644 video and acc audio for mp4 format
                        //        tmpBytes = ConvertVideoH264_ACC(Serverpath, newFile, fileguid);
                        //        if (tmpBytes == null)
                        //        {
                        //            //transcoding fail save as file
                        //            r = SaveAttachmentTPClient(CaseNumber, file, newFile, fileBytes, fileguid, FileTypeTPClient);
                        //            if (r)
                        //            {
                        //                FileSavedOnTPClient = true;
                        //            }
                        //        }
                        //        else
                        //        {
                        //            //save as video
                        //            FileTypeTPClient = "video";
                        //            r = SaveAttachmentTPClient(CaseNumber, onlyfilename + ".mp4", fileguid + ".mp4", tmpBytes, fileguid, FileTypeTPClient);
                        //            if (r)
                        //            {
                        //                FileSavedOnTPClient = true;
                        //            }
                        //        }
                        //    }
                        //    else
                        //    {
                        //        //check if has audio tracks
                        //        if (HasAudioTracks(Serverpath, newFile))
                        //        {
                        //            tmpBytes = ConvertAudio_ACC(Serverpath, newFile, fileguid);
                        //            if (tmpBytes == null)
                        //            {
                        //                //transcoding fail save as file
                        //                r = SaveAttachmentTPClient(CaseNumber, file, newFile, fileBytes, fileguid, FileTypeTPClient);
                        //                if (r)
                        //                {
                        //                    FileSavedOnTPClient = true;
                        //                }
                        //            }
                        //            else
                        //            {
                        //                //save as audio
                        //                FileTypeTPClient = "audio";
                        //                r = SaveAttachmentTPClient(CaseNumber, onlyfilename + ".mp4", fileguid + ".mp4", tmpBytes, fileguid, FileTypeTPClient);
                        //                if (r)
                        //                {
                        //                    FileSavedOnTPClient = true;
                        //                }
                        //            }
                        //        }
                        //        else
                        //        {
                        //            //not video and not audio but has the extension. save as file
                        //            r = SaveAttachmentTPClient(CaseNumber, file, newFile, fileBytes, fileguid, FileTypeTPClient);
                        //            if (r)
                        //            {
                        //                FileSavedOnTPClient = true;
                        //            }
                        //        }
                        //    }
                        //    break;
                        default:
                            //save as file
                            r = SaveAttachmentTPClient(CaseNumber, file, newFile, fileBytes, fileguid, FileTypeTPClient);
                            if (r)
                            {
                                FileSavedOnTPClient = true;
                            }
                            break;
                    }

                    //send response back
                    if (FileSavedOnTPClient)
                    {
                        if (FileTypeTPClient == "image")
                        {
                            context.Response.Write("Success:" + FileTypeTPClient + ":" + fileguid + ":.png" + ":" + file);
                        }
                        if ((FileTypeTPClient == "video") || (FileTypeTPClient == "audio"))
                        {
                            context.Response.Write("Success:" + FileTypeTPClient + ":" + fileguid + ":.mp4" + ":" + file);
                        }
                        if (FileTypeTPClient == "file")
                        {
                            context.Response.Write("Success:" + FileTypeTPClient + ":" + fileguid + ":" + ext + ":" + file);
                        }
                    }
                    else
                    {
                        context.Response.Write("Error");
                    }
                }
            }
            catch (Exception ex)
            {
                context.Response.Write("Exception " + ex.Message);
            }
        }

        public static string GetFileDirectory(string serverPath, string fileName)
        {
            string fileDirectory = Path.Combine(serverPath, fileName);
            return fileDirectory;
        }

        public static byte[] GetBytes(string byteSample)
        {
            byte[] fileBytes = System.IO.File.ReadAllBytes(byteSample);
            return fileBytes;
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

        private bool CheckSecurity()
        {
            bool result;
            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIGetChatQueuePropertiesByLoginResponse ChatPropertiesResponse;

            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string mIdApplication = ConfigurationManager.AppSettings["EXTERNALAPPLICATION_CHAT_SAMPLE12"].ToString();
            string mUserExternalAplication = ConfigurationManager.AppSettings["USER_EXTERNALAPPLICATION_CHAT_SAMPLE12"].ToString();
            string mPasswordExternalAplication = ConfigurationManager.AppSettings["PASSWORD_EXTERNALAPPLICATION_CHAT_SAMPLE12"].ToString();
            string mQueueLogin = ConfigurationManager.AppSettings["CHAT_QUEUE_LOGIN_SAMPLE12"].ToString();
            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters;
            Newtonsoft.Json.Linq.JToken objJson;

            result = false;

            DateTime RightNow = DateTime.UtcNow;
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                return result;
            }
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                return result;
            }
            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                return result;
            }
            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                return result;
            }
            //Insert CaseAttachment

            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;

            serviceparameters += mQueueLogin;
            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                return result;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                return result;
            }
            ChatPropertiesResponse = ws.GetChatQueuePropertiesByLogin("A" + publicKey1, encryptedUser, encryptedPassword,
                                                                signature, mQueueLogin);
            if (ChatPropertiesResponse.response.responseCode != 1)
            {
                //Error
                return result;
            }
            objJson = Newtonsoft.Json.Linq.JToken.Parse(ChatPropertiesResponse.JsonChatQueueProperties);

            if (objJson["AgentCanReceiveFiles_CHGE"].ToString().ToLower() == "true")
            {
                result = true;
            }

            return result;
        }

        private byte[] ConvertToPNG(byte[] ImageBytes, string Serverpath, string Filename, string fileguid)
        {
            byte[] result = null;


            using (System.IO.MemoryStream ms = new MemoryStream())
            {
                using (System.Drawing.Image pngImage = System.Drawing.Image.FromStream(new System.IO.MemoryStream(ImageBytes)))
                {
                    pngImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    System.IO.File.Delete(Path.Combine(Serverpath, Filename));
                    pngImage.Save(Path.Combine(Serverpath, fileguid + ".png"));
                    result = ms.ToArray();
                }
            }

            return result;
        }

        private bool HasVideoTracks(string Serverpath, string Filename)
        {
            bool result;
            string r;
            result = false;
            try
            {
                Frapper.FFMPEG myff = new Frapper.FFMPEG(Path.Combine(Serverpath, "ffprobe.exe"));
                r = myff.RunCommand(@"-i " + Path.Combine(Serverpath, Filename) + " -show_streams -select_streams v -loglevel error");
                if (!string.IsNullOrEmpty(r) && r.StartsWith("[STREAM]"))
                {
                    result = true;

                }
            }
            catch
            {
                result = false;
            }
            return result;
        }

        private bool HasAudioTracks(string Serverpath, string Filename)
        {
            bool result;
            string r;
            result = false;
            try
            {
                Frapper.FFMPEG myff = new Frapper.FFMPEG(Path.Combine(Serverpath, "ffprobe.exe"));
                r = myff.RunCommand(@"-i " + Path.Combine(Serverpath, Filename) + " -show_streams -select_streams a -loglevel error");
                if (!string.IsNullOrEmpty(r) && r.StartsWith("[STREAM]"))
                {

                    result = true;

                }
            }
            catch
            {
                result = false;
            }
            return result;
        }

        private byte[] ConvertVideoH264_ACC(string Serverpath, string Filename, string fileguid)
        {
            byte[] result;
            byte[] tmpresult;
            result = null;
            try
            {
                using (Process p = new Process())
                {
                    p.StartInfo.UseShellExecute = false;
                    p.StartInfo.CreateNoWindow = true;
                    p.StartInfo.RedirectStandardOutput = true;
                    p.StartInfo.FileName = Path.Combine(Serverpath, "ffmpeg.exe");
                    p.StartInfo.Arguments = @"-i " + Path.Combine(Serverpath, Filename) + " -vcodec h264 -acodec aac -strict -2 " + Path.Combine(Serverpath, "x" + fileguid + ".mp4");
                    p.Start();
                    p.WaitForExit();
                }

                if (System.IO.File.Exists(Path.Combine(Serverpath, "x" + fileguid + ".mp4")))
                {
                    tmpresult = System.IO.File.ReadAllBytes(Path.Combine(Serverpath, "x" + fileguid + ".mp4"));
                    if (tmpresult != null && tmpresult.Length >= 1)
                    {
                        System.IO.File.Delete(Path.Combine(Serverpath, Filename));
                        System.IO.File.Move(Path.Combine(Serverpath, "x" + fileguid + ".mp4"), Path.Combine(Serverpath, fileguid + ".mp4"));
                        result = tmpresult.ToArray();
                    }

                    System.IO.File.Delete(Path.Combine(Serverpath, "x" + fileguid + ".mp4"));

                }
            }
            catch
            {
                result = null;
            }
            return result;
        }

        private byte[] ConvertAudio_ACC(string Serverpath, string Filename, string fileguid)
        {
            byte[] result;
            byte[] tmpresult;
            result = null;
            try
            {
                using (Process p = new Process())
                {
                    p.StartInfo.UseShellExecute = false;
                    p.StartInfo.CreateNoWindow = true;
                    p.StartInfo.RedirectStandardOutput = true;
                    p.StartInfo.FileName = Path.Combine(Serverpath, "ffmpeg.exe");
                    p.StartInfo.Arguments = @"-i " + Path.Combine(Serverpath, Filename) + " -acodec aac -strict -2 " + Path.Combine(Serverpath, "x" + fileguid + ".mp4");
                    p.Start();
                    p.WaitForExit();

                }

                if (System.IO.File.Exists(Path.Combine(Serverpath, "x" + fileguid + ".mp4")))
                {
                    tmpresult = System.IO.File.ReadAllBytes(Path.Combine(Serverpath, "x" + fileguid + ".mp4"));
                    if (tmpresult != null && tmpresult.Length >= 1)
                    {
                        System.IO.File.Delete(Path.Combine(Serverpath, Filename));
                        System.IO.File.Move(Path.Combine(Serverpath, "x" + fileguid + ".mp4"), Path.Combine(Serverpath, fileguid + ".mp4"));
                        result = tmpresult.ToArray();
                    }
                    System.IO.File.Delete(Path.Combine(Serverpath, "x" + fileguid + ".mp4"));
                }
            }
            catch
            {
                result = null;
            }
            return result;
        }

        private bool SaveAttachmentTPClient(string CaseNumber, string FileName, string FileNameGuid, byte[] fileBytes, string fileGuid, string fileType)
        {
            bool result;

            wsTPClientAPI.TPClientWebServicesAPI ws = new wsTPClientAPI.TPClientWebServicesAPI();
            wsTPClientAPI.APIAttachFileToExistingCaseResponse oneInsertCaseAttachment;

            bool r;
            string publicKey1 = "";
            string keyPairs = "";
            string message = "";

            string mIdApplication = ConfigurationManager.AppSettings["EXTERNALAPPLICATION_CHAT_SAMPLE12"].ToString();
            string mUserExternalAplication = ConfigurationManager.AppSettings["USER_EXTERNALAPPLICATION_CHAT_SAMPLE12"].ToString();
            string mPasswordExternalAplication = ConfigurationManager.AppSettings["PASSWORD_EXTERNALAPPLICATION_CHAT_SAMPLE12"].ToString();
            string publicKey2;
            string encryptedUser;
            string encryptedPassword;
            string appSignature;
            string signature;
            string serviceparameters;
            string md5parameters;
            string bytesmd5;

            result = false;

            DateTime RightNow = DateTime.UtcNow;
            r = RsaManager.CreateKeyPair(ref publicKey1, ref keyPairs, ref message);
            if (!r)
            {
                //Error
                return result;
            }
            publicKey2 = ws.GetPublicKey();
            if (string.IsNullOrEmpty(publicKey2.Trim()))
            {
                //Error
                return result;
            }
            encryptedUser = RsaManager.EncryptRSA(publicKey2, mUserExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedUser))
            {
                //Error
                return result;
            }
            encryptedPassword = RsaManager.EncryptRSA(publicKey2, mPasswordExternalAplication, ref message);
            if (string.IsNullOrEmpty(encryptedPassword))
            {
                //Error
                return result;
            }
            //Insert CaseAttachment

            //signature: idapplication|year-month-day-utchour-utcminute|md5parameters
            //md5parameters is md5 operation of idapplication+EncryptedUser+EncryptedPassword+p1.tostring+p2.tostring+....+pn.tostring
            //if px not exists md5 finish after EncryptedPassword
            //if px are date must be converted to string using yyyy-mm-dd 24hh:mm:ss
            appSignature = mIdApplication + "|" + RightNow.Year.ToString() + "-" + RightNow.Month.ToString() + "-" + RightNow.Day.ToString() + "-" + RightNow.Hour.ToString() + "-" + RightNow.Minute.ToString();

            serviceparameters = mIdApplication + encryptedUser + encryptedPassword;

            bytesmd5 = "";
            r = HashManager.Hash_MD5Bytes(fileBytes, ref bytesmd5);
            if (!r)
            {
                //Error
                return result;
            }

            serviceparameters = serviceparameters + CaseNumber + bytesmd5 + FileName;
            serviceparameters = serviceparameters + mUserExternalAplication + FileNameGuid + "1";
            serviceparameters = serviceparameters + fileGuid + fileType;

            md5parameters = "";
            r = HashManager.Hash_MD5(serviceparameters, ref md5parameters);
            if (!r || string.IsNullOrEmpty(md5parameters))
            {
                //Error
                return result;
            }

            signature = appSignature + "|" + md5parameters;

            signature = RsaManager.EncryptRSA(publicKey2, signature, ref message);
            if (string.IsNullOrEmpty(signature))
            {
                //Error
                return result;
            }
            oneInsertCaseAttachment = ws.AttachFileToExistingCase("A" + publicKey1, encryptedUser, encryptedPassword,
                                                                signature,
                                                                Convert.ToInt32(CaseNumber),
                                                                fileBytes,
                                                                FileName,
                                                                mUserExternalAplication,
                                                                FileNameGuid,
                                                                true,
                                                                fileGuid,
                                                                fileType);
            if (oneInsertCaseAttachment.response.responseCode != 1)
            {
                //Error
                return result;
            }

            result = true;

            return result;
        }
    }
}