﻿
$(document).ready(function () {
    var UrlTPClientSite;
    var d = new Date()
    var n = d.getTimezoneOffset();
    $("#UserTimezoneOffset").val(n);
    $("#nameTextBox").focus();
    //var firstname =  localStorage.getItem("firstname");
    //var lastname = localStorage.getItem("lastname");
    ////var mobile = localStorage.getItem("mobile");
    //var email =  localStorage.getItem("email");

    //if (firstname == null) {        
    //    window.location.href = "https://chathelpdesk.teleperformancedibs.com/Waha/ChatExpress/LogOut";       
    //}
    $(window).resize(function () {
        myResize();
    });

    function myResize() {
        var screenW = $("#sizerDiv").width();
        var screenH = $("#sizerDiv").height();
        //var w;
        var h;

        $("#MainDiv").css("width", screenW + "px");
        $("#MainDiv").css("height", screenH + "px");

        if (screenW <= 480) {
            h = screenH - 60 - 35;
        }
        else {
            h = screenH - 85 - 35;
        }

        if (h <= 150) {
            h = 150;
        }

        $("#MessageRedirectingDiv").css("height", h + "px");
        $("#MessageRedirectSpanRow").css("padding-top", parseInt(h / 2 - 40, 10) + "px");
    }

    setTimeout(function () {
        myResize();
    }, 100);

    function fnConnectionSuccess() {
        //debugger;
        //do your business rules according to your needs
        //$("#nameTextBox").attr('disabled', 'disabled');
        //$("#lastNameTextBox").attr('disabled', 'disabled');
        //$("#emailTextBox").attr('disabled', 'disabled');
        //$("#queryTextArea").attr('disabled', 'disabled');
        //$("#saveButton").attr('disabled', 'disabled');

        //$("#nameTextBox").val(firstname);
        //$("#lastNameTextBox").val(lastname);
        //$("#emailTextBox").val(email);

        //$("#nameTextBox").attr('disabled', 'disabled');
        //$("#lastNameTextBox").attr('disabled', 'disabled');
        //$("#emailTextBox").attr('disabled', 'disabled');

        //SwalErrorMessage('Unable to connect to network infrastructure');
    }

    function fnConnectionFail() {
        //debugger;
        //do your business rules according to your needs
        //$("#nameTextBox").attr('disabled', 'disabled');
        //$("#lastNameTextBox").attr('disabled', 'disabled');
        //$("#emailTextBox").attr('disabled', 'disabled');
        //$("#queryTextArea").attr('disabled', 'disabled');
        //$("#saveButton").attr('disabled', 'disabled');

        //$("#nameTextBox").val(firstname);
        //$("#lastNameTextBox").val(lastname);
        //$("#emailTextBox").val(email);
        //$("#nameTextBox").attr('disabled', 'disabled');
        //$("#lastNameTextBox").attr('disabled', 'disabled');
        //$("#emailTextBox").attr('disabled', 'disabled');

        //SwalErrorMessage('Unable to connect to network infrastructure');
    }

    //validate signalr
    try {
        UrlTPClientSite = decodeURIComponent($("#URLSiteHidden").val());
        $.connection.hub.url = UrlTPClientSite + "signalr";
        $.connection.hub.start({ transport: 'longPolling' }).done(function () {
            fnConnectionSuccess();
        }).fail(function () {
            fnConnectionFail();
        });
    } catch (ex) {
        fnConnectionFail();
    }
});

var LoadingModal = new Object();
LoadingModal.Hide = function () {
    document.getElementById("overlayTPClient").style.visibility = "hidden";
}
LoadingModal.Show = function () {
    document.getElementById("overlayTPClient").style.visibility = "visible";
    setTimeout("LoadingModal.Hide();", 30000);
}

function fnValidate() {
    if ($.trim($("#nameTextBox").val()) === '') {
        $("#nameTextBox").focus();
        SwalErrorMessage('You must type your name');
        return false;
    }
    if ($.trim($("#lastNameTextBox").val()) === '') {
        $("#lastNameTextBox").focus();
        SwalErrorMessage('You must type your last name');
        return false;
    }
    if ($.trim($("#crewidTextBox").val()) === '') {
        $("#crewidTextBox").focus();
        SwalErrorMessage('You must type your crew id');
        return false;
    }

    var radio = document.getElementsByName("requestTypeRadioButtonList"); //Client ID of the RadioButtonList1                            
    var flag = 0;
    var defaultValue = "";
    for (var i = 0; i < radio.length; i++) {
        if (radio[i].checked) {
            flag = 1;
            defaultValue = radio[i].defaultValue;
            break;
        }
    }
    if (flag == 0) {
        SwalErrorMessage('Please select Request Type');
        return false;
    }
    //if ($.trim($("#emailTextBox").val()) === '') {
    if (!isValidEmailAddress($.trim($("#emailTextBox").val()))) {
        $("#emailTextBox").focus();
        SwalErrorMessage('invalid email');
        return false;
    }

    var ddlvalue = $("#ddlusertype option:selected").val();
    if (ddlvalue == '-1') {
        SwalErrorMessage('Please select User Type');
        return false;
    }
    if (defaultValue != "UR") {
        var ddlvalue = $("#ddlclassificationtype option:selected").val();
        if (ddlvalue == '-1') {
            SwalErrorMessage('Please select Classification Type');
            return false;
        }

        var ddlvalue = $("#ddlsubclassificationtype option:selected").val();
        if (ddlvalue == '-1') {
            SwalErrorMessage('Please select Sub Classification Type');
            return false;
        }
    }
    if ($.trim($("#queryTextArea").val()) === '') {
        $("#queryTextArea").focus();
        SwalErrorMessage('You must type your question');
        return false;
    }

    $("#nameTextBox").prop("disabled", false);
    $("#lastNameTextBox").prop("disabled", false);
    $("#emailTextBox").prop("disabled", false);

    setTimeout(function () {
        LoadingModal.Show();
    }, 100);
    return true;
}

function isValidEmailAddress(emailAddress) {
    var pattern = new RegExp(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i);
    return pattern.test(emailAddress);
}

function SwalErrorMessage(message) {
    swal("Oops", message, "error");
}

