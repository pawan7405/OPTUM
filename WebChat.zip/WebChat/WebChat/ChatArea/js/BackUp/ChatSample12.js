﻿//************************global variables*****************************

var MediaAudioRecorder;
var RecordedAudio = null;

var UrlTPClientSite = "";
var ChatSample12 = null;
var TPClientChatSample;
var selectedConnectionIdBD = 0;

var chatConnectionIdEncrypted = "";
var LoadingModal = new Object();
var Nonce = "";
var ArrayFileguid = new Array();
var ArrayFileName = new Array();
var ArrayFileExtension = new Array();
var IEClickButton = false;
var surveyFirstTime = true;
var surveyInprogress = false;

//****************************clsChatSample12***************************
//utility functions encapsulated on clsChatSample12
//to avoid overwrite other functions with same name
function clsChatSample12() {
    //private members

    var mIinitialWidth = null;
    var mInitialHeight = null;

    mInitialWidth = $("#sizerDiv").css("width");
    mInitialHeight = $("#sizerDiv").css("height");

    function mfnWindowLink(URL) {
        var param;
        param = "width=" + mInitialWidth + ",height=" + mInitialHeight + ",menubar=0,resizable=1,status=1,top=0,left=0";

        var currentlocation;
        currentlocation = window.location.href;
        currentlocation = currentlocation.toLowerCase();
        if ((currentlocation.indexOf("https://") == 0) && (URL.toLowerCase().indexOf("http://") == 0)) {
            switch (jQuery.browser) {
                case "msie":
                    //do nothing to prevent reload
                    break;
                default:
                    //let the pop-up blocker to manage it
                    window.open(URL, "", param);
                    break;
            }
        }
        else {
            window.open(URL, "", param);
        }
    }

    //public members
    return {
        fnWindowLink: mfnWindowLink,
        initialWidth: mInitialWidth,
        initialHeight: mInitialHeight
    }
}
//*********************************************************************

//**************************** document ready **************************
$(document).ready(function () {

    //upload plugin
    //Modernizr test
    function isUploadSupported() {
        if (navigator.userAgent.match(/(Android (1.0|1.1|1.5|1.6|2.0|2.1))|(Windows Phone (OS 7|8.0))|(XBLWP)|(ZuneWP)|(w(eb)?OSBrowser)|(webOS)|(Kindle\/(1.0|2.0|2.5|3.0))/)) {
            return false;
        }
        var elem = document.createElement('input');
        elem.type = 'file';
        return !elem.disabled;
    }

    if (isUploadSupported()) {
        if ($("#AgentCanReceiveFiles_Hidden").val() == "true") {
            $("#UploadFileDiv").css("display", "block");

            if (!MediaRecorder.notSupported) {
                $("#MediaAudioRecordingButton").css("display", "block");
                $("#MediaAudioRecordingButton").click(function () {
                    var html;
                    html = "";
                    html = html + "<div>";
                    navigator.mediaDevices.getUserMedia({ audio: true })
                        .then(function (stream) {
                            html = html + "<table align='center' border='0' cellspacing='0' cellpadding='0'>";
                            html = html + "<tr  id='StartRecordMediaAudioImage'>";
                            html = html + "<td align='center'>";
                            html = html + "&nbsp;<a style='display:block;'> <img src='images/audiorecord.png' style='height:58px;' /></a>";
                            html = html + "</td>";
                            html = html + "</tr>";
                            html = html + "<tr>";
                            html = html + "<td align='center'>";
                            html = html + "&nbsp;<a id='StartRecordMediaAudioButton' href='javascript:StartRecordAudio();' style='display:block;'> <img src='images/audiorecordstart2.png' style='height:58px;' /></a>";
                            html = html + "</td>";
                            html = html + "</tr>";
                            html = html + "<tr >";
                            html = html + "<td align='center'>";
                            html = html + "&nbsp;<img id='RecordingMediaAudioImage' src='images/recording.gif' style='height:70px;display:none;'>";
                            html = html + "</td>";
                            html = html + "</tr>";
                            html = html + "<tr>";
                            html = html + "<td align='center'>";
                            html = html + "&nbsp;<a  id='StopRecordMediaAudioButton'  href='javascript:StopRecordAudio();'  style='display:none;'> <img src='images/stoprecord.png' style='height:50px;' /></a>";
                            html = html + "</td>";
                            html = html + "</tr>";
                            html = html + "<tr>";
                            html = html + "<td align='center'>";
                            html = html + "<div id='AudioPlayerRecordMediaDiv'></div>";
                            html = html + "</tr>";
                            html = html + "<tr>";
                            html = html + "</table>";
                            html = html + "</div>";
                            RecordedAudio = null;
                            swal({
                                html: true,
                                title: "",
                                text: html,
                                showCancelButton: true,
                                confirmButtonText: "OK",
                                cancelButtonText: "Cancel"
                            }, function (isConfirm) {
                                if (isConfirm) {
                                    var data = new FormData();
                                    data.append('file', RecordedAudio);
                                    $.ajax({
                                        url: 'FileUploadHandler.ashx?upload=start&CaseNumber=' + $("#caseNumberTextBox").val() + "&ChatRequestId=" + $("#ChatRequestIdHidden").val() + "&IsAudioRecorded=true",
                                        type: 'POST',
                                        data: data,
                                        contentType: false,
                                        processData: false,
                                        success: function (response) {
                                            if (response != null) {
                                                if (response.startsWith("Success:")) {
                                                    var otherdata;
                                                    otherdata = response.split(':');
                                                    //Success:filetype:guid:ext:filename
                                                    switch (otherdata[1]) {
                                                        case "audio":
                                                            TPClientChatSample.UserSendMessage("[tpclient_external_audio:" + otherdata[2] + "]", UserRenderHeader, UserName);
                                                            break;
                                                    }
                                                }
                                            }
                                        },
                                        error: function (error) {
                                            console.log(error);
                                        }
                                    });
                                }
                            });
                            $(".sa-confirm-button-container").css("display", "none");
                        }).catch(function (err) {
                            html = html + "<p>Your microphone is blocked to be used by this page.</p>";
                            html = html + "<p>Please unblock it and try again.</p>";
                            html = html + "</div>";
                            RecordedAudio = null;
                            swal(
                                {
                                    html: true,
                                    title: "",
                                    text: html,
                                    confirmButtonText: "OK",
                                }
                            );
                        });
                });
            }

            $('#btnFileUpload').fileupload({
                url: 'FileUploadHandler.ashx?upload=start&CaseNumber=' + $("#caseNumberTextBox").val() + "&ChatRequestId=" + $("#ChatRequestIdHidden").val(),
                add: function (e, data) {
                    //$('#progressbar').show();
                    data.submit();
                },
                progress: function (e, data) {
                    var progress = parseInt(data.loaded / data.total * 100, 10);
                    //console.log(progress);
                    //$('#progressbar div').css('width', progress + '%');
                },
                success: function (response, status) {
                    //$('#progressbar').hide();
                    //$('#progressbar div').css('width', '0%');
                    if (response != null) {
                        if (response.startsWith("Success:")) {
                            var otherdata;
                            otherdata = response.split(':');
                            //Success:filetype:guid:ext:filename
                            switch (otherdata[1]) {
                                case "image":
                                    TPClientChatSample.UserSendMessage("[tpclient_external_image:" + otherdata[2] + "]", UserRenderHeader, UserName);
                                    break;
                                case "video":
                                    TPClientChatSample.UserSendMessage("[tpclient_external_video:" + otherdata[2] + "]", UserRenderHeader, UserName);
                                    break;
                                case "audio":
                                    TPClientChatSample.UserSendMessage("[tpclient_external_audio:" + otherdata[2] + "]", UserRenderHeader, UserName);
                                    break;
                                case "file":
                                    ArrayFileguid.push(otherdata[2]);
                                    ArrayFileExtension.push(otherdata[3]);
                                    ArrayFileName.push(otherdata[4]);
                                    TPClientChatSample.UserSendMessage("[tpclient_external_file:" + otherdata[2] + "]", UserRenderHeader, UserName);
                                    break;
                            }
                        }
                    }
                    //console.log(response);
                },
                error: function (error) {
                    //$('#progressbar').hide();
                    //$('#progressbar div').css('width', '0%');
                    //console.log(error);
                }
            });
        }
    }




    //Resize
    function Chatresize() {
        if (surveyInprogress) {
            $("#ChatContainerDiv").css("display", "none");
            return;
        }
        var screenW = $("#sizerDiv").width();
        var screenH = $("#sizerDiv").height();

        var w;
        var h;
        var h2;
        var HeaderHeight;
        var ButtonsHeaderHeight;
        var TabsHeight;
        var TypingHeight;

        $("#MainDiv").css("width", screenW + "px");
        $("#MainDiv").css("height", screenH + "px");

        HeaderHeight = $("#headerDiv").outerHeight(true);
        ButtonsHeaderHeight = $("#buttonsheaderDiv").outerHeight(true);
        TabsHeight = $("#TabsDiv").outerHeight(true);
        TypingHeight = $("#typingDiv").outerHeight(true);

        h2 = screenH - HeaderHeight - ButtonsHeaderHeight - TabsHeight - TypingHeight - 40;

        if (h2 < 150) {
            h2 = 150;
        }

        $("#messages").css("height", h2 + "px");

        $("#ChatHistoryDiv").css("height", h2 + "px");

        h = screenH - HeaderHeight - 40;
        if (h <= 150) {
            h = 150;
        }
        $("#MessageInvalidRequestDiv").css("height", h + "px");
        $("#MessageInvalidRequestSpanRow").css("padding-top", parseInt(h / 2 - 40, 10) + "px");

        $("#MessageRoutingDiv").css("height", h + "px");
        $("#MessageRoutingSpanRow").css("padding-top", parseInt(h / 2 - 40, 10) + "px");

        $("#MessageStillWaitingDiv").css("height", h + "px");
        $("#MessageStillWaitingSpanRow").css("padding-top", parseInt(h / 3, 10) + "px");

        $("#MessageTimeOutDiv").css("height", h + "px");
        $("#MessageTimeOutSpanRow").css("padding-top", parseInt(h / 2 - 40, 10) + "px");

        $("#messages").scrollTop($("#messages").get(0).scrollHeight);

        if ($("#ChatTypeTextBox").val() !== "TEXT" && $("#VideoEnabled").val() === "1") {
            $("#VideoDiv").css("left", "30px");
            $("#VideoDiv").css("top", (HeaderHeight + ButtonsHeaderHeight) + "px");
            h = screenH - HeaderHeight - ButtonsHeaderHeight - 40;
            if (h < 150) {
                h = 150;
            }
            w = (screenW - 60);
            if (w < 100) {
                w = 100;
            }
            $("#VideoDiv").css("width", w + "px");
            $("#VideoDiv").css("height", h + "px");
            $("#VideoUserIframe").css("width", (w - 10) + "px");
            $("#VideoUserIframe").css("height", (h - 10) + "px");

            $("#VideoUserIframe").contents().find("#AgentVideoDiv").css("left", "0");
            $("#VideoUserIframe").contents().find("#AgentVideoDiv").css("top", "0");
            $("#VideoUserIframe").contents().find("#AgentVideoDiv").css("width", (w - 11) + "px");
            $("#VideoUserIframe").contents().find("#AgentVideoDiv").css("height", (h - 11) + "px");

            $("#VideoUserIframe").contents().find("#UserVideoDiv").css("left", (w - 30 - 100) + "px");
            $("#VideoUserIframe").contents().find("#UserVideoDiv").css("top", (h - 30 - 170) + "px");
        }
    }
    //End Resize

    setTimeout(function () {
        Chatresize();
    }, 100);

    $(window).resize(function () {
        Chatresize();
    });

    LoadingModal.Hide = function () {
        document.getElementById("overlayTPClient").style.visibility = "hidden";
    }
    LoadingModal.Show = function () {
        document.getElementById("overlayTPClient").style.visibility = "visible";
        setTimeout("LoadingModal.Hide();", 30000);
    }

    //create sample1 one object to initialize some global functions and variables
    ChatSample12 = new clsChatSample12();

    //****************************************utility functions*************************************
    //function to get time formated hh:mm
    function fnFormatNowTime() {
        var nowDate = new Date();
        var result;
        result = '';
        if (nowDate.getHours() <= 9) {
            result = result + '0' + nowDate.getHours();
        }
        else {
            result = result + nowDate.getHours();
        }
        result = result + ":";
        if (nowDate.getMinutes() <= 9) {
            result = result + '0' + nowDate.getMinutes();
        }
        else {
            result = result + nowDate.getMinutes();
        }
        result = result + ":";
        if (nowDate.getSeconds() <= 9) {
            result = result + '0' + nowDate.getSeconds();
        }
        else {
            result = result + nowDate.getSeconds();
        }
        return result;
    }

    //trim spaces
    function trimSpaces(text) {
        // skip leading and trailing whitespace and return everything in between
        return text.replace(/^\s*(\b.*\b|)\s*$/, "$1");
    }

    //string function to replace characters
    function replaceAll(txt, replace, with_this) {
        return txt.split(replace).join(with_this);
    }
    //*****************************************************************************************

    //specific functions and variables for chat processing
    var ErrorMessage;
    var routingTries = 0;
    var delayBetweentries = 5000;
    var offerWaiting = false;
    var offerdelay = 0;
    var offerMail = false;
    var UserRenderHeader;
    var UserName;

    var typingAlert = new Date();
    var isTyping = false;
    var SuccesSentEmailMessage = "";
    var FailSentEmailMessage = "";
    var valueTimeOutOfferMail = 60;
    var timeFromStart;
    var timerOffer = null;

    //viewdesktop modal windows
    var widthViewDesktopPrompt = 350;
    var heightViewDesktopPrompt = 200;
    var widthViewDesktopRun = 400;
    var heightViewDesktopRun = 430;

    //make typingAlert old
    typingAlert.setDate(typingAlert.getDate() - 1);

    //******************************************Initial validations***********************************
    //check if it is valid request
    $("#InvalidRequestLabel").text($("#InvalidChatRequestMessage_CHGRHidden").val());
    if (($("#IsValidRequestHidden").val().toLocaleLowerCase() == "false") || ($("#Id_GROUHidden").val() == "")) {
        $("#InvalidChatRequestDiv").css("display", "block");
        $("#InvalidRequestLabel").css("display", "block");
        $("#RouterDiv").css("display", "none");
        $("#endButton").val($("#EndButtonMessage_CHGRHidden").val());
        return;
    }

    //check if it is out of schedule
    if ($("#IsOutofScheduleHidden").val().toLowerCase() == "true") {
        if ($("#ExternalURLOutOfSchedule_CHGRHidden").val().toLowerCase() != "") {
            var url;
            url = decodeURIComponent($("#ExternalURLOutOfSchedule_CHGRHidden").val());
            if (url.indexOf('?') == -1) {
                window.location.href = url + "?status=OUTOFSCHEDULE&QueueLogin=" + $("#QueueLoginTextBox").val() + "&IdCase=" + $("#caseNumberTextBox").val();
            }
            else {
                window.location.href = url + "&status=OUTOFSCHEDULE&QueueLogin=" + $("#QueueLoginTextBox").val() + "&IdCase=" + $("#caseNumberTextBox").val();
            }
            return;
        }
        else {
            $("#WaitingMessageLabel").text($("#MessageWhenNoExternalURLOutOfSchedule_CHGRHidden").val());
            $("#WaitingMessageLabel").css("display", "block");
            $("#RouterDiv").css("display", "block");
            return;
        }
    }
    //************************************************************************************************

    //*******************************************setup parameters*************************************
    //assing values to RouteDiv Elements
    $("#WaitingMessageLabel").text($("#RoutingSearchAvailAgentMessage_CHGRHidden").val());

    if ($("#ShowQueuePosition_CHGRHidden").val().toLowerCase() == "true") {
        $("#QueuePositionLabel").text($("#RoutingQueuePositionMessage_CHGRHidden").val());
        $("#QueuePositionLabel").css("display", "block");
        $("#QueuePositionValueLabel").text("");
        $("#QueuePositionValueLabel").css("display", "block");
    }


    $("#RouterDiv").css("display", "block");

    //assign values to offer elements
    if ($("#OfferStillWait_CHGRHidden").val().toLowerCase() == "true") {
        offerWaiting = true
        offerdelay = parseInt($("#DelayBeforeOfferWaitSeconds_CHGRHidden").val()) * 1000;

        $("#wantWaitRadioButtonLabel").text($("#StillWaitMessage_CHGRHidden").val());
        $("#doNotWantWaitRadioButtonLabel").text($("#DontWaitMessage_CHGRHidden").val());
        $("#sendWaitModeButton").val($("#SendButtonMessage_CHGRHidden").val());
        valueTimeOutOfferMail = parseInt($("#TimeoutMinutesNoConnection_CHGRHidden").val());
        $("#TimeOutLabel").text($("#TimeOutMessage_CHGRHidden").val());
    }
    else {
        $("#AbandomRoutingButton").css("visibility", "visible");
        $("#AbandomRoutingButton").click(function () {
            PageMethods.KillChatRequest(TPClientChatSample.ChatRequestId, $("#webMethodsTokenHidden").val(), onSuccessKillChatRequest, onErrorKillChatRequest);
        });
    }

    function onSuccessKillChatRequest(result, userContext, methodName) {
        window.close();
    }

    function onErrorKillChatRequest(result, userContext, methodName) {
        window.close();
    }

    //chatting parameters
    //send and end objects
    $("#sendButton").val($("#SendButtonMessage_CHGRHidden").val());
    $("#endButton").val($("#EndButtonMessage_CHGRHidden").val());
    if ($("#ShowSendTranscript_CHGRHidden").val().toLowerCase() == "true") {
        //assign values to Mail
        offerMail = true
        $("#mailButton").val($("#SendEmailButtonMessage_CHGRHidden").val());
        SuccesSentEmailMessage = $("#SuccessSendEmailTranscriptMessage_CHGRHidden").val();
        FailSentEmailMessage = $("#FailSendEmailTranscriptMessage_CHGRHidden").val();
    }
    $("#typingAlert").text($("#AgentIsTypingMessage_CHGRHidden").val());
    UserRenderHeader = $("#UserRenderHeader_CHGRHidden").val();

    UserName = $("#UserFirstNameTextBox").val() + " " + $("#UserLastNameTextBox").val();

    //assign values to viewdesktop elements
    $("#questionOfferViewDesktopLabel").text($("#ViewDesktopOfferQuestion_CHGRHidden").val());
    $("#GrantAllowViewDesktopButton").val($("#ViewDesktopOfferAcceptButtonMessage_CHGRHidden").val());
    $("#DenyViewDesktopButton").val($("#ViewDesktopOfferRejectButtonMessage_CHGRHidden").val());

    //transfer parameters
    $("#TransferredMessageLabel").text($("#TransferredMessage_CHGRHidden").val());
    $("#CurrentDialogSpan").text($("#CurrentDialogTabMesage_CHGRHidden").val());
    $("#TransferredDialogSpan").text($("#PreviousDialogTabMesage_CHGRHidden").val());

    //*****************************************************************************************************

    UrlTPClientSite = decodeURIComponent($("#URLSiteHidden").val());

    alert(UrlTPClientSite);
    //handler triggered when hub connection is established after StartHub method
    function fnStarHubOk() {
        //connection to hub has been established
        console.log("signalR hub connected");
        timeFromStart = new Date();
    }

    //handler triggered when hub connection is not established after StartHub method
    function fnStartHubFail() {
        //critical error
        SwalErrorMessage("Error connecting to Chat Hub");
        return;
    }

    //RSA function needed to encrypt local symmetric key
    //only used once after connection to hub is established
    //use external js function defined in CryptoV4 folder
    //it also uses ExpRSATpCol,ModRSATpCol,ChallengeRSATpCol variables (see save button handler)
    function fnEncryptSymmetricWithRSA(data) {
        //console.log("RSA:" + data);
        //return data;
        var data2;
        //encrypt data using public key2 RSA
        fnInitKey();
        data2 = encryptedString(rsakeyTPCOL, Base64.encode(data));
        return data2;
    }

    //Function to encrypt messages from user to server
    //uses external functions defined in CryptJS folder
    function fnEncryptmessageHub(data, symmetrickey) {
        //console.log("Encrypt:" + data);
        //return data;
        //encrypt data using symetric key
        var keystr = symmetrickey.split('^')[0];
        var ivstr = symmetrickey.split('^')[1];
        var key = CryptoJS.enc.Hex.parse(keystr);
        var iv = CryptoJS.enc.Hex.parse(ivstr);
        var encrypted = CryptoJS.AES.encrypt(data, key, { iv: iv });
        //return data;
        return encrypted.toString();
    }

    //Function to decrypt messages from server to user
    //uses external functions defined in CryptJS folder
    function fnDecryptmessageHub(data, symmetrickey) {
        //return data;
        //decrypt data using symetric key
        var keystr = symmetrickey.split('^')[0];
        var ivstr = symmetrickey.split('^')[1];
        var key = CryptoJS.enc.Hex.parse(keystr);
        var iv = CryptoJS.enc.Hex.parse(ivstr);
        var decrypted = CryptoJS.AES.decrypt(data, key, { iv: iv });
        //console.log("Decrypt:" + CryptoJS.enc.Utf8.stringify(decrypted));
        return CryptoJS.enc.Utf8.stringify(decrypted);

        //return decrypted.toString();
    }

    function fnFormatHHMMSS(seconds) {
        var sec_num = parseInt(seconds, 10);
        var hours = Math.floor(sec_num / 3600);
        var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
        var seconds = sec_num - (hours * 3600) - (minutes * 60);

        if (hours < 10) { hours = "0" + hours; }
        if (minutes < 10) { minutes = "0" + minutes; }
        if (seconds < 10) { seconds = "0" + seconds; }
        return hours + ':' + minutes + ':' + seconds;
    }

    //handler triggered when user tries to connect to and agent
    //and there is no agent available 
    //The function returns your current queue postion for chat request
    function fnRoutingToAgentsFail(QueuePos, EWT) {
        console.log("fnRoutingToAgentsFail QueuePos:" + QueuePos);
        console.log("fnRoutingToAgentsFail EWT:" + EWT);
        //decide what to do  deppending on 
        //show queue,show offer, delay between tries,number of tries, etc.
        //change UI elemetns according to this

        //update queue values
        if ($("#ShowQueuePosition_CHGRHidden").val().toLowerCase() == "true") {
            if (QueuePos == "0") {
                $("#QueuePositionValueLabel").text("");
            }
            else {
                $("#QueuePositionValueLabel").text(QueuePos);
            }
        }

        if ($("#ExpectedWaitTimeMessage_CHGEHidden").val() != "") {
            if (EWT == "N/A") {
                $("#ExpectedWaitTimeLabel").css("visibility", "hidden");
                $("#ExpectedWaitTimeValueLabel").css("visibility", "hidden");
                $("#ExpectedWaitTimeValueLabel").text("...");
            } else {
                if (QueuePos == "0") {
                    $("#ExpectedWaitTimeLabel").css("visibility", "hidden");
                    $("#ExpectedWaitTimeValueLabel").css("visibility", "hidden");
                    $("#ExpectedWaitTimeValueLabel").text("...");
                }
                else {
                    $("#ExpectedWaitTimeLabel").text($("#ExpectedWaitTimeMessage_CHGEHidden").val())
                    $("#ExpectedWaitTimeValueLabel").text(fnFormatHHMMSS(parseInt(QueuePos, 10) * parseInt(EWT, 10)));
                    $("#ExpectedWaitTimeLabel").css("visibility", "visible");
                    $("#ExpectedWaitTimeValueLabel").css("visibility", "visible");
                }
            }
        }

        if (offerWaiting) {
            //Offer is enabled
            //check if it's to offer other options
            routingTries = routingTries + 1;
            if (routingTries * delayBetweentries >= offerdelay) {
                console.log('offer waiting');
                $("#RouterDiv").css("display", "none");
                $("#stillWaitingDiv").css("display", "block");//manage answer in sendWaitModeButton handler as shown in next lines
                //trigger a timer to avoid no answer after 1 hour
                timerOffer = setTimeout(fnTimeOutOffer, 10000);
            }
            else {
                //wait at least 1 hour with 5 seconds delay between tries
                var d2 = new Date();
                //console.log(d2 - timeFromStart);
                if ((d2 - timeFromStart) > valueTimeOutOfferMail * 60 * 1000) {
                    console.log('timeout offer waiting');
                    $("#RouterDiv").css("display", "none");
                    $("#stillWaitingDiv").css("display", "none");
                    $("#TimeOutDiv").css("display", "block");
                    TPClientChatSample.fnAbortRoutingChat();
                }
                else {
                    TPClientChatSample.fnTryRoutingAgain(delayBetweentries);
                }
            }
        } else {
            //wait at least 1 hour with 5 seconds delay between tries
            var d2 = new Date();
            //console.log(d2 - timeFromStart);
            if ((d2 - timeFromStart) > valueTimeOutOfferMail * 60 * 1000) {
                console.log('timeout offer waiting');
                $("#RouterDiv").css("display", "none");
                $("#stillWaitingDiv").css("display", "none");
                $("#TimeOutDiv").css("display", "block");
                TPClientChatSample.fnAbortRoutingChat();
            }
            else {
                TPClientChatSample.fnTryRoutingAgain(delayBetweentries);
            }
        }
    }

    function fnTimeOutOffer() {
        console.log('fnTimeOutOffer');
        if ($("#stillWaitingDiv").css("display") == "block") {
            var d2 = new Date();
            //console.log(d2 - timeFromStart);
            if ((d2 - timeFromStart) > valueTimeOutOfferMail * 60 * 1000) {
                console.log('timeout offer waiting');
                $("#RouterDiv").css("display", "none");
                $("#stillWaitingDiv").css("display", "none");
                $("#TimeOutDiv").css("display", "block");
                TPClientChatSample.fnAbortRoutingChat();
                try {
                    clearTimeout(timerOffer);
                }
                catch (ex) { }
            }
            else {
                try {
                    clearTimeout(timerOffer);
                }
                catch (ex) { }
                timerOffer = setTimeout(fnTimeOutOffer, 10000);
            }
        }
    }

    //handler to "offering send button"
    if (offerWaiting) {
        $("#sendWaitModeButton").click(function () {
            var id = $("input[name='WaitRadioButton']:checked").attr('id');
            if (!id) {
                //no option selected
                SwalErrorMessage('You must select one option');
                return;
            }
            if (id == "wantWaitRadioButton") {
                //wants to wait
                routingTries = 0;
                $("#stillWaitingDiv").css("display", "none");
                $("#RouterDiv").css("display", "block");
                //try again
                TPClientChatSample.fnTryRoutingAgain(delayBetweentries);

                try {
                    clearTimeout(timerOffer);
                }
                catch (ex) { }
            }
            else {
                //dont want to wait
                //hide elements and show message
                $("#wantWaitRadioButton").css("display", "none");
                $("#wantWaitRadioButtonLabel").css("display", "none");
                $("#doNotWantWaitRadioButton").css("display", "none");
                $("#doNotWantWaitRadioButtonLabel").css("display", "none");
                $("#sendWaitModeButton").css("display", "none");
                try {
                    clearTimeout(timerOffer);
                }
                catch (ex) { }
                if ($("#EmailClassifier_ID_WSCLHidden").val() != "") {
                    //notify server
                    PageMethods.ReclassifyChatRequestToBeContactedByMail(TPClientChatSample.ChatRequestId, $("#webMethodsTokenHidden").val(), onSuccessReclassifyChatRequestToBeContactedByMail, onErrorReclassifyChatRequestToBeContactedByMail);
                } else {
                    $("#WillBeContactedByMailLabelRow").css("display", "block");
                    $("#WillBeContactedByMailLabel").css("display", "block");
                }
            }
        });
    }

    function onSuccessReclassifyChatRequestToBeContactedByMail(result, userContext, methodName) {
        if (result == 'SUCCESS') {
            $("#WillBeContactedByMailLabelRow").css("display", "block");
            $("#WillBeContactedByMailLabel").css("display", "block");
        } else {
            $("#WillBeContactedByMailLabel").val(result);
            $("#WillBeContactedByMailLabelRow").css("display", "block");
            $("#WillBeContactedByMailLabel").css("display", "block");
        }
    }

    function onErrorReclassifyChatRequestToBeContactedByMail(result, userContext, methodName) {
        $("#WillBeContactedByMailLabel").val(result);
        $("#WillBeContactedByMailLabelRow").css("display", "block");
        $("#WillBeContactedByMailLabel").css("display", "block");
    }

    //handler triggered when user successfully connect to an agent
    function fnRoutingToAgentsOk(varselectedConnectionIdBD) {
        console.log("fnRoutingToAgentsOk");
        var r;
        selectedConnectionIdBD = varselectedConnectionIdBD;

        //reset timer
        try {
            clearTimeout(timerOffer);
        }
        catch (ex) { }

        //Change UI Elements to change to  chatting mode
        $("#RouterDiv").css("display", "none");

        //send case comments (Initial question)
        setTimeout(function () {
            $("#ChattingDiv").css("display", "block");
            $("#chatMessageTextArea").click();
            $("#chatMessageTextArea").val($("#caseCommentsTextBox").val());
            fnSendUserMessageChat();
            Chatresize();
        }, 2000);

        //Detect video
        if ($("#ChatTypeTextBox").val() == "VIDEO") {
            if ($("#EnableVideoChat_CHGRHidden").val().toLowerCase() == "true") {
                //only allows webrtc on https or localhost
                if ((window.location.protocol == "https:") || (window.location.href.substring(0, 17).toLowerCase() == "http://localhost/")) {
                    var iOS = (navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? true : false);
                    if (iOS) {
                        //not supported here 
                    }
                    else {
                        //desktop,android
                        r = DetectWEBRTC_TECH();
                        if ((!r) && (isIE())) {
                            //show load plugin
                            $("#IEPluginButton").show();
                            return;
                        }
                        if (r) {
                            StartNegotiateDetectVideoAgent()
                        }
                    }
                }
            }
        }
    }

    $("#IEPluginButton").click(function () {
        var URL;
        var params;
        URL = "WEBRTC_IEDownloadPlugin.aspx";
        params = "width=30,height=50,resizable=1,top=0,left=0";
        window.open(URL, "CHATEXPRESSWEBRTCIE", params, false);
    });

    $("#SurveyIFrame").load(function () {
        LoadingModal.Hide();
        $("#SurveyIFrame").css("display", "block");
        $("#ExitSurveyButton").css("display", "block");
        setTimeout(function () {
            Chatresize();
        }, 1000);
    });

    //handler triggered when chat end
    function fnChatEnd() {
        var param;

        //Setup controls to end state
        fnClearControlsStateChat();

        //enable send transcript by mail
        if (offerMail) {
            $("#mailButton").attr("style", "display:block");
        }

        //launch survey
        if (surveyFirstTime) {
            surveyFirstTime = false;
            param = "width=" + ChatSample12.initialWidth + ",height=" + ChatSample12.initialHeight + ",menubar=0,resizable=1,status=1,top=0,left=0";
            if ($("#UseTPClientSurvey_CHGRHidden").val().toLowerCase() == "true") {
                //TPClient survey
                var urlinternalsurvey;
                urlinternalsurvey = decodeURIComponent($("#URLSurveyHidden").val())
                //window.open(urlinternalsurvey, "", param);
                surveyInprogress = true;
                $("#overlayTPClient").css("display", "block");
                LoadingModal.Show();
                $("#headerDiv").css("display", "none");
                $("#ChatContainerDiv").css("display", "none");
                $("#VideoDiv").css("display", "none");
                $("#SurveyContainer").css("display", "block");

                $("#SurveyIFrame").attr("src", urlinternalsurvey);
            }
            else {
                if ($("#ExternalSurveyURL_CHGRHidden").val().toLowerCase() != "") {
                    //external survey
                    var urlexternalsurvey;
                    urlexternalsurvey = decodeURIComponent($("#ExternalSurveyURL_CHGRHidden").val());
                    //parameters
                    urlexternalsurvey = urlexternalsurvey.replace("[CaseNumber]", $("#caseNumberTextBox").val());
                    urlexternalsurvey = urlexternalsurvey.replace("[Context]", $("#ContextTextBox").val());
                    urlexternalsurvey = urlexternalsurvey.replace("[QueueLogin]", $("#QueueLoginTextBox").val());
                    window.open(urlexternalsurvey, "", param);
                }
            }
        }
    }

    $("#ExitSurveyButton").click(function () {
        surveyInprogress = false;
        $("#SurveyContainer").css("display", "none");
        $("#ExitSurveyButton").css("display", "none");
        $("#headerDiv").css("display", "block");
        $("#ChatContainerDiv").css("display", "block");
        $("#SurveyIFrame").attr("src", "about:blank");
        setTimeout(function () {
            Chatresize();
        }, 1000);
    });

    function ReplaceTagData(str, wordToFound, sourcetype) {
        var str2;
        var str3;
        var str4;
        var str5;
        var str6;
        var indexWordFound1;
        var indexWordFound2;
        var bolExit;
        var objReturn = {};
        var IdArray = new Array();
        var TypeArray = new Array();

        bolExit = false;
        do {
            indexWordFound1 = str.indexOf(wordToFound);
            if (indexWordFound1 == -1) {
                bolExit = true;
            }
            else {
                str2 = str.substring(indexWordFound1);
                indexWordFound2 = str2.indexOf("]");
                str4 = str2.substring(wordToFound.length, indexWordFound2);
                str5 = str.substring(0, indexWordFound1);
                str6 = str.substring(indexWordFound1 + indexWordFound2 + 1);
                if (sourcetype == "image") {
                    str = str5 + '<img style="height:25px;" class="tp_eximage_nofullscreen"  id="ex_image' + str4 + '" src="images/ImageSelect.png"  /><img style="width:50px;height:15px;" src="images/progress.gif" id="ex_prog' + str4 + '"/>' + str6;
                    IdArray.push(str4);
                    TypeArray.push('image');
                }
                if (sourcetype == "video") {
                    str = str5 + '<img style="height:25px;"  id="ex_image' + str4 + '" src="images/PlayMovie.png"  /><video id="ex_video' + str4 + '" style="display:none;" controls   /><img style="width:50px;height:15px;" src="images/progress.gif" id="ex_prog' + str4 + '"/>' + str6;
                    IdArray.push(str4);
                    TypeArray.push('video');
                }
                if (sourcetype == "audio") {
                    str = str5 + '<img style="height:25px;"  id="ex_image' + str4 + '" src="images/Play16.png"  /><audio id="ex_audio' + str4 + '" style="display:none;" controls   /><img style="width:50px;height:15px;" src="images/progress.gif" id="ex_prog' + str4 + '"/>' + str6;
                    IdArray.push(str4);
                    TypeArray.push('audio');
                }
                if (sourcetype == "file") {
                    str = str5 + '<img style="height:25px;"  id="ex_image' + str4 + '" src="images/folder.png"  /><a target="_blank" rel="noopener noreferrer" href="" style="display:none" id="ex_file' + str4 + '"></a> <img style="width:50px;height:15px;" src="images/progress.gif" id="ex_prog' + str4 + '"/>' + str6;
                    IdArray.push(str4);
                    TypeArray.push('file');
                }
            }
        } while (bolExit == false);
        objReturn.str = str;
        objReturn.IdArray = IdArray;
        objReturn.TypeArray = TypeArray;
        return objReturn;
    }

    //handler to receive messages from agent
    function fnReceiveMessage(message, agentheader, chatTextId) {
        //console.log("Message from agent:" + message);
        var header;
        var submessage;
        var i;
        var k;
        var m;
        var n;
        var rowText;
        var foundRow;
        var oneLink;
        var oldText;
        var parts;
        var IdFinalArray = new Array();
        var TypeFinalArray = new Array();
        var objReplace;

        if ($("#PlayReceiveMessageSoundHidden").val() == "true") {
            try {
                var audio = new Audio('sounds/audio_file.wav');
                audio.play();
            } catch (e) { }
        }

        header = '<li class=\'liagentsaid\' ><span class=\'agentSaid\'>' + agentheader + '&nbsp;</span><span class=\'atTime\'>at&nbsp;' + fnFormatNowTime() + '</span></li>';
        $('#messages').append(header);
        header = '<li class=\'triangle-isosceles2\' >';

        submessage = message;
        submessage = submessage.replace('<br/>', '\n');

        //insert one <li> per line and parse push command
        parts = submessage.split('\n');
        for (k = 0; k < parts.length; k++) {
            rowText = parts[k] + ' ';
            rowText = replaceAll(rowText, "push:http://", "http://");
            rowText = replaceAll(rowText, "push:https://", "https://");
            rowText = replaceAll(rowText, "push:ftp://", "ftp://");
            rowText = replaceAll(rowText, "push:ftps://", "ftps://");
            var allLinks = rowText.match(/(f|ht)tps?:\/\/.+?\s/g);
            if (allLinks != null) {
                var distinctLink = [];
                distinctLink.push(allLinks[0]);
                for (m = 1; m < allLinks.length; m++) {
                    foundRow = false;
                    for (n = 0; n < distinctLink.length; n++) {
                        if (allLinks[m] == distinctLink[n]) {
                            foundRow = true;
                        }
                    }
                    if (!foundRow) {
                        distinctLink.push(allLinks[m]);
                    }
                }
                for (m = 0; m < distinctLink.length; m++) {
                    oldText = distinctLink[m];
                    distinctLink[m] = replaceAll(distinctLink[m], '&amp;', '&');
                    oneLink = '';
                    oneLink = oneLink + '<a href="javascript:ChatSample12.fnWindowLink(\'';
                    oneLink = oneLink + distinctLink[m];
                    oneLink = oneLink + '\');">';
                    oneLink = oneLink + oldText + '</a>';
                    rowText = replaceAll(trimSpaces(rowText), trimSpaces(oldText), oneLink);
                }
                if (k == 0) {
                    header = header + '<span class=\'agentText\'>&nbsp;' + rowText + '</span>';
                }
                else {
                    header = header + '<span class=\'agentText\'>&nbsp;' + rowText + '</span>';
                }

                //check for push links
                rowText = parts[k] + ' ';
                allLinks = [];
                allLinks = rowText.match(/push:(f|ht)tps?:\/\/.+?\s/g);
                if (allLinks != null) {
                    distinctLink = [];
                    distinctLink.push(allLinks[0]);
                    for (m = 1; m < allLinks.length; m++) {
                        foundRow = false;
                        for (n = 0; n < distinctLink.length; n++) {
                            if (allLinks[m] == distinctLink[n]) {
                                foundRow = true;
                            }
                        }
                        if (!foundRow) {
                            distinctLink.push(allLinks[m]);
                        }
                    }
                    for (m = 0; m < distinctLink.length; m++) {
                        distinctLink[m] = replaceAll(distinctLink[m], '&amp;', '&');
                        oneLink = '';
                        oneLink = oneLink + distinctLink[m].substring(5);
                        //if (!$.browser.msie) {
                        ChatSample12.fnWindowLink(oneLink);
                        //}
                    }
                }
            }
            else {
                if (k == 0) {
                    header = header + '<span class=\'agentText\'>&nbsp;' + parts[k] + '</span>';
                }
                else {
                    header = header + '<span class=\'agentText\'>&nbsp;' + parts[k] + '</span>';
                }
            }
        }//next k
        header = header + '</li>';

        objReplace = ReplaceTagData(header, '[tpclient_external_image:', 'image');
        header = objReplace.str;
        for (i = 0; i <= objReplace.IdArray.length - 1; i++) {
            IdFinalArray.push(objReplace.IdArray[i]);
            TypeFinalArray.push(objReplace.TypeArray[i]);
        }

        objReplace = ReplaceTagData(header, '[tpclient_external_video:', 'video');
        header = objReplace.str;
        for (i = 0; i <= objReplace.IdArray.length - 1; i++) {
            IdFinalArray.push(objReplace.IdArray[i]);
            TypeFinalArray.push(objReplace.TypeArray[i]);
        }

        objReplace = ReplaceTagData(header, '[tpclient_external_audio:', 'audio');
        header = objReplace.str;
        for (i = 0; i <= objReplace.IdArray.length - 1; i++) {
            IdFinalArray.push(objReplace.IdArray[i]);
            TypeFinalArray.push(objReplace.TypeArray[i]);
        }

        objReplace = ReplaceTagData(header, '[tpclient_external_file:', 'file');
        header = objReplace.str;
        for (i = 0; i <= objReplace.IdArray.length - 1; i++) {
            IdFinalArray.push(objReplace.IdArray[i]);
            TypeFinalArray.push(objReplace.TypeArray[i]);
        }

        $('#messages').append(header);


        if ($("#GoChatImage").css("display") == "block") {
            $("#GoChatImage").click();
        }
        $("#messages").scrollTop($("#messages").get(0).scrollHeight);
        $("#typingAlert").css('visibility', 'hidden');
        if ($("#RequiresChatNotification").val() == "true") {
            TPClientChatSample.ConfirmReceivedMessageUser(chatTextId);
        }

        setTimeout(function () {
            if (IdFinalArray.length >= 1) {
                for (i = 0; i <= IdFinalArray.length - 1; i++) {
                    if (TypeFinalArray[i] == 'video') {
                        $("#ex_video" + IdFinalArray[i]).bind('canplay', function () {
                            var progressid = this.id;
                            //ex_imageXXXXX..
                            //012345678901234
                            progressid = "ex_prog" + progressid.substring(8);
                            $("#" + progressid).css("display", "none");
                        });
                    }
                    if (TypeFinalArray[i] == 'audio') {
                        $("#ex_audio" + IdFinalArray[i]).bind('canplay', function () {
                            var progressid = this.id;
                            //ex_imageXXXXX..
                            //012345678901234
                            progressid = "ex_prog" + progressid.substring(8);
                            $("#" + progressid).css("display", "none");
                        });
                    }
                }
                PageMethods.LoadExternalFiles(IdFinalArray, TypeFinalArray, $("#webMethodsTokenHidden").val(), OnSuccessLoadExternalFiles, OnErrorLoadExternalFiles);
            }
        }, 100);
    }

    function OnSuccessLoadExternalFiles(result, userContext, methodName) {
        var i;
        if (result != null) {
            try {
                if (result.length >= 1) {
                    for (i = 0; i <= result.length - 1; i++) {
                        if (result[i].ExternalFileType == "image") {
                            //images
                            $("#ex_image" + result[i].Id).load(function () {
                                var progressid = this.id;
                                //ex_imageXXXXX..
                                //012345678901234
                                progressid = "ex_prog" + progressid.substring(8);
                                $("#" + progressid).css("display", "none");
                                $("#" + this.id).css("height", "90px");
                                $("#" + this.id).css("border", "1px solid #7F7F7F");
                                $("#" + this.id).css("border-radius", "10px");
                                $("#messages").scrollTop($("#messages").get(0).scrollHeight);

                                $("#" + this.id).click(function () {
                                    var elem = document.getElementById(this.id);
                                    $("#" + this.id).css("height", "");
                                    if (elem.requestFullscreen) {
                                        elem.requestFullscreen();
                                    } else if (elem.mozRequestFullScreen) {
                                        elem.mozRequestFullScreen();
                                    } else if (elem.webkitRequestFullscreen) {
                                        elem.webkitRequestFullscreen();
                                    } else if (elem.msRequestFullscreen) {
                                        elem.msRequestFullscreen();
                                    }
                                });
                            }).attr("src", "Upload/image" + result[i].Id + ".png");
                        }
                        else {
                            if (result[i].ExternalFileType == "video") {
                                //videos
                                $("#ex_image" + result[i].Id).css("display", "none");
                                $("#ex_video" + result[i].Id).css("height", "100px");
                                $("#ex_video" + result[i].Id).css("min-width", "210px");
                                $("#ex_video" + result[i].Id).css("display", "block");
                                setTimeout(function (p) {
                                    $("#ex_video" + p).attr("src", "Upload/video" + p + ".mp4")
                                }, 4000, result[i].Id)
                                $('#ex_video').bind('contextmenu', function () { return false; });
                                $("#messages").scrollTop($("#messages").get(0).scrollHeight);
                            }
                            else {
                                if (result[i].ExternalFileType == "audio") {
                                    //audios
                                    $("#ex_image" + result[i].Id).css("display", "none");
                                    $("#ex_audio" + result[i].Id).css("height", "30px");
                                    $("#ex_audio" + result[i].Id).css("min-width", "210px");
                                    $("#ex_audio" + result[i].Id).css("display", "block");
                                    setTimeout(function (p) {
                                        $("#ex_audio" + p).attr("src", "Upload/audio" + p + ".mp4");
                                    }, 4000, result[i].Id);
                                    $('#ex_audio').bind('contextmenu', function () { return false; });
                                    $("#messages").scrollTop($("#messages").get(0).scrollHeight);
                                }
                                else {
                                    if (result[i].ExternalFileType == "file") {
                                        //files
                                        $("#ex_image" + result[i].Id).css("display", "none");
                                        $("#ex_prog" + result[i].Id).css("display", "none");
                                        $("#ex_file" + result[i].Id).attr("href", "Upload/file" + result[i].Id + result[i].FileExtension);
                                        $("#ex_file" + result[i].Id).html(result[i].AttachmentFilename);
                                        $("#ex_file" + result[i].Id).css("display", "block");
                                        $("#messages").scrollTop($("#messages").get(0).scrollHeight);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (e) { }
            $("#messages").scrollTop($("#messages").get(0).scrollHeight);
        }
    }

    function OnErrorLoadExternalFiles(error, userContext, methodName) {
        //todo
    }

    function LocalReplaceTagData(str, wordToFound, sourcetype) {
        var str2;
        var str3;
        var str4;
        var str5;
        var str6;
        var indexWordFound1;
        var indexWordFound2;
        var bolExit;
        var objReturn = {};
        var IdArray = new Array();
        var TypeArray = new Array();
        var i;

        bolExit = false;
        do {
            indexWordFound1 = str.indexOf(wordToFound);
            if (indexWordFound1 == -1) {
                bolExit = true;
            }
            else {
                str2 = str.substring(indexWordFound1);
                indexWordFound2 = str2.indexOf("]");
                str4 = str2.substring(wordToFound.length, indexWordFound2);
                str5 = str.substring(0, indexWordFound1);
                str6 = str.substring(indexWordFound1 + indexWordFound2 + 1);
                if (sourcetype == "image") {
                    str = str5 + '<img style="height:90px;border:1px solid black;border-radius:10px;" class="tp_eximage_nofullscreen"  id="ex_image' + str4 + '" src="Upload/' + str4 + '.png"  />' + str6;
                    IdArray.push(str4);
                    TypeArray.push('image');
                }
                if (sourcetype == "video") {
                    str = str5 + '<img style="width:50px;height:15px;" src="images/progress.gif" id="ex_prog' + str4 + '"/><video controls style="height:90px;display:none;"  id="ex_video' + str4 + '" />' + str6;
                    IdArray.push(str4);
                    TypeArray.push('video');
                }
                if (sourcetype == "audio") {
                    str = str5 + '<img style="width:50px;height:15px;" src="images/progress.gif" id="ex_prog' + str4 + '"/><audio controls style="display:none;"  id="ex_audio' + str4 + '" />' + str6;
                    IdArray.push(str4);
                    TypeArray.push('audio');
                }
                if (sourcetype == "file") {
                    for (i = 0; i <= ArrayFileguid.length - 1; i++) {
                        if (ArrayFileguid[i] == str4) {
                            str = str5 + '<a target="_blank" rel="noopener noreferrer" href="Upload/' + str4 + ArrayFileExtension[i] + '" >' + ArrayFileName[i] + '<a/>' + str6;
                            IdArray.push(str4);
                            TypeArray.push('file');
                            break;
                        }
                    }

                }
            }
        } while (bolExit == false);
        objReturn.str = str;
        objReturn.IdArray = IdArray;
        objReturn.TypeArray = TypeArray;
        return objReturn;
    }

    document.addEventListener('webkitfullscreenchange', exitHandler, false);
    document.addEventListener('mozfullscreenchange', exitHandler, false);
    document.addEventListener('fullscreenchange', exitHandler, false);
    document.addEventListener('MSFullscreenChange', exitHandler, false);

    function exitHandler() {
        var state = document.fullScreen || document.mozFullScreen || document.webkitIsFullScreen || document.msFullscreenElement;
        var event = state ? 'FullscreenOn' : 'FullscreenOff';
        if (event == 'FullscreenOff') {
            /* Run code on exit */
            $(".tp_eximage_nofullscreen").css("height", "90px");
        }
    }


    //handler to receive messages from user(callback)
    function fnUserMessageCallBack(message, chatTextId) {
        console.log("Message from user:" + message);
        var header;
        var k;
        var submessage;
        var parts;
        var objReplace;

        header = '<li class=\'liusersaid\' ><span class=\'userSaid\' >' + UserRenderHeader + '&nbsp;</span><span class=\'atTime\'>at&nbsp;' + fnFormatNowTime() + '</span>';
        if ($("#RequiresChatNotification").val() == "true") {
            header = header + '&nbsp;<img src="images/loading.gif" id="ReceivedMark' + chatTextId + '" style="height:18px;" />';
        }
        else {
            header = header + '&nbsp;';
        }
        header = header + '</li>';
        $('#messages').append(header);

        //bubble
        header = '<li class=\'triangle-isosceles\' >';
        submessage = message;
        submessage = submessage.replace('<br/>', '\n');
        parts = submessage.split('\n');
        var linkedText1;
        if ((parts[0].indexOf('[tpclient_external_image:') == -1)
            && (parts[0].indexOf('[tpclient_external_video:') == -1)
            && (parts[0].indexOf('[tpclient_external_audio:') == -1)
            && (parts[0].indexOf('[tpclient_external_file:') == -1)) {
            linkedText1 = Autolinker.link(parts[0], {
                newWindow: true,
                replaceFn: function (match) {
                    //bing maps
                    if ((match.getType() == 'url') && (match.getAnchorHref().includes("www.bing.com%2Fmaps%2F"))) {
                        return "<a href='" + match.getAnchorHref() + "' target='_blank' rel='noopener noreferrer'><img src='images/location.png' style='border:none;'></a>";
                    }
                    else {
                        return true;
                    }
                    //console.log("href = ", match.getAnchorHref());
                    //console.log("text = ", match.getAnchorText());
                }
            });
        }
        else {
            linkedText1 = parts[0];
        }
        header = header + '<span class=\'userText\'>&nbsp;' + linkedText1 + '</span>';

        for (k = 1; k < parts.length; k++) {
            var linkedText2;
            if ((parts[k].indexOf('[tpclient_external_image:') == -1)
                && (parts[k].indexOf('[tpclient_external_video:') == -1)
                && (parts[k].indexOf('[tpclient_external_audio:') == -1)
                && (parts[k].indexOf('[tpclient_external_file:') == -1)) {
                linkedText2 = Autolinker.link(parts[k], {
                    newWindow: true,
                    replaceFn: function (match) {
                        //bing maps
                        if ((match.getType() == 'url') && (match.getAnchorHref().includes("www.bing.com%2Fmaps%2F"))) {
                            return "<a href='" + match.getAnchorHref() + "' target='_blank' rel='noopener noreferrer'><img src='images/location.png' style='border:none;'></a>";
                        }
                        else {
                            return true;
                        }
                    }
                });
            }
            else {
                linkedText2 = parts[k];
            }
            header = header + '<span class=\'userText\'>&nbsp;' + linkedText2 + '</span>';
        }
        header = header + '</li>';
        //images
        objReplace = LocalReplaceTagData(header, '[tpclient_external_image:', 'image');
        header = objReplace.str;
        //set click handlers for images 
        for (k = 0; k <= objReplace.IdArray.length - 1; k++) {
            $("body").on('click', '#ex_image' + objReplace.IdArray[k], function () {
                var elem = document.getElementById(this.id);
                $("#" + this.id).css("height", "");
                if (elem.requestFullscreen) {
                    elem.requestFullscreen();
                } else if (elem.mozRequestFullScreen) {
                    elem.mozRequestFullScreen();
                } else if (elem.webkitRequestFullscreen) {
                    elem.webkitRequestFullscreen();
                } else if (elem.msRequestFullscreen) {
                    elem.msRequestFullscreen();
                }
            });
        }
        //videos
        objReplace = LocalReplaceTagData(header, '[tpclient_external_video:', 'video');
        header = objReplace.str;
        //set video source
        for (k = 0; k <= objReplace.IdArray.length - 1; k++) {
            setTimeout(function (p) {
                $("#ex_prog" + p).css("display", "none");
                $("#ex_video" + p).css("display", "block");
                $("#ex_video" + p).attr("src", "Upload/" + p + ".mp4");
                $("#messages").scrollTop($("#messages").get(0).scrollHeight);
            }, 4000, objReplace.IdArray[k]);
        }
        //audios
        objReplace = LocalReplaceTagData(header, '[tpclient_external_audio:', 'audio');
        header = objReplace.str;
        //set audio source
        for (k = 0; k <= objReplace.IdArray.length - 1; k++) {
            setTimeout(function (p) {
                $("#ex_prog" + p).css("display", "none");
                $("#ex_audio" + p).css("display", "block");
                $("#ex_audio" + p).attr("src", "Upload/" + p + ".mp4");
                $("#messages").scrollTop($("#messages").get(0).scrollHeight);
            }, 4000, objReplace.IdArray[k]);
        }
        //files
        objReplace = LocalReplaceTagData(header, '[tpclient_external_file:', 'file');
        header = objReplace.str;

        $('#messages').append(header);
        $("#messages").scrollTop($("#messages").get(0).scrollHeight);
        $("#chatMessageTextArea").val('');
        typingAlert = new Date();
        typingAlert.setDate(typingAlert.getDate() - 1);
        isTyping = false;

        if ($("#RequiresChatNotification").val() == "true") {
            setTimeout(function () {
                fnCheckIfWasReceived(chatTextId);
            }, 15000);
        }


    }

    function fnCheckIfWasReceived(ChatTextIdBD) {
        try {
            if ($("#ReceivedMark" + ChatTextIdBD).attr("src") == "images/loading.gif") {
                $("#ReceivedMark" + ChatTextIdBD).attr("src", "images/ChatMarkFailed.png");
            }
        } catch (e) { }
    }

    //handler to receive notification that agent is typing
    function fnAgentIsTyping() {
        $("#typingAlert").css('visibility', 'visible');
    }

    //handler to receive notification that agent is no typing
    function fnAgentNoTyping() {
        $("#typingAlert").css('visibility', 'hidden');
    }

    //handler to receive notification that mail transcript send ok
    function fnSendMailOk() {
        SwalSuccesMessage(SuccesSentEmailMessage);
    }

    //handler to receive notification that mail transcript send fail
    function fnSendMailFail() {
        SwalErrorMessage(FailSentEmailMessage);
    }

    //function to check if userStillTyping
    function fnCheckIfUserStillTyping() {
        var nowDate = new Date();
        var t1;
        var t2;
        if (isTyping == true) {
            t1 = typingAlert.getTime();
            t2 = nowDate.getTime();
            if (parseInt((t2 - t1) / 1000) > 30) {
                //user is not typing since last time
                isTyping = false;
                return false;
            }
            else {//user still typing
                return true;
            }
        }
        else {
            return false;
        }
    }

    //function to setup controls when chat end
    function fnClearControlsStateChat() {
        //disable controls ChattingDiv
        $("#chatMessageTextArea").attr("disabled", "disabled");
        $("#sendButton").attr("disabled", "disabled");
        $("#endButton").attr("disabled", "disabled");
        $("#chatMessageTextArea").attr("style", "display:none");
        $("#sendButton").attr("style", "display:none");
        $("#endButton").attr("style", "display:none");
        $("#typingAlert").css('visibility', 'hidden');

        $("#btnFileUpload").attr("disabled", "disabled");
        $("#UploadFileDiv").css("display", "none");
        $("#MediaAudioRecordingButton").css("display", "none");

        //viewdesktop question
        try {
            $("#ViewDesktopOfferQuestionDiv").dialog("close");
        }
        catch (ex) { }
        //viewdesktop run
        try {
            $("#viewDesktopRunDiv").dialog("close");
        }
        catch (ex) { }

        //hide video controls
        $("#StartVideoButton").css("display", "none");
        $("#EndVideoButton").css("display", "none");
        $("#VideoDiv").css("display", "none");
        $("#VideoUserIframe").attr("src", "about:blank");
        $("#overlayTPClient").css("display", "none");
        $("#ChatContainerDiv").css("display", "block");
        $("#GoCameraImage").css("display", "none");
        $("#GoChatImage").css("display", "none");
    }

    //handler to receive notification to ask permission to view desktop
    //see other handlers below to send answer to server
    function fnRequestViewDesktopPrompt() {
        //close viewDesktopRunDiv just in case is already open
        try {
            $("#viewDesktopRunDiv").dialog("close");
        }
        catch (ex) { }

        $('.modal-body').css('height', '80px');
        $("#ViewDesktopOfferQuestionDiv").modal("show");
    }

    //handler to receive notification to run ViewDesktop exe
    function fnRunViewDesktop(id, guid) {
        var windowViewDesktopOpenWindow;
        var d = new Date();
        windowViewDesktopOpenWindow = "ViewDesktopUser_Sample12.aspx?id=" + id + "&guid=" + guid + "&dummy=" + d.getTime();
        $("#viewDesktopRunIframe").attr("src", windowViewDesktopOpenWindow);

        $('.modal-body').css('height', '280px');
        $("#viewDesktopRunDiv").modal("show");
    }

    //handler to receive notification to close viewdesktop window
    function fnViewDesktopEnd() {
        try {
            $("#viewDesktopRunDiv").dialog("close");
        }
        catch (ex) { }
    }

    $('.nav-tabs').on('shown.bs.tab', function (event) {
        Chatresize();
    });

    //handler to receive notification to start transfer
    function fnStartTransfer() {
        //viewdesktop question
        try {
            $("#ViewDesktopOfferQuestionDiv").dialog("close");
        }
        catch (ex) { }
        //viewdesktop run
        try {
            $("#viewDesktopRunDiv").dialog("close");
        }
        catch (ex) { }

        $("#stillWaitingDiv").css("display", "none");
        $("#ChattingDiv").css("display", "none");

        //transfer controls
        $("#TabsDiv").hide();

        //video controls
        $("#StartVideoButton").css("display", "none");
        $("#EndVideoButton").css("display", "none");
        $("#VideoDiv").css("display", "none");
        $("#VideoUserIframe").attr("src", "about:blank");
        $("#ChatContainerDiv").css("display", "block");
        $("#GoChatImage").css("display", "none");
        $("#GoCameraImage").css("display", "none");
        $("#WaitingMessageLabel").css("display", "none");
        $("#QueuePositionLabel").css("display", "none");
        $("#QueuePositionValueLabel").css("display", "none");

        $("#TransferredMessageLabelrow").css("display", "block");
        $("#TransferredMessageLabel").css("display", "block");
        $("#RouterDiv").css("display", "block");
    }

    //handler to receive notification to route transfer
    function fnRouteTransfer(newChatRequest) {
        console.log(newChatRequest)
        var j;
        var submessage;
        j = window.location.href.indexOf("=");
        submessage = window.location.href.substring(0, j + 1);
        setTimeout(function () {
            window.location.href = submessage + newChatRequest;
        }, 3000);
    }

    //handler to receive notitication of transfer history
    function fnLinkHistoryTransfer(message) {
        console.log('transfer link');
        PageMethods.GetHistoryChatFromTPClientSite('CONNECTION', 'UNTIL', message, $("#webMethodsTokenHidden").val(), onSuccessGetHistoryChatFromTPClientSite, onErrorGetHistoryChatFromTPClientSite);
    }

    function onSuccessGetHistoryChatFromTPClientSite(result, userContext, methodName) {
        $("#ChatHistoryDiv").html(result);
        $("#ChatHistoryDiv a").each(function (index, element) {
            var linkText;
            linkText = $(this).text();

            $(this).replaceWith(function () { return linkText });
        });
        $("#TabsDiv").show();
    }

    function onErrorGetHistoryChatFromTPClientSite(result, userContext, methodName) {
        console.log("Error getting history transfer:" + result);
    }

    function fnSendUserMessageChat() {
        debugger;
        TPClientChatSample.UserSendMessage($("#chatMessageTextArea").val(), UserRenderHeader, UserName);
    }

    //handler to send messages
    $("#sendButton").click(function () {
        if ($("#chatMessageTextArea").val() != '') {
            fnSendUserMessageChat();
        }
        else {
            SwalErrorMessage('Please enter message to send');
            return;
        }
    });

    //handler to end chat
    $("#endButton").click(function () {

        //hide controls just in case not confirmation of end chat from agent is received
        fnClearControlsStateChat();
        TPClientChatSample.UserEndChat();
        window.location.href = "http://localhost:64016/ChatArea/ChatWithUs.aspx";
    });

    //handler for keyup and keydown in textarea to manage typing alerts,control enter and enter 
    $('#chatMessageTextArea').keyup(function (e) {
        var data;
        data = document.getElementById("chatMessageTextArea");
        var val = data.value;
        if (val.length == 0) {//Empty textbox
            typingAlert = new Date();
            typingAlert.setDate(typingAlert.getDate() - 1);
            isTyping = false;
            TPClientChatSample.UserNoTyping();
        }
    });

    $('#chatMessageTextArea').keydown(function (e) {
        var nowDate = new Date();
        var t1;
        var t2;
        var data;
        t1 = typingAlert.getTime();
        t2 = nowDate.getTime();
        if (parseInt((t2 - t1) / 1000) > 15) {
            TPClientChatSample.UserIsTyping();
        }
        typingAlert = nowDate;
        isTyping = true;
        if (e.which == 13) {
            if (e.ctrlKey || e.metaKey) {
                data = document.getElementById("chatMessageTextArea");
                var val = data.value;
                if (typeof data.selectionStart == "number" && typeof data.selectionEnd == "number") {
                    var start = data.selectionStart;
                    data.value = val.slice(0, start) + "\n" + val.slice(data.selectionEnd);
                    data.selectionStart = data.selectionEnd = start + 1;
                } else if (document.selection && document.selection.createRange) {
                    data.focus();
                    var range = document.selection.createRange();
                    range.text = "\r\n";
                    range.collapse(false);
                    range.select();
                }
            }
            else {
                e.preventDefault();
                fnSendUserMessageChat();
            }
        }
    });

    //handler to manage send transcript 
    if (offerMail) {
        $("#mailButton").click(function () {
            TPClientChatSample.RequestChatTranscriptByMail();
            $("#mailButton").css("display", "none");
        });
    }

    //handler to accept view desktop
    $("#GrantAllowViewDesktopButton").click(function () {
        $("#ViewDesktopOfferQuestionDiv").modal("hide");
        TPClientChatSample.UserAcceptViewDesktop();
    });

    //handler to reject view desktop
    $("#DenyViewDesktopButton").click(function () {
        $("#ViewDesktopOfferQuestionDiv").modal("hide");
        TPClientChatSample.UserRejectViewDesktop();
    });

    //handlers to start and stop video
    $("#StartVideoButton").click(function () {
        fnRealStartVideoButtonClick();
    });

    function fnRealStartVideoButtonClick() {
        var d = new Date();
        $("#VideoUserIframe").attr("src", "WEBRTC_User_Sample12.aspx?idConnection=" + selectedConnectionIdBD + "&dummy=" + d.getTime());
        $("#VideoDiv").css("display", "block");
        $("#StartVideoButton").css("display", "none");
        $("#EndVideoButton").css("display", "block");
        $("#ChatContainerDiv").css("display", "none");

        $("#GoChatImage").css("display", "block");
        $("#VideoEnabled").val("1");
        setTimeout(function () { Chatresize(); }, 100);
        LoadingModal.Show();
        TPClientChatSample.StartVideo();
    }


    $("#EndVideoButton").click(function () {
        $("#VideoUserIframe").attr("src", "about:blank");
        $("#VideoDiv").css("display", "none");
        $("#StartVideoButton").css("display", "block");
        $("#EndVideoButton").css("display", "none");

        $("#ChatContainerDiv").css("display", "block");
        $("#GoCameraImage").css("display", "none");
        $("#GoChatImage").css("display", "none");
        $("#VideoEnabled").val("0");
        setTimeout(function () { Chatresize(); }, 100);
        TPClientChatSample.EndVideo();
    });

    $("#GoCameraImage").click(function () {
        $("#ChatContainerDiv").css("display", "none");
        $("#VideoDiv").css("display", "block");
        $("#GoCameraImage").css("display", "none");
        $("#GoChatImage").css("display", "block");
        Chatresize();
    });

    $("#GoChatImage").click(function () {
        $("#ChatContainerDiv").css("display", "block");
        $("#VideoDiv").css("display", "none");
        $("#GoCameraImage").css("display", "block");
        $("#GoChatImage").css("display", "none");
        Chatresize();
    });

    //handler triggered when webrtc on agent side is enabled
    function fnWebRTCAgentEnabled() {
        //webrtc is also enabled on agent side desktop, Android
        $("#StartVideoButton").css("display", "block");

        if (IEClickButton) {
            fnRealStartVideoButtonClick();
        }
    }

    //handler triggered when webrtc on agent side is not enabled
    function fnWebRTCAgentDisabled() {
        console.log("fnWebRTCAgentDisabled");
    }

    //handler to manage network errors
    function fnNetworkError(Message) {
        console.log(Message);
    }
    //handler to manage confirmation from agent that has received the message send by the user
    function fnHandleMarkReceivedMessage(ChatMessageIdBD) {
        $("#ReceivedMark" + ChatMessageIdBD).attr("src", "images/ChatMarkReceived.png");
    }

    //3. Create Object
    TPClientChatSample = new Teleperformance.TPClient.ExternalTools.ChatV32(UrlTPClientSite);

    alert(TPClientChatSample)
    alert(fnStarHubOk)
    alert(fnStartHubFail)


    //4. Set Object Handlers
    TPClientChatSample.Fn_Event_NetworkError = fnNetworkError;//mandatory new since 5.0
    TPClientChatSample.Fn_Event_Hub_StartOk = fnStarHubOk;//mandatory
    TPClientChatSample.Fn_Event_Hub_StartFail = fnStartHubFail;//mandatory
    TPClientChatSample.Fn_Encrypt_SimmetrycKeyWith_RSA = fnEncryptSymmetricWithRSA;//mandatory
    TPClientChatSample.Fn_EncryptMessageHub = fnEncryptmessageHub;//mandatory
    TPClientChatSample.Fn_DecryptMessageHub = fnDecryptmessageHub;//mandatory
    TPClientChatSample.Fn_Event_RoutingToAgentsFail = fnRoutingToAgentsFail;//mandatory
    TPClientChatSample.Fn_Event_RoutingToAgentsOK = fnRoutingToAgentsOk;//mandatory
    TPClientChatSample.Fn_Event_ChatEnd = fnChatEnd;//mandatory
    TPClientChatSample.Fn_Event_Receive_Message = fnReceiveMessage;//mandatory
    TPClientChatSample.Fn_Event_UserMessageCallback = fnUserMessageCallBack;//mandatory

    TPClientChatSample.Fn_Event_AgentIsTyping = fnAgentIsTyping;//optional, mandatory if you want to implement typing alerts
    TPClientChatSample.Fn_Event_AgentNoTyping = fnAgentNoTyping;//optional, mandatory if you want to implement typing alerts
    TPClientChatSample.Fn_CheckIfUserStillTyping = fnCheckIfUserStillTyping;//optional, mandatory if you want to implement typing alerts

    TPClientChatSample.Fn_Event_EmailTranscriptOk = fnSendMailOk;//optional, mandatory if you want to implement send chat transcript by mail
    TPClientChatSample.Fn_Event_EmailTranscriptFail = fnSendMailFail;//optional, mandatory if you want to implement send chat transcript by mail

    TPClientChatSample.Fn_RequestViewDesktopPrompt = fnRequestViewDesktopPrompt;//optional, mandatory if you want to implement viewdesktop feature
    TPClientChatSample.Fn_Event_ViewDesktopData = fnRunViewDesktop;//optional, mandatory if you want to implement viewdesktop feature
    TPClientChatSample.Fn_Event_ViewDesktopEnd = fnViewDesktopEnd;//optional, mandatory if you want to implement viewdesktop feature

    TPClientChatSample.Fn_Event_StartTransfer = fnStartTransfer;//optional, mandatory if you want to implement transfer feature
    TPClientChatSample.Fn_Event_RouteTransfer = fnRouteTransfer;//optional, mandatory if you want to implement transfer feature
    TPClientChatSample.Fn_Event_LinkHistoryTransfer = fnLinkHistoryTransfer;//optional, mandatory if you want to implement transfer feature

    TPClientChatSample.Fn_Event_WebRTCAgentSideFail = fnWebRTCAgentDisabled;//optional, mandatory if you want to implement video feature
    TPClientChatSample.Fn_Event_WebRTCAgentSideOK = fnWebRTCAgentEnabled;//optional, mandatory if you want to implement video feature
    //TPClientChatSample.Fn_Event_FlashAgentSideOK     DEPRECATED
    //TPClientChatSample.Fn_Event_WebRTC_StartDialog  DEPRECATED
    //TPClientChatSample.Fn_Event_WebRTC_AgentCreatedPeer DEPRECATED
    //TPClientChatSample.Fn_Event_WebRTC_AgentSendSDP  DEPRECATED
    //TPClientChatSample.Fn_Event_WebRTC_AgentSendCandiatae DEPRECATED
    //TPClientChatSample.Fn_Event_WebRTC_FlashFallBack DEPRECATED
    //TPClientChatSample.Fn_Event_WebRTC_AllSucceeded DEPRECATED
    //TPClientChatSample.Fn_Event_WebRTCTechTicketCreated = fnAgentCreateTicket;
    //TPClientChatSample.Fn_Event_WebRTCTechOpentokDataCreated = fnOpenTockDataCreated;
    TPClientChatSample.Fn_Event_AgentReceivedMessage = fnHandleMarkReceivedMessage;

    TPClientChatSample.ChatRequestId = $("#ChatRequestIdHidden").val();

    //4. Call Init and check for errors
    ErrorMessage = TPClientChatSample.Init();
    if (ErrorMessage != "SUCCESS") {
        //critical error
        SwalErrorMessage(ErrorMessage);
        return;
    }

    //5. Call StartHub and wait for response
    TPClientChatSample.StartHub();
});//Document Ready

//other global handlers for video feature

function isIE() {
    var userAgent = window.navigator.userAgent.toLowerCase(),
        appName = window.navigator.appName;

    return (appName === 'Microsoft Internet Explorer' ||                     // IE <= 10
        (appName === 'Netscape' && userAgent.indexOf('trident') > -1)); // IE >= 11
}

function DetectWEBRTC_TECH() {
    try {
        if (isIE()) {
            return false;
        }
        var r = OT.checkSystemRequirements();
        if (r == 1) {
            return true;
        }
        else {
            return false;
        }
    }
    catch (e) {
        return false;
    }
}

function fnViewDesktopClose() {
    try {
        $("#viewDesktopRunDiv").dialog("close");
    }
    catch (ex) { }
}

function SwalErrorMessage(message) {
    swal("Oops", message, "error");
}

function SwalSuccesMessage(message) {
    swal("", message, "success");
}

function fnResize() {
    $(window).resize();
}

function StartNegotiateDetectVideoAgent() {
    chatConnectionIdEncrypted = "";
    Nonce = "";
    PageMethods.EncryptChatConnection(selectedConnectionIdBD, $("#webMethodsTokenHidden").val(), onSuccessEncryptChatConnection, onErrorEncryptChatConnection);
}

function onSuccessEncryptChatConnection(result, userContext, methodName) {
    if (result != "") {
        //alert(result);
        chatConnectionIdEncrypted = result.split("|")[0];
        Nonce = result.split("|")[1];
        //detect webrtc agent 
        if ($("#AUDIOONLY_SAMPLE12_TEXTBOX").val() == "1") {
            TPClientChatSample.DetectWebRTC_TECH_AgentSide($("#Id_GROUHidden").val(), 'DESKTOP', $("#urlHexTextBox").val(), chatConnectionIdEncrypted, 1);
        }
        else {
            TPClientChatSample.DetectWebRTC_TECH_AgentSide($("#Id_GROUHidden").val(), 'DESKTOP', $("#urlHexTextBox").val(), chatConnectionIdEncrypted, 0);
        }
    }
}

function onErrorEncryptChatConnection(error, userContext, methodName) {
    chatConnectionIdEncrypted = "";
}


function StartRecordAudio() {
    $("#AudioPlayerRecordMediaDiv").html("");
    navigator.mediaDevices.getUserMedia({ audio: true })
        .then(function (stream) {
            MediaAudioRecorder = new MediaRecorder(stream)

            MediaAudioRecorder.addEventListener('dataavailable', saveMediaAudioRecord)
            $("#StartRecordMediaAudioImage").css("display", "none");
            $("#StartRecordMediaAudioButton").css("display", "none");
            $("#RecordingMediaAudioImage").css("display", "block");
            $("#StopRecordMediaAudioButton").css("display", "block");
            MediaAudioRecorder.start();
        })
        .catch(function (err) {
            console.log('audio blocked');
        });
}

function saveMediaAudioRecord(e) {
    RecordedAudio = e.data;
    $("#AudioPlayerRecordMediaDiv").html("");
    var audio = document.createElement('audio');
    audio.controls = true;
    audio.src = URL.createObjectURL(e.data);
    document.getElementById("AudioPlayerRecordMediaDiv").appendChild(audio);
}

function StopRecordAudio() {
    $("#AudioPlayerRecordMediaDiv").html("");
    $("#StopRecordMediaAudioButton").css("display", "none");
    $("#RecordingMediaAudioImage").css("display", "none");
    $(".sa-confirm-button-container").css("display", "inline-block");
    MediaAudioRecorder.stop();
    MediaAudioRecorder.stream.getTracks()[0].stop();
}
