/// <reference path="typings/signalr/signalr.d.ts" />
var Teleperformance;
(function (Teleperformance) {
    var TPClient;
    (function (TPClient) {
        var ExternalTools;
        (function (ExternalTools) {
            var ChatV32 = (function () {
                function ChatV32(varUrlTPClientSite) {
                    //url must ends with /
                    if (varUrlTPClientSite.substring(varUrlTPClientSite.length - 1, varUrlTPClientSite.length) != '/') {
                        //fix it
                        varUrlTPClientSite = varUrlTPClientSite + "/";
                    }
                    this.privateUrlTPClientSite = varUrlTPClientSite;
                    this.ChatRequestId = "";
                    this.ReopenId = "0";
                    this.privateProxyChat = null;
                    this.privateSymmetrickey1 = "";
                    this.Fn_Event_NetworkError = null;
                    this.Fn_Event_Hub_StartOk = null;
                    this.Fn_Event_Hub_StartFail = null;
                    this.Fn_Encrypt_SimmetrycKeyWith_RSA = null;
                    this.Fn_DecryptMessageHub = null;
                    this.Fn_EncryptMessageHub = null;
                    this.Fn_Event_RoutingToAgentsFail = null;
                    this.Fn_Event_RoutingToAgentsOK = null;
                    this.Fn_Event_ChatEnd = null;
                    this.Fn_Event_Receive_Message = null;
                    this.Fn_Event_UserMessageCallback = null;
                    this.Fn_Event_AgentIsTyping = null;
                    this.Fn_Event_AgentNoTyping = null;
                    this.Fn_CheckIfUserStillTyping = null;
                    this.Fn_Event_EmailTranscriptFail = null;
                    this.Fn_Event_EmailTranscriptOk = null;
                    this.Fn_RequestViewDesktopPrompt = null;
                    this.Fn_Event_ViewDesktopData = null;
                    this.Fn_Event_ViewDesktopEnd = null;
                    this.Fn_Event_StartTransfer = null;
                    this.Fn_Event_RouteTransfer = null;
                    this.Fn_Event_LinkHistoryTransfer = null;
                    this.Fn_Event_WebRTCAgentSideOK = null;
                    this.Fn_Event_WebRTCAgentSideFail = null;
                    //            this.Fn_Event_FlashAgentSideOK = null;
                    //            this.Fn_Event_WebRTC_StartDialog = null;
                    //            this.Fn_Event_WebRTC_AgentCreatedPeer = null;
                    //            this.Fn_Event_WebRTC_AgentSendSDP = null;
                    //            this.Fn_Event_WebRTC_AgentSendCandiatae = null;
                    //            this.Fn_Event_WebRTC_FlashFallBack = null;
                    //            this.Fn_Event_WebRTC_AllSucceeded = null;
                    this.Fn_Event_WebRTCTechTicketCreated = null;
                    this.Fn_Event_WebRTCTechOpentokDataCreated = null;
                    this.Fn_Event_AgentReceivedMessage = null;
                    this.Fn_Event_ReconnectFail = null;
                    this.Fn_Event_KeepAliveFireIt = null;
                    this.RoutingMode = "AUTOMATIC";
                    this.privateScreenStatus = "Routing";
                    this.privateSelectedConnectionIdBD = "0";
                }
                //Cryptography Functions
                ChatV32.prototype.privateGetRandomInt = function (min, max) {
                    return Math.floor(Math.random() * (max - min + 1)) + min;
                };
                ChatV32.prototype.privateGenerateSymmetricKey = function () {
                    var i;
                    var onehex;
                    //create symmetric key on the fly
                    for (i = 1; i <= 32; i++) {
                        onehex = this.privateGetRandomInt(0, 255).toString(16);
                        if (onehex.length == 1) {
                            onehex = '0' + onehex;
                        }
                        this.privateSymmetrickey1 = this.privateSymmetrickey1 + onehex;
                        if (i == 16) {
                            this.privateSymmetrickey1 = this.privateSymmetrickey1 + "^";
                        }
                    }
                };
                ChatV32.prototype.privateSendnetworkError = function (ThisObj, Message) {
                    try {
                        ThisObj.privateScreenStatus = "End";
                        ThisObj.Fn_Event_NetworkError(Message);
                    }
                    catch (ex) {
                        console.log('error sending fnSendnetworkError');
                        console.log(ex);
                        console.log(Message);
                    }
                };
                //Init RSADialog
                ChatV32.prototype.privateInitRSADialog = function (ThisObj) {
                    var Message;
                    Message = ThisObj.Fn_Encrypt_SimmetrycKeyWith_RSA(this.privateSymmetrickey1);
                    try {
                        ThisObj.privateProxyChat.server.createNewSignalRClient(Message);
                    }
                    catch (ex) {
                        console.log('error sending createNewSignalRClient');
                        console.log(ex);
                        ThisObj.privateSendnetworkError(ThisObj, 'error sending createNewSignalRClient');
                        return;
                    }
                };
                ChatV32.prototype.privateFnKeepAliveHub = function (ThisObj) {
                    var r;
                    if (ThisObj.privateScreenStatus != "End") {
                        console.log('Enter privateFnKeepAliveHub');
                        //update keep alive hub
                        try {
                            //console.log('KeeAlive hub user side');
                            ThisObj.privateProxyChat.server.keepAliveSignalRConnection();
                            if (ThisObj.Fn_Event_KeepAliveFireIt) {
                                ThisObj.Fn_Event_KeepAliveFireIt($.connection.hub.id);
                            }
                        }
                        catch (ex) {
                            console.log('Error sending keepAliveSignalRConnection');
                            console.log(ex);
                            ThisObj.privateSendnetworkError(ThisObj, 'Error sending keepAliveSignalRConnection');
                            setTimeout(function () { ThisObj.privateFnKeepAliveHub(ThisObj); }, 15000);
                            return;
                        }
                        //if state = chatting update keep alive connection
                        if (ThisObj.privateScreenStatus == "Chatting") {
                            try {
                                //console.log('KeeAlive chat user side');
                                ThisObj.privateProxyChat.server.chat_UpdateKeepAliveUserChatConnection(ThisObj.Fn_EncryptMessageHub(ThisObj.privateSelectedConnectionIdBD, ThisObj.privateSymmetrickey1));
                            }
                            catch (ex) {
                                console.log('Error sending chat_UpdateKeepAliveUserChatConnection');
                                console.log(ex);
                                ThisObj.privateSendnetworkError(ThisObj, 'Error sending chat_UpdateKeepAliveUserChatConnection');
                                setTimeout(function () { ThisObj.privateFnKeepAliveHub(ThisObj); }, 15000);
                                return;
                            }
                            //check if user is typing
                            if (ThisObj.Fn_CheckIfUserStillTyping != null) {
                                r = ThisObj.Fn_CheckIfUserStillTyping();
                                if (!r) {
                                    ThisObj.UserNoTyping();
                                }
                            }
                        }
                        //loop timer
                        setTimeout(function () { ThisObj.privateFnKeepAliveHub(ThisObj); }, 30000);
                    }
                };
                ChatV32.prototype.privateFnTryRouting = function (ThisObj) {
                    try {
                        ThisObj.privateProxyChat.server.chat_TryConnect(ThisObj.Fn_EncryptMessageHub(ThisObj.ChatRequestId, ThisObj.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending chat_TryConnect');
                        console.log(ex);
                        ThisObj.privateSendnetworkError(ThisObj, 'Error sending chat_TryConnect');
                        return;
                    }
                };
                ChatV32.prototype.fnTryRoutingAgain = function (delayMilliseconds) {
                    var ThisObj;
                    ThisObj = this;
                    setTimeout(function () { ThisObj.privateFnTryRouting(ThisObj); }, delayMilliseconds);
                };
                ChatV32.prototype.fnAbortRoutingChat = function () {
                    this.privateScreenStatus = 'Abort';
                };
                ChatV32.prototype.UserIsTyping = function () {
                    //console.log('user is typing');
                    try {
                        this.privateProxyChat.server.chat_UserIsTyping(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending chat_UserIsTyping');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending chat_UserIsTyping');
                        return;
                    }
                };
                ChatV32.prototype.UserNoTyping = function () {
                    //console.log('user no typing');
                    try {
                        this.privateProxyChat.server.chat_UserIsNoTyping(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending chat_UserIsNoTyping');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending chat_UserIsNoTyping');
                        return;
                    }
                };
                ChatV32.prototype.UserSendMessage = function (message, UserRenderHeader, UserName) {
//debugger;
                    try {
                        //console.log('user send message');
                        this.privateProxyChat.server.chat_UserSendMessage(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1), this.Fn_EncryptMessageHub(message, this.privateSymmetrickey1), this.Fn_EncryptMessageHub(UserRenderHeader, this.privateSymmetrickey1), this.Fn_EncryptMessageHub(UserName, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending chat_UserSendMessage');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending chat_UserSendMessage');
                        return;
                    }
                };
                ChatV32.prototype.UserEndChat = function () {
//debugger;
                    //console.log('user ends');
                    try {
                        this.privateProxyChat.server.chat_UserEndChat(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending chat_UserEndChat');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending chat_UserEndChat');
                        return;
                    }
                };
                ChatV32.prototype.RequestChatTranscriptByMail = function () {
                    try {
                        this.privateProxyChat.server.chat_UserRequestSendMailChat(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending chat_UserRequestSendMailChat');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending chat_UserRequestSendMailChat');
                        return;
                    }
                };
                ChatV32.prototype.UserAcceptViewDesktop = function () {
                    //console.log('user accepts view desktop');
                    //this.privateProxyChat.server.send(this.Fn_EncryptMessageHub("CHA_ALLOWVIEWDESKTOP:" + this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    try {
                        this.privateProxyChat.server.viewDesktop_UserAccept(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending viewDesktop_UserAccept');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending viewDesktop_UserAccept');
                        return;
                    }
                };
                ChatV32.prototype.UserRejectViewDesktop = function () {
                    //console.log('user rejects view desktop');
                    //this.privateProxyChat.server.send(this.Fn_EncryptMessageHub("CHA_DENYVIEWDESKTOP:" + this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    try {
                        this.privateProxyChat.server.viewDesktop_UserReject(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending viewDesktop_UserReject');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending viewDesktop_UserReject');
                        return;
                    }
                };
                ChatV32.prototype.DetectWebRTC_TECH_AgentSide = function (QueueId, UserDeviceType, urlhexcustomsite, connectionIdEncryptedWithCustomSiteRSAandHex, audioonly) {
                    //user have installed webrtc browser
                    //send message to agent to verify if agent also have installed webrtc
                    try {
                        this.privateProxyChat.server.chat_DetectWEBRTCAgentSide(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1), this.Fn_EncryptMessageHub(QueueId.toString(), this.privateSymmetrickey1), this.Fn_EncryptMessageHub(UserDeviceType, this.privateSymmetrickey1), this.Fn_EncryptMessageHub(urlhexcustomsite, this.privateSymmetrickey1), this.Fn_EncryptMessageHub(connectionIdEncryptedWithCustomSiteRSAandHex, this.privateSymmetrickey1), this.Fn_EncryptMessageHub(audioonly.toString(), this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending chat_DetectWEBRTCAgentSide');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending chat_DetectWEBRTCAgentSide');
                        return;
                    }
                };
                ChatV32.prototype.StartVideoSafari = function () {
                    try {
                        this.privateProxyChat.server.chat_StartVideoSafari(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending chat_StartVideoSafari');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending chat_StartVideoSafari');
                        return;
                    }
                };
                ChatV32.prototype.StartVideo = function () {
                    try {
                        this.privateProxyChat.server.chat_StartVideo(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending chat_StartVideo');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending chat_StartVideo');
                        return;
                    }
                };
                ChatV32.prototype.EndVideo = function () {
                    try {
                        this.privateProxyChat.server.chat_EndVideo(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending chat_EndVideo');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending chat_EndVideo');
                        return;
                    }
                };
                ChatV32.prototype.privateFnTryReopen = function (ThisObj) {
                    try {
                        ThisObj.privateProxyChat.server.chat_TryReopen(ThisObj.Fn_EncryptMessageHub(ThisObj.ReopenId, ThisObj.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending chat_TryReopen');
                        console.log(ex);
                        ThisObj.privateSendnetworkError(ThisObj, 'Error sending chat_TryReopen');
                        return;
                    }
                };
                ChatV32.prototype.UserStartVideoIniOS = function () {
                    try {
                        this.privateProxyChat.server.chat_UserStartVideoIniOS(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending UserStartVideoIniOS');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending chat_UserStartVideoIniOS');
                        return;
                    }
                };
                ChatV32.prototype.ConfirmReceivedMessageUser = function (MessageChatIdBD) {
                    try {
                        this.privateProxyChat.server.chat_ConfirmReceivedMessageUser(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1), this.Fn_EncryptMessageHub(MessageChatIdBD, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending ConfirmReceivedMessage');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending chat_ConfirmReceivedMessage');
                        return;
                    }
                };
                ChatV32.prototype.SendKeyValues = function (JsonKeyValueList) {
                    try {
                        this.privateProxyChat.server.chat_SendKeyValues(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1), this.Fn_EncryptMessageHub(JsonKeyValueList, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending SendKeyValues');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending chat_SendKeyValues');
                        return;
                    }
                };
                ChatV32.prototype.Chat_Reconnect = function () {
                    try {
                        this.privateProxyChat.server.chat_Reconnect(this.Fn_EncryptMessageHub(this.privateSelectedConnectionIdBD, this.privateSymmetrickey1));
                    }
                    catch (ex) {
                        console.log('Error sending Chat_Reconnect');
                        console.log(ex);
                        this.privateSendnetworkError(this, 'Error sending Chat_Reconnect');
                        return;
                    }
                };
                ChatV32.prototype.Init = function () {
                    var ThisObj;
                    var ErrorMessage;
                    ThisObj = this;
                    ErrorMessage = "";
                    //check if all minimun functions are in place
                    if (this.Fn_Event_NetworkError == null) {
                        ErrorMessage = "Fn_Event_NetworkError is not set. You must set it before call Init";
                        return ErrorMessage;
                    }
                    if (this.Fn_Event_Hub_StartOk == null) {
                        ErrorMessage = "Fn_Event_Hub_StartOk is not set. You must set it before call Init";
                        return ErrorMessage;
                    }
                    if (this.Fn_Event_Hub_StartFail == null) {
                        ErrorMessage = "Fn_Event_Hub_StartFail is not set. You must set it before call Init";
                        return ErrorMessage;
                    }
                    if (this.Fn_Encrypt_SimmetrycKeyWith_RSA == null) {
                        ErrorMessage = "Fn_Encrypt_SimmetrycKeyWith_RSA is not set. You must set it before call Init";
                        return ErrorMessage;
                    }
                    if (this.Fn_DecryptMessageHub == null) {
                        ErrorMessage = "Fn_DecryptMessageHub is not set. You must set it before call Init";
                        return ErrorMessage;
                    }
                    if (this.Fn_EncryptMessageHub == null) {
                        ErrorMessage = "Fn_EncryptMessageHub is not set. You must set it before call Init";
                        return ErrorMessage;
                    }
                    if (this.Fn_Event_RoutingToAgentsFail == null) {
                        ErrorMessage = "Fn_Event_RoutingToAgentsFail is not set. You must set it before call Init";
                        return ErrorMessage;
                    }
                    if (this.Fn_Event_RoutingToAgentsOK == null) {
                        ErrorMessage = "Fn_Event_RoutingToAgentsOK is not set. You must set it before call Init";
                        return ErrorMessage;
                    }
                    if (this.Fn_Event_ChatEnd == null) {
                        ErrorMessage = "Fn_Event_ChatEnd is not set. You must set it before call Init";
                        return ErrorMessage;
                    }
                    if (this.Fn_Event_Receive_Message == null) {
                        ErrorMessage = "Fn_Event_Receive_Message is not set. Use Set_Fn_Event_Receive_Message before Init";
                        return ErrorMessage;
                    }
                    if (this.Fn_Event_UserMessageCallback == null) {
                        ErrorMessage = "Fn_Event_UserMessageCallback is not set. You must set it before call Init";
                        return ErrorMessage;
                    }
                    //generate symmetrickey
                    this.privateGenerateSymmetricKey();
                    //set url hub
                    try {
                        $.connection.hub.url = this.privateUrlTPClientSite + "signalr";
                    }
                    catch (ex) {
                        ErrorMessage = "Error setting hub.url property";
                        return ErrorMessage;
                    }
                    //set error function
                    try {
                        $.connection.hub.error(function (error) {
                            console.log('SignalR error: ' + error);
                            //ThisObj.privateScreenStatus = "End";
                            //try {
                            //    $.connection.hub.stop();
                            //} catch (ex) { }
                            //setTimeout(function () {
                            //    ThisObj.Fn_Event_NetworkError('SignalR error: ' + error);
                            //}, 5000);
                        });
                    }
                    catch (ex) {
                        ErrorMessage = "Error setting connection.hub.error handler";
                        return ErrorMessage;
                    }
                    //set disconnect function
                    try {
                        $.connection.hub.disconnected(function () {
                            console.log('SignalR disconnected:');
                        });
                    }
                    catch (ex) {
                    }
                    //get proxy reference
                    try {
                        this.privateProxyChat = $.connection.tPSignalRHub;
                    }
                    catch (ex) {
                        ErrorMessage = "Error getting proxy reference";
                        return ErrorMessage;
                    }
                    //map the server functions with local function
                    //receive ack set symmetric key
                    try {
                        this.privateProxyChat.client.receive_ACK_SetSymmetricKey = function () {
                            ThisObj.privateReceive_ACK_SetSymmetricKey(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ACK_SetSymmetricKey";
                        return ErrorMessage;
                    }
                    //receive ack try connect (if successfully establish a connection selectedConnectionIdBD<>0)
                    try {
                        this.privateProxyChat.client.receive_ACK_TryConnect = function (selectedConnectionIdBD, QueuePos, EWT) {
                            ThisObj.privateReceive_ACK_TryConnect(ThisObj, selectedConnectionIdBD, QueuePos, EWT);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ACK_TryConnect";
                        return ErrorMessage;
                    }
                    //receive MessageCallback from user
                    try {
                        this.privateProxyChat.client.receive_ChatMessageUserCallback = function (EncryptedChatMessage, EncryptedChatMessageIdBD) {
                            ThisObj.privateReceive_ChatMessageUserCallback(ThisObj, EncryptedChatMessage, EncryptedChatMessageIdBD);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ChatMessageUserCallback";
                        return ErrorMessage;
                    }
                    //receive Agent send message
                    try {
                        this.privateProxyChat.client.receive_ChatMessageFromAgent = function (EncryptedChatMessage, EncryptedAgentRenderHeader, EncryptedChatTextId) {
                            ThisObj.receive_ChatMessageFromAgent(ThisObj, EncryptedChatMessage, EncryptedAgentRenderHeader, EncryptedChatTextId);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ChatMessageFromAgent";
                        return ErrorMessage;
                    }
                    //receive Agent is typing
                    try {
                        this.privateProxyChat.client.receive_ChatAgentIsTyping = function () {
                            ThisObj.receive_ChatAgentIsTyping(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ChatAgentIsTyping";
                        return ErrorMessage;
                    }
                    //receive Agent not typing
                    try {
                        this.privateProxyChat.client.receive_ChatAgentIsNoTyping = function () {
                            ThisObj.receive_ChatAgentIsNoTyping(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ChatAgentIsNoTyping";
                        return ErrorMessage;
                    }
                    //receive Chat End
                    try {
                        this.privateProxyChat.client.receive_ChatEnd = function () {
                            ThisObj.receive_ChatEnd(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ChatEnd";
                        return ErrorMessage;
                    }
                    //receive Chat Send Mail Fail
                    try {
                        this.privateProxyChat.client.receive_ChatSendMailFail = function () {
                            ThisObj.receive_ChatSendMailFail(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ChatSendMailFail";
                        return ErrorMessage;
                    }
                    //receive Chat Send Mail Success
                    try {
                        this.privateProxyChat.client.receive_ChatSendMailSuccess = function () {
                            ThisObj.receive_ChatSendMailSuccess(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ChatSendMailSuccess";
                        return ErrorMessage;
                    }
                    //receive Chat Start Transfer
                    try {
                        this.privateProxyChat.client.receive_ChatStartTransfer = function () {
                            ThisObj.receive_ChatStartTransfer(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ChatStartTransfer";
                        return ErrorMessage;
                    }
                    //receive Chat Route Transfer
                    try {
                        this.privateProxyChat.client.receive_ChatRouteTransfer = function (NewChatRequestIdEncrypted) {
                            ThisObj.receive_ChatRouteTransfer(ThisObj, NewChatRequestIdEncrypted);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ChatRouteTransfer";
                        return ErrorMessage;
                    }
                    //receive_Chat_AgentEndChat
                    try {
                        this.privateProxyChat.client.receive_Chat_AgentEndChat = function () {
                            ThisObj.receive_Chat_AgentEndChat(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_Chat_UserAgentChat";
                        return ErrorMessage;
                    }
                    //receive_Chat_ChatEnd
                    try {
                        this.privateProxyChat.client.receive_Chat_ChatEnd = function () {
                            ThisObj.receive_Chat_ChatEnd(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_Chat_ChatEnd";
                        return ErrorMessage;
                    }
                    //receive_ChatLinkTransfer
                    try {
                        this.privateProxyChat.client.receive_ChatLinkTransfer = function (EncryptedLinkTransfer) {
                            ThisObj.receive_ChatLinkTransfer(ThisObj, EncryptedLinkTransfer);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ChatLinkTransfer";
                        return ErrorMessage;
                    }
                    //receive_Chat_WebRTAgentEnabled
                    try {
                        this.privateProxyChat.client.receive_Chat_WebRTAgentEnabled = function () {
                            ThisObj.receive_Chat_WebRTAgentEnabled(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_Chat_WebRTAgentEnabled";
                        return ErrorMessage;
                    }
                    //receive_Chat_WebRTAgentDisabled
                    try {
                        this.privateProxyChat.client.receive_Chat_WebRTAgentDisabled = function () {
                            ThisObj.receive_Chat_WebRTAgentDisabled(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_Chat_WebRTAgentDisabled";
                        return ErrorMessage;
                    }
                    //receive_Chat_RequestViewDesktopPrompt
                    try {
                        this.privateProxyChat.client.receive_Chat_RequestViewDesktopPrompt = function () {
                            ThisObj.receive_Chat_RequestViewDesktopPrompt(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_Chat_RequestViewDesktopPrompt";
                        return ErrorMessage;
                    }
                    //receive_ViewDesktopGuidData
                    try {
                        this.privateProxyChat.client.receive_ViewDesktopGuidData = function (ConnectionIdEncrypted, OneGuidEncrypted) {
                            ThisObj.receive_ViewDesktopGuidData(ThisObj, ConnectionIdEncrypted, OneGuidEncrypted);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ViewDesktopGuidData";
                        return ErrorMessage;
                    }
                    //receive_ACK_TryReopen
                    try {
                        this.privateProxyChat.client.receive_ACK_TryReopen = function (ResultTryReopen, ChatRequestEncrypted, ConnectionIDBDEncrypted) {
                            ThisObj.receive_ACK_TryReopen(ThisObj, ResultTryReopen, ChatRequestEncrypted, ConnectionIDBDEncrypted);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ACK_TryReopen";
                        return ErrorMessage;
                    }
                    //receive_Chat_WebRTCAgentCreatedTicket
                    try {
                        this.privateProxyChat.client.receive_Chat_WebRTCAgentCreatedTicket = function (TicketEncrypted) {
                            ThisObj.receive_Chat_WebRTCAgentCreatedTicket(ThisObj, TicketEncrypted);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_Chat_WebRTCAgentCreatedTicket";
                        return ErrorMessage;
                    }
                    //receive_Chat_AgentReportOpentokDataCreated
                    try {
                        this.privateProxyChat.client.receive_Chat_AgentReportOpentokDataCreated = function () {
                            ThisObj.receive_Chat_AgentReportOpentokDataCreated(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_Chat_AgentReportOpentokDataCreated";
                        return ErrorMessage;
                    }
                    try {
                        this.privateProxyChat.client.receive_ConfirmationAgentReceiveMessage = function (EncryptedChatTextIdBD) {
                            ThisObj.receive_ConfirmationAgentReceiveMessage(ThisObj, EncryptedChatTextIdBD);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ConfirmationAgentReceiveMessage";
                        return ErrorMessage;
                    }
                    //receive_ReconnectFail
                    try {
                        this.privateProxyChat.client.receive_ReconnectFail = function () {
                            ThisObj.receive_ReconnectFail(ThisObj);
                        };
                    }
                    catch (ex) {
                        ErrorMessage = "Error mapping receive_ReconnectFail";
                        return ErrorMessage;
                    }
                    return "SUCCESS";
                };
                ChatV32.prototype.StartHub = function () {
                    var ThisObj;
                    ThisObj = this;
                    //start the hub
                    try {
                        $.connection.hub.start().done(function () {
                            //notify success HUB STARTED
                            ThisObj.Fn_Event_Hub_StartOk();
                            //start RSADialog
                            ThisObj.privateInitRSADialog(ThisObj);
                        }).fail(function () {
                            //notify fail HUB NOT CONNECTED
                            ThisObj.Fn_Event_Hub_StartFail();
                        });
                    }
                    catch (ex) {
                        console.log(ex);
                        //notify fail HUB NOT CONNECTED
                        ThisObj.Fn_Event_Hub_StartFail();
                        return;
                    }
                };
                ChatV32.prototype.privateReceive_ACK_SetSymmetricKey = function (ThisObj) {
                    //start sending keep alive
                    ThisObj.privateFnKeepAliveHub(ThisObj);
                    if (ThisObj.RoutingMode == "AUTOMATIC") {
                        if (ThisObj.ReopenId == "0") {
                            ThisObj.privateFnTryRouting(ThisObj);
                        }
                        else {
                            ThisObj.privateFnTryReopen(ThisObj);
                        }
                    }
                };
                //receive ack try connect (if successfully establish a connection selectedConnectionIdBD<>0)
                ChatV32.prototype.privateReceive_ACK_TryConnect = function (ThisObj, selectedConnectionIdBD, QueuePos, EWT) {
                    if (selectedConnectionIdBD == "0") {
                        //notify fail to connect and wait if external application
                        //try to connect again using fnTryRoutingAgain
                        ThisObj.Fn_Event_RoutingToAgentsFail(QueuePos, EWT, $.connection.hub.id);
                    }
                    else {
                        ThisObj.privateSelectedConnectionIdBD = selectedConnectionIdBD;
                        ThisObj.privateScreenStatus = "Chatting";
                        //notify connection success
                        ThisObj.Fn_Event_RoutingToAgentsOK(selectedConnectionIdBD);
                    }
                };
                ChatV32.prototype.privateReceive_ChatMessageUserCallback = function (ThisObj, EncryptedChatMessage, EncryptedChatMessageIdBD) {
                    var message;
                    var messageId;
                    message = ThisObj.Fn_DecryptMessageHub(EncryptedChatMessage, ThisObj.privateSymmetrickey1);
                    messageId = ThisObj.Fn_DecryptMessageHub(EncryptedChatMessageIdBD, ThisObj.privateSymmetrickey1);
                    ThisObj.Fn_Event_UserMessageCallback(message, messageId);
                };
                ChatV32.prototype.receive_ChatMessageFromAgent = function (ThisObj, EncryptedChatMessage, EncryptedAgentRenderHeader, EncryptedChatTextId) {
                    var message;
                    var agentHeader;
                    var chatTextId;
                    message = ThisObj.Fn_DecryptMessageHub(EncryptedChatMessage, ThisObj.privateSymmetrickey1);
                    agentHeader = ThisObj.Fn_DecryptMessageHub(EncryptedAgentRenderHeader, ThisObj.privateSymmetrickey1);
                    chatTextId = ThisObj.Fn_DecryptMessageHub(EncryptedChatTextId, ThisObj.privateSymmetrickey1);
                    ThisObj.Fn_Event_Receive_Message(message, agentHeader, chatTextId);
                };
                ChatV32.prototype.receive_ChatAgentIsTyping = function (ThisObj) {
                    if (ThisObj.Fn_Event_AgentIsTyping != null) {
                        ThisObj.Fn_Event_AgentIsTyping();
                    }
                };
                ChatV32.prototype.receive_ChatAgentIsNoTyping = function (ThisObj) {
                    if (ThisObj.Fn_Event_AgentNoTyping != null) {
                        ThisObj.Fn_Event_AgentNoTyping();
                    }
                };
                ChatV32.prototype.receive_ChatEnd = function (ThisObj) {
                    if (ThisObj.Fn_Event_ChatEnd != null) {
                        ThisObj.Fn_Event_ChatEnd();
                    }
                };
                ChatV32.prototype.receive_ChatSendMailFail = function (ThisObj) {
                    if (ThisObj.Fn_Event_EmailTranscriptFail != null) {
                        ThisObj.Fn_Event_EmailTranscriptFail();
                    }
                };
                ChatV32.prototype.receive_ChatSendMailSuccess = function (ThisObj) {
                    if (ThisObj.Fn_Event_EmailTranscriptOk != null) {
                        ThisObj.Fn_Event_EmailTranscriptOk();
                    }
                };
                ChatV32.prototype.receive_ChatStartTransfer = function (ThisObj) {
                    ThisObj.privateScreenStatus = "StartTransfer";
                    if (ThisObj.Fn_Event_StartTransfer != null) {
                        ThisObj.Fn_Event_StartTransfer();
                    }
                };
                ChatV32.prototype.receive_ChatRouteTransfer = function (ThisObj, NewChatRequestIdEncrypted) {
                    if (ThisObj.Fn_Event_RouteTransfer != null) {
                        var NewChatRequestId;
                        NewChatRequestId = ThisObj.Fn_DecryptMessageHub(NewChatRequestIdEncrypted, ThisObj.privateSymmetrickey1);
                        ThisObj.Fn_Event_RouteTransfer(NewChatRequestId);
                    }
                };
                ChatV32.prototype.receive_Chat_AgentEndChat = function (ThisObj) {
                    ThisObj.privateScreenStatus = "End";
                    ThisObj.Fn_Event_ChatEnd();
                };
                ChatV32.prototype.receive_Chat_ChatEnd = function (ThisObj) {
                    ThisObj.privateScreenStatus = "End";
                    ThisObj.Fn_Event_ChatEnd();
                };
                ChatV32.prototype.receive_ChatLinkTransfer = function (ThisObj, EncryptedLinkTransfer) {
                    if (ThisObj.Fn_Event_LinkHistoryTransfer != null) {
                        var LinkTransfer;
                        LinkTransfer = ThisObj.Fn_DecryptMessageHub(EncryptedLinkTransfer, ThisObj.privateSymmetrickey1);
                        ThisObj.Fn_Event_LinkHistoryTransfer(LinkTransfer);
                    }
                };
                ChatV32.prototype.receive_Chat_WebRTAgentEnabled = function (ThisObj) {
                    if (ThisObj.Fn_Event_WebRTCAgentSideOK != null) {
                        ThisObj.Fn_Event_WebRTCAgentSideOK();
                    }
                };
                ChatV32.prototype.receive_Chat_WebRTAgentDisabled = function (ThisObj) {
                    if (ThisObj.Fn_Event_WebRTCAgentSideFail != null) {
                        ThisObj.Fn_Event_WebRTCAgentSideFail();
                    }
                };
                ChatV32.prototype.receive_Chat_RequestViewDesktopPrompt = function (ThisObj) {
                    if (ThisObj.Fn_RequestViewDesktopPrompt != null) {
                        ThisObj.Fn_RequestViewDesktopPrompt();
                    }
                };
                ChatV32.prototype.receive_ViewDesktopGuidData = function (ThisObj, ConnectionIdEncrypted, OneGuidEncrypted) {
                    var OneGuid;
                    var ConnectionId;
                    ConnectionId = ThisObj.Fn_DecryptMessageHub(ConnectionIdEncrypted, ThisObj.privateSymmetrickey1);
                    OneGuid = ThisObj.Fn_DecryptMessageHub(OneGuidEncrypted, ThisObj.privateSymmetrickey1);
                    ThisObj.Fn_Event_ViewDesktopData(ConnectionId, OneGuid);
                };
                ChatV32.prototype.receive_ACK_TryReopen = function (ThisObj, ResultTryReopen, ChatRequestEncrypted, ConnectionIDBDEncrypted) {
                    var ChatRequest;
                    var ConnectionIDBD;
                    console.log(ResultTryReopen);
                    if (ResultTryReopen == 'OK') {
                        ChatRequest = ThisObj.Fn_DecryptMessageHub(ChatRequestEncrypted, ThisObj.privateSymmetrickey1);
                        ConnectionIDBD = ThisObj.Fn_DecryptMessageHub(ConnectionIDBDEncrypted.toString(), ThisObj.privateSymmetrickey1);
                        ThisObj.privateSelectedConnectionIdBD = ThisObj.ReopenId;
                        ThisObj.privateScreenStatus = "Chatting";
                        //notify connection success
                        ThisObj.Fn_Event_RoutingToAgentsOK(ThisObj.ReopenId);
                        ThisObj.Fn_Event_LinkHistoryTransfer(ConnectionIDBD);
                    }
                    else {
                    }
                };
                ChatV32.prototype.receive_Chat_WebRTCAgentCreatedTicket = function (ThisObj, TicketEncrypted) {
                    var Ticket;
                    if (ThisObj.Fn_Event_WebRTCTechTicketCreated != null) {
                        Ticket = ThisObj.Fn_DecryptMessageHub(TicketEncrypted, ThisObj.privateSymmetrickey1);
                        ThisObj.Fn_Event_WebRTCTechTicketCreated(Ticket);
                    }
                };
                ChatV32.prototype.receive_Chat_AgentReportOpentokDataCreated = function (ThisObj) {
                    if (ThisObj.Fn_Event_WebRTCTechOpentokDataCreated != null) {
                        ThisObj.Fn_Event_WebRTCTechOpentokDataCreated();
                    }
                };
                ChatV32.prototype.receive_ConfirmationAgentReceiveMessage = function (ThisObj, EncryptedChatTextIdBD) {
                    var ChatTextIdBD;
                    if (ThisObj.Fn_Event_AgentReceivedMessage != null) {
                        ChatTextIdBD = ThisObj.Fn_DecryptMessageHub(EncryptedChatTextIdBD, ThisObj.privateSymmetrickey1);
                        ThisObj.Fn_Event_AgentReceivedMessage(ChatTextIdBD);
                    }
                };
                ChatV32.prototype.receive_ReconnectFail = function (ThisObj) {
                    if (ThisObj.Fn_Event_ReconnectFail != null) {
                        ThisObj.Fn_Event_ReconnectFail();
                    }
                };
                return ChatV32;
            }());
            ExternalTools.ChatV32 = ChatV32;
        })(ExternalTools = TPClient.ExternalTools || (TPClient.ExternalTools = {}));
    })(TPClient = Teleperformance.TPClient || (Teleperformance.TPClient = {}));
})(Teleperformance || (Teleperformance = {}));
//# sourceMappingURL=ChatExternal_V_3.2.js.map