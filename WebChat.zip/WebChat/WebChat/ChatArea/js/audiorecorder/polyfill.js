/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./test/demo/polyfill.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./index.js":
/*!******************!*\
  !*** ./index.js ***!
  \******************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("var AudioContext = window.AudioContext || window.webkitAudioContext\n\nfunction createWorker (fn) {\n  var js = fn\n    .toString()\n    .replace(/^function\\s*\\(\\)\\s*{/, '')\n    .replace(/}$/, '')\n  var blob = new Blob([js])\n  return new Worker(URL.createObjectURL(blob))\n}\n\nvar context\n\n/**\n * Audio Recorder with MediaRecorder API.\n *\n * @param {MediaStream} stream The audio stream to record.\n *\n * @example\n * navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {\n *   var recorder = new MediaRecorder(stream)\n * })\n *\n * @class\n */\nfunction MediaRecorder (stream) {\n  /**\n   * The `MediaStream` passed into the constructor.\n   * @type {MediaStream}\n   */\n  this.stream = stream\n\n  /**\n   * The current state of recording process.\n   * @type {\"inactive\"|\"recording\"|\"paused\"}\n   */\n  this.state = 'inactive'\n\n  this.em = document.createDocumentFragment()\n  this.encoder = createWorker(MediaRecorder.encoder)\n\n  var recorder = this\n  this.encoder.addEventListener('message', function (e) {\n    var event = new Event('dataavailable')\n    event.data = new Blob([e.data], { type: recorder.mimeType })\n    recorder.em.dispatchEvent(event)\n    if (recorder.state === 'inactive') {\n      recorder.em.dispatchEvent(new Event('stop'))\n    }\n  })\n}\n\nMediaRecorder.prototype = {\n  /**\n   * The MIME type that is being used for recording.\n   * @type {string}\n   */\n  mimeType: 'audio/wav',\n\n  /**\n   * Begins recording media.\n   *\n   * @param {number} [timeslice] The milliseconds to record into each `Blob`.\n   *                             If this parameter isn’t included, single `Blob`\n   *                             will be recorded.\n   *\n   * @return {undefined}\n   *\n   * @example\n   * recordButton.addEventListener('click', function () {\n   *   recorder.start()\n   * })\n   */\n  start: function start (timeslice) {\n    if (this.state === 'inactive') {\n      this.state = 'recording'\n\n      if (!context) {\n        context = new AudioContext()\n      }\n      var input = context.createMediaStreamSource(this.stream)\n      var processor = context.createScriptProcessor(2048, 1, 1)\n\n      var recorder = this\n      processor.onaudioprocess = function (e) {\n        if (recorder.state === 'recording') {\n          recorder.encoder.postMessage([\n            'encode', e.inputBuffer.getChannelData(0)\n          ])\n        }\n      }\n\n      input.connect(processor)\n      processor.connect(context.destination)\n\n      this.em.dispatchEvent(new Event('start'))\n\n      if (timeslice) {\n        this.slicing = setInterval(function () {\n          if (recorder.state === 'recording') recorder.requestData()\n        }, timeslice)\n      }\n    }\n  },\n\n  /**\n   * Stop media capture and raise `dataavailable` event with recorded data.\n   *\n   * @return {undefined}\n   *\n   * @example\n   * finishButton.addEventListener('click', function () {\n   *   recorder.stop()\n   * })\n   */\n  stop: function stop () {\n    if (this.state !== 'inactive') {\n      this.requestData()\n      this.state = 'inactive'\n      clearInterval(this.slicing)\n    }\n  },\n\n  /**\n   * Pauses recording of media streams.\n   *\n   * @return {undefined}\n   *\n   * @example\n   * pauseButton.addEventListener('click', function () {\n   *   recorder.pause()\n   * })\n   */\n  pause: function pause () {\n    if (this.state === 'recording') {\n      this.state = 'paused'\n      this.em.dispatchEvent(new Event('pause'))\n    }\n  },\n\n  /**\n   * Resumes media recording when it has been previously paused.\n   *\n   * @return {undefined}\n   *\n   * @example\n   * resumeButton.addEventListener('click', function () {\n   *   recorder.resume()\n   * })\n   */\n  resume: function resume () {\n    if (this.state === 'paused') {\n      this.state = 'recording'\n      this.em.dispatchEvent(new Event('resume'))\n    }\n  },\n\n  /**\n   * Raise a `dataavailable` event containing the captured media.\n   *\n   * @return {undefined}\n   *\n   * @example\n   * this.on('nextData', function () {\n   *   recorder.requestData()\n   * })\n   */\n  requestData: function requestData () {\n    if (this.state !== 'inactive') {\n      this.encoder.postMessage(['dump', context.sampleRate])\n    }\n  },\n\n  /**\n   * Add listener for specified event type.\n   *\n   * @param {\"start\"|\"stop\"|\"pause\"|\"resume\"|\"dataavailable\"} type Event type.\n   * @param {function} listener The listener function.\n   *\n   * @return {undefined}\n   *\n   * @example\n   * recorder.addEventListener('dataavailable', function (e) {\n   *   audio.src = URL.createObjectURL(e.data)\n   * })\n   */\n  addEventListener: function addEventListener () {\n    this.em.addEventListener.apply(this.em, arguments)\n  },\n\n  /**\n   * Remove event listener.\n   *\n   * @param {\"start\"|\"stop\"|\"pause\"|\"resume\"|\"dataavailable\"} type Event type.\n   * @param {function} listener The same function used in `addEventListener`.\n   *\n   * @return {undefined}\n   */\n  removeEventListener: function removeEventListener () {\n    this.em.removeEventListener.apply(this.em, arguments)\n  },\n\n  /**\n   * Calls each of the listeners registered for a given event.\n   *\n   * @param {Event} event The event object.\n   *\n   * @return {boolean} Is event was no canceled by any listener.\n   */\n  dispatchEvent: function dispatchEvent () {\n    this.em.dispatchEvent.apply(this.em, arguments)\n  }\n}\n\n/**\n * Returns `true` if the MIME type specified is one the polyfill can record.\n *\n * This polyfill supports only `audio/wav`.\n *\n * @param {string} mimeType The mimeType to check.\n *\n * @return {boolean} `true` on `audio/wav` MIME type.\n */\nMediaRecorder.isTypeSupported = function isTypeSupported (mimeType) {\n  return /audio\\/wave?/.test(mimeType)\n}\n\n/**\n * `true` if MediaRecorder can not be polyfilled in the current browser.\n * @type {boolean}\n *\n * @example\n * if (MediaRecorder.notSupported) {\n *   showWarning('Audio recording is not supported in this browser')\n * }\n */\nMediaRecorder.notSupported = !navigator.mediaDevices || !AudioContext\n\n/**\n * Converts RAW audio buffer to compressed audio files.\n * It will be loaded to Web Worker.\n * By default, WAVE encoder will be used.\n * @type {function}\n *\n * @example\n * MediaRecorder.prototype.mimeType = 'audio/ogg'\n * MediaRecorder.encoder = oggEncoder\n */\nMediaRecorder.encoder = __webpack_require__(/*! ./wave-encoder */ \"./wave-encoder.js\")\n\nmodule.exports = MediaRecorder\n\n\n//# sourceURL=webpack:///./index.js?");

/***/ }),

/***/ "./test/demo/polyfill.js":
/*!*******************************!*\
  !*** ./test/demo/polyfill.js ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("document.addEventListener('DOMContentLoaded', function () {\n  document.getElementById('mode').innerText = 'Polyfill is enabled'\n})\nwindow.MediaRecorder = __webpack_require__(/*! ../../ */ \"./index.js\")\n\n\n//# sourceURL=webpack:///./test/demo/polyfill.js?");

/***/ }),

/***/ "./wave-encoder.js":
/*!*************************!*\
  !*** ./wave-encoder.js ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("// Copied from https://github.com/chris-rudmin/Recorderjs\n\nmodule.exports = function () {\n  var BYTES_PER_SAMPLE = 2\n\n  var recorded = []\n\n  function encode (buffer) {\n    var length = buffer.length\n    var data = new Uint8Array(length * BYTES_PER_SAMPLE)\n    for (var i = 0; i < length; i++) {\n      var index = i * BYTES_PER_SAMPLE\n      var sample = buffer[i]\n      if (sample > 1) {\n        sample = 1\n      } else if (sample < -1) {\n        sample = -1\n      }\n      sample = sample * 32768\n      data[index] = sample\n      data[index + 1] = sample >> 8\n    }\n    recorded.push(data)\n  }\n\n  function dump (sampleRate) {\n    var bufferLength = recorded.length ? recorded[0].length : 0\n    var length = recorded.length * bufferLength\n    var wav = new Uint8Array(44 + length)\n    var view = new DataView(wav.buffer)\n\n    // RIFF identifier 'RIFF'\n    view.setUint32(0, 1380533830, false)\n    // file length minus RIFF identifier length and file description length\n    view.setUint32(4, 36 + length, true)\n    // RIFF type 'WAVE'\n    view.setUint32(8, 1463899717, false)\n    // format chunk identifier 'fmt '\n    view.setUint32(12, 1718449184, false)\n    // format chunk length\n    view.setUint32(16, 16, true)\n    // sample format (raw)\n    view.setUint16(20, 1, true)\n    // channel count\n    view.setUint16(22, 1, true)\n    // sample rate\n    view.setUint32(24, sampleRate, true)\n    // byte rate (sample rate * block align)\n    view.setUint32(28, sampleRate * BYTES_PER_SAMPLE, true)\n    // block align (channel count * bytes per sample)\n    view.setUint16(32, BYTES_PER_SAMPLE, true)\n    // bits per sample\n    view.setUint16(34, 8 * BYTES_PER_SAMPLE, true)\n    // data chunk identifier 'data'\n    view.setUint32(36, 1684108385, false)\n    // data chunk length\n    view.setUint32(40, length, true)\n\n    for (var i = 0; i < recorded.length; i++) {\n      wav.set(recorded[i], i * bufferLength + 44)\n    }\n\n    recorded = []\n    postMessage(wav.buffer, [wav.buffer])\n  }\n\n  onmessage = function (e) {\n    if (e.data[0] === 'encode') {\n      encode(e.data[1])\n    } else {\n      dump(e.data[1])\n    }\n  }\n}\n\n\n//# sourceURL=webpack:///./wave-encoder.js?");

/***/ })

/******/ });