﻿using System;
using System.Collections.Generic;



namespace WebChat
{
    public class nonceItem
    {
        public String Nonce { get; set; }
        public DateTime CreationDate { get; set; }
        public String State { get; set; }
    }
    public class MemoryCollections
    {
        private static readonly object listLock = new object();
        private static List<nonceItem> MobileChatNonces = new List<nonceItem>();

        public static String Add()
        {
            nonceItem oneNonce = new nonceItem();
            lock (listLock){
                oneNonce.Nonce=Guid.NewGuid().ToString();
                oneNonce.CreationDate=DateTime.UtcNow;
                oneNonce.State = "FREE";
                MobileChatNonces.Add(oneNonce);
            }
            return oneNonce.Nonce;
        }

        public static Boolean UseNonce(String Nonce)
        {
            Boolean ReturnValue;
            Boolean PerformGC;
            Boolean Restart;
            int i;
            ReturnValue = false;
            PerformGC = false;
            Restart = true;
            lock (listLock)
            {
                for (i = 0; i <= MobileChatNonces.Count - 1; i++)
                {
                    if ((MobileChatNonces[i].Nonce.Equals(Nonce)) && (MobileChatNonces[i].State.Equals("FREE")) )
                    {
                        MobileChatNonces[i].State = "USED";
                        ReturnValue = true;
                    }
                    if (MobileChatNonces[i].CreationDate < DateTime.UtcNow.AddDays(-10))
                    {
                        PerformGC = true;
                    }
                }
                if (PerformGC)
                {
                    while (Restart)
                    {
                        Restart = false;
                        for (i = 0; i <= MobileChatNonces.Count - 1; i++)
                        {
                            if (MobileChatNonces[i].CreationDate < DateTime.UtcNow.AddDays(-10))
                            {
                                MobileChatNonces.RemoveAt(i);
                                Restart = true;
                                break;
                            }
                        }
                    }
                }
            }
            return ReturnValue;
        }


    }
}